function createContextMenus() {
  chrome.contextMenus.removeAll(() => {
    console.log("Creating Jaydai context menus");
    chrome.contextMenus.create({
      id: "create_block",
      title: "Create a Jaydai Block",
      contexts: ["all"]
    });
    chrome.contextMenus.create({
      id: "insert_block",
      title: "Insert a Jaydai Block",
      contexts: ["all"]
    });
  });
}
chrome.runtime.onInstalled.addListener(() => {
  chrome.tabs.create({ url: "welcome.html" });
  createContextMenus();
});
chrome.runtime.onStartup.addListener(createContextMenus);
createContextMenus();
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab || !tab.id) return;
  if (info.menuItemId === "create_block") {
    chrome.tabs.sendMessage(tab.id, {
      action: "openCreateBlockDialog",
      content: info.selectionText || ""
    });
  } else if (info.menuItemId === "insert_block") {
    chrome.tabs.sendMessage(tab.id, { action: "openInsertBlockDialog" });
  }
});
chrome.commands.onCommand.addListener((command) => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const tab = tabs[0];
    if (!tab || !tab.id) return;
    if (command === "create-prompt") {
      chrome.tabs.sendMessage(tab.id, { action: "openCreateBlockDialog", content: "" });
    } else if (command === "insert-prompt") {
      chrome.tabs.sendMessage(tab.id, { action: "openInsertBlockDialog" });
    }
  });
});
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const actions = {
    // Auth actions
    googleSignIn: () => googleSignIn(sendResponse),
    emailSignIn: () => emailSignIn(request.email, request.password, sendResponse),
    signUp: () => signUp(request.email, request.password, request.name, sendResponse),
    getAuthToken: () => sendAuthToken(sendResponse),
    refreshAuthToken: () => refreshAndSendToken(sendResponse),
    // Locale actions
    getUserLocale: () => {
      const locale = chrome.i18n.getUILanguage();
      sendResponse({ success: true, locale });
      return false;
    },
    // Network monitoring actions - simplified
    "start-network-monitoring": () => {
      console.log("🔍 Starting network monitoring (simplified version)...");
      sendResponse({ success: true });
      return false;
    },
    "stop-network-monitoring": () => {
      console.log("🔍 Stopping network monitoring (simplified version)...");
      sendResponse({ success: true });
      return false;
    },
    "network-request-captured": () => {
      var _a;
      if ((_a = sender.tab) == null ? void 0 : _a.id) {
        chrome.tabs.sendMessage(sender.tab.id, {
          action: "network-request-captured",
          data: request.data
        });
      }
      sendResponse({ success: true });
      return false;
    }
  };
  if (actions[request.action]) {
    const result = actions[request.action]();
    return result === false ? false : true;
  } else {
    sendResponse({ success: false, error: "Invalid action" });
    return false;
  }
});
async function emailSignIn(email, password, sendResponse) {
  try {
    console.log("🔑 Attempting email sign-in for:", email);
    const response = await fetch(`${"https://api.dev.jayd.ai"}/auth/sign_in`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password })
    });
    const data = await response.json();
    if (!response.ok) {
      console.error("❌ Email Sign-In failed:", data);
      sendResponse({
        success: false,
        error: data.detail || "Invalid email or password"
      });
      return;
    }
    if (!data.session || !data.session.access_token || !data.session.refresh_token) {
      console.error("❌ Invalid response from sign-in endpoint (missing session data):", data);
      sendResponse({
        success: false,
        error: "Server returned invalid authentication data"
      });
      return;
    }
    console.log("✅ Email Sign-In successful");
    storeAuthSession(data.session);
    if (data.user) {
      storeUser(data.user);
    } else {
      console.warn("⚠️ No user data returned from sign-in endpoint");
    }
    sendResponse({
      success: true,
      user: data.user,
      access_token: data.session.access_token
    });
  } catch (error) {
    console.error("❌ Error in email sign-in:", error);
    sendResponse({
      success: false,
      error: error.message || "Unable to connect to authentication service"
    });
  }
  return true;
}
function signUp(email, password, name, sendResponse) {
  console.log("📝 Attempting sign-up for:", email);
  fetch(`${"https://api.dev.jayd.ai"}/auth/sign_up`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password, name })
  }).then((response) => {
    const contentType = response.headers.get("content-type");
    if (!contentType || !contentType.includes("application/json")) {
      throw new Error("Server returned non-JSON response");
    }
    return response.json();
  }).then((data) => {
    if (!data.success) {
      throw new Error(data.detail || data.error || "Sign-up failed");
    }
    console.log("✅ Signup successful");
    if (data.user) {
      storeUser(data.user);
    }
    if (data.session && data.session.access_token && data.session.refresh_token) {
      storeAuthSession(data.session);
    }
    sendResponse({
      success: true,
      user: data.user
    });
  }).catch((error) => {
    console.error("❌ Error in signup:", error);
    sendResponse({
      success: false,
      error: error.message || "Failed to create account"
    });
  });
  return true;
}
function googleSignIn(sendResponse) {
  console.log("🔍 Starting Google sign-in flow");
  const manifest = chrome.runtime.getManifest();
  const redirectUri = `https://${chrome.runtime.id}.chromiumapp.org`;
  if (!manifest.oauth2 || !manifest.oauth2.client_id) {
    console.error("❌ Missing Google OAuth client ID in manifest");
    sendResponse({
      success: false,
      error: "Google OAuth is not properly configured"
    });
    return true;
  }
  const authUrl = new URL("https://accounts.google.com/o/oauth2/auth");
  authUrl.searchParams.set("client_id", manifest.oauth2.client_id);
  authUrl.searchParams.set("response_type", "id_token");
  authUrl.searchParams.set("access_type", "offline");
  authUrl.searchParams.set("redirect_uri", redirectUri);
  authUrl.searchParams.set("scope", (manifest.oauth2.scopes || ["email", "profile"]).join(" "));
  authUrl.searchParams.set("prompt", "consent");
  console.log("Redirect URI:", redirectUri);
  chrome.identity.launchWebAuthFlow({
    url: authUrl.href,
    interactive: true
  }, async (redirectedUrl) => {
    if (chrome.runtime.lastError) {
      console.error("❌ Google Sign-In failed:", chrome.runtime.lastError);
      sendResponse({
        success: false,
        error: chrome.runtime.lastError.message || "Google authentication was canceled"
      });
      return;
    }
    if (!redirectedUrl) {
      console.error("❌ No redirect URL received");
      sendResponse({
        success: false,
        error: "No authentication data received from Google"
      });
      return;
    }
    try {
      const url = new URL(redirectedUrl);
      const params = new URLSearchParams(url.hash.replace("#", "?"));
      const idToken = params.get("id_token");
      if (!idToken) {
        console.error("❌ No id_token in redirect URL");
        sendResponse({
          success: false,
          error: "Google authentication didn't return an ID token"
        });
        return;
      }
      console.log("🔹 Google ID Token received");
      const apiUrl = "https://api.dev.jayd.ai";
      const response = await fetch(`${apiUrl}/auth/sign_in_with_google`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Origin": chrome.runtime.getURL("")
        },
        body: JSON.stringify({
          id_token: idToken
        }),
        credentials: "include"
      });
      const data = await response.json();
      if (!response.ok) {
        console.error("❌ Backend authentication failed:", data);
        sendResponse({
          success: false,
          error: data.detail || data.error || "Backend authentication failed"
        });
        return;
      }
      if (!data.session || !data.session.access_token || !data.session.refresh_token) {
        console.error("❌ Invalid response from Google auth endpoint (missing session data):", data);
        sendResponse({
          success: false,
          error: "Server returned invalid authentication data"
        });
        return;
      }
      console.log("✅ Google authentication successful");
      storeAuthSession(data.session);
      if (data.user) {
        storeUser(data.user);
      }
      sendResponse({
        success: true,
        user: data.user,
        session: data.session
      });
    } catch (error) {
      console.error("❌ Error processing Google authentication:", error);
      sendResponse({
        success: false,
        error: error.message || "Failed to process Google authentication"
      });
    }
  });
  return true;
}
function storeUser(user) {
  if (!user) {
    console.error("❌ Attempted to store undefined/null user");
    return;
  }
  chrome.storage.local.set({ user }, () => {
    if (chrome.runtime.lastError) {
      console.error("❌ Error storing user data:", chrome.runtime.lastError);
    } else {
      console.log("✅ User data stored successfully:", user.id);
    }
  });
}
function storeAuthSession(session) {
  if (!session) {
    console.error("❌ Attempted to store undefined/null session");
    return;
  }
  if (!session.access_token || !session.refresh_token) {
    console.error("❌ Incomplete session data:", session);
    return;
  }
  console.log("🔄 Storing auth session. Expires at:", session.expires_at);
  chrome.storage.local.set({
    access_token: session.access_token,
    refresh_token: session.refresh_token,
    token_expires_at: session.expires_at
  }, () => {
    if (chrome.runtime.lastError) {
      console.error("❌ Error storing auth session:", chrome.runtime.lastError);
    } else {
      console.log("✅ Auth session stored successfully");
    }
  });
}
function sendAuthToken(sendResponse) {
  chrome.storage.local.get(["access_token", "refresh_token", "token_expires_at", "user"], (result) => {
    const now = Math.floor(Date.now() / 1e3);
    console.log("🔄 Current time:", now);
    console.log("🔄 Token expires at:", result.token_expires_at);
    if (result.access_token && result.token_expires_at && result.token_expires_at > now) {
      console.log("✅ Using valid auth token");
      sendResponse({ success: true, token: result.access_token });
      return;
    }
    if (result.refresh_token) {
      console.log("⚠️ Token expired. Attempting refresh...");
      refreshAndSendToken(sendResponse);
      return;
    }
    if (result.user && result.user.id) {
      console.log("⚠️ No valid tokens, but user data exists. Redirecting to silent sign-in...");
      sendResponse({
        success: false,
        error: "Session expired",
        errorCode: "SESSION_EXPIRED",
        needsReauth: true
      });
      return;
    }
    console.error("❌ No authentication data found");
    sendResponse({
      success: false,
      error: "Not authenticated",
      errorCode: "NOT_AUTHENTICATED",
      needsReauth: true
    });
  });
  return true;
}
function refreshAndSendToken(sendResponse) {
  chrome.storage.local.get(["refresh_token", "user"], async (result) => {
    if (!result.refresh_token) {
      console.error("❌ No refresh token available");
      if (result.user && result.user.id) {
        sendResponse({
          success: false,
          error: chrome.i18n.getMessage("sessionExpired", void 0, "Session expired. Please sign in again."),
          errorCode: "REFRESH_TOKEN_MISSING",
          needsReauth: true
        });
      } else {
        sendResponse({
          success: false,
          error: chrome.i18n.getMessage("notAuthenticated", void 0, "Not authenticated. Please sign in."),
          errorCode: "NOT_AUTHENTICATED",
          needsReauth: true
        });
      }
      return;
    }
    try {
      console.log("🔄 Attempting to refresh token...");
      const response = await fetch(`${"https://api.dev.jayd.ai"}/auth/refresh_token`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refresh_token: result.refresh_token })
      });
      if (!response.ok) {
        console.error("❌ Token refresh failed:", await response.text());
        if (response.status === 401 || response.status === 403) {
          chrome.storage.local.remove(["access_token", "refresh_token", "token_expires_at"]);
          sendResponse({
            success: false,
            error: chrome.i18n.getMessage("sessionExpired", void 0, "Session expired. Please sign in again."),
            errorCode: "INVALID_REFRESH_TOKEN",
            needsReauth: true
          });
        } else {
          sendResponse({
            success: false,
            error: chrome.i18n.getMessage("refreshFailed", void 0, "Failed to refresh token. Please try again."),
            errorCode: "REFRESH_FAILED"
          });
        }
        return;
      }
      const data = await response.json();
      console.log("🔄 Token refreshed successfully");
      if (!data.session || !data.session.access_token) {
        console.error("❌ Invalid response from refresh endpoint:", data);
        sendResponse({
          success: false,
          error: "Invalid response from server",
          errorCode: "INVALID_RESPONSE"
        });
        return;
      }
      storeAuthSession(data.session);
      sendResponse({ success: true, token: data.session.access_token });
    } catch (error) {
      console.error("❌ Error refreshing access token:", error);
      sendResponse({
        success: false,
        error: chrome.i18n.getMessage("networkError", void 0, "Network error while refreshing token"),
        errorCode: "NETWORK_ERROR"
      });
    }
  });
  return true;
}
chrome.storage.onChanged.addListener((changes, namespace) => {
  if (namespace === "local" && changes.devReloadTimestamp) {
    chrome.runtime.reload();
  }
});
//# sourceMappingURL=background.js.map
