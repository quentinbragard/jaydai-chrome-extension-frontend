(function() {
  if (!window.location.hostname.includes("chatgpt.com") && !window.location.hostname.includes("claude.ai") && !window.location.hostname.includes("mistral.ai") && !window.location.hostname.includes("copilot.microsoft.com")) {
    return;
  }
  try {
    const script = document.createElement("script");
    script.id = "jaydai:network-interceptor";
    script.src = chrome.runtime.getURL("networkInterceptor.js");
    const injectScript = () => {
      const target = document.head || document.documentElement || document.body;
      if (target) {
        target.appendChild(script);
      } else {
        console.error("❌ No target element available for script injection");
      }
    };
    injectScript();
    document.addEventListener("DOMContentLoaded", () => {
      injectModuleScript();
    });
  } catch (error) {
    console.error("❌ Error injecting interceptor:", error);
  }
  function injectModuleScript() {
    try {
      const applicationInitializerUrl = chrome.runtime.getURL("applicationInitializer.js");
      import(applicationInitializerUrl).then((module) => {
        const initialize = module.initialize || module.default && module.default.initialize;
        const cleanup = module.cleanup || module.default && module.default.cleanup;
        if (!initialize || typeof initialize !== "function") {
          throw new Error("❌ 'initialize' is not a function. Check module exports.");
        }
        initialize().catch((err) => console.error("❌ Error during initialization:", err));
        if (cleanup && typeof cleanup === "function") {
          window.addEventListener("beforeunload", () => {
            cleanup();
          });
          chrome.runtime.onMessage.addListener((message) => {
            if (message.action === "reinitialize") {
              cleanup();
              initialize().catch((err) => console.error("❌ Error during reinitialization:", err));
            }
          });
        }
      }).catch((importError) => {
        console.error("❌ Failed to import module:", importError);
      });
    } catch (error) {
      console.error("❌ Error in content script:", error);
    }
  }
})();
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  var _a, _b;
  if (message.action === "openCreateBlockDialog") {
    const content = message.content || "";
    if ((_a = window.dialogManager) == null ? void 0 : _a.openDialog) {
      window.dialogManager.openDialog("createBlock", { initialContent: content });
      sendResponse({ success: true });
    } else {
      sendResponse({ success: false });
    }
  }
  if (message.action === "openInsertBlockDialog") {
    if ((_b = window.dialogManager) == null ? void 0 : _b.openDialog) {
      window.dialogManager.openDialog("insertBlock");
      sendResponse({ success: true });
    } else {
      sendResponse({ success: false });
    }
  }
  return true;
});
//# sourceMappingURL=content.js.map
