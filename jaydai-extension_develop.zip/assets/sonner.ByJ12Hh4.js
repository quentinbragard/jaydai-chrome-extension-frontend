import { z, j as jsxRuntimeExports, T as Toaster$1 } from "./index.DcWboGrL.js";
const Toaster = ({ ...props }) => {
  const { theme = "system" } = z();
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Toaster$1,
    {
      theme,
      className: "jd-toaster jd-group",
      toastOptions: {
        classNames: {
          toast: "jd-group jd-toast jd-group-[.jd-toaster]:jd-bg-background jd-group-[.jd-toaster]:jd-text-foreground jd-group-[.jd-toaster]:jd-border-border jd-group-[.jd-toaster]:jd-shadow-lg",
          description: "jd-group-[.jd-toast]:jd-text-muted-foreground",
          actionButton: "jd-group-[.jd-toast]:jd-bg-primary jd-group-[.jd-toast]:jd-text-primary-foreground",
          cancelButton: "jd-group-[.jd-toast]:jd-bg-muted jd-group-[.jd-toast]:jd-text-muted-foreground"
        }
      },
      ...props
    }
  );
};
export {
  Toaster as T
};
//# sourceMappingURL=sonner.ByJ12Hh4.js.map
