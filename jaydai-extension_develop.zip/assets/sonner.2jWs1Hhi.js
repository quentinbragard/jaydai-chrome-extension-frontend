import { j as jsxRuntimeExports, B as Button, C as ChevronRight, g as getMessage, z, T as Toaster$1 } from "./index.DiCJHUBL.js";
const ToolCard = ({
  tool,
  onClick
}) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-relative jd-group jd-perspective jd-mb-3", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: `jd-absolute jd-inset-0 jd-bg-gradient-to-r jd-${tool.color} jd-rounded-lg jd-m-0.5 
                   jd-opacity-0 group-hover:jd-opacity-100 jd-transition-all jd-duration-300
                   jd-blur-[2px] group-hover:jd-blur-[1px] jd-scale-[0.97] group-hover:jd-scale-100`
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Button,
      {
        variant: "default",
        className: `jd-w-full jd-justify-start jd-py-6 jd-px-4 jd-relative 
                   jd-bg-card/95 jd-border jd-border-gray-800/30 
                   jd-shadow-sm hover:jd-shadow-lg jd-rounded-lg
                   jd-transition-all jd-duration-300 jd-ease-out
                   group-hover:jd-translate-y-[-2px] group-hover:jd-border-gray-700/50
                   ${tool.disabled ? "jd-opacity-80 hover:jd-opacity-80 jd-cursor-not-allowed" : ""}`,
        onClick,
        disabled: tool.disabled,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-flex jd-items-center jd-w-full jd-gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `jd-flex-shrink-0 jd-p-2 jd-rounded-md
                         jd-transition-all jd-duration-300
                         jd-bg-gradient-to-br jd-from-background/90 jd-to-background
                         group-hover:jd-shadow-md jd-shadow-sm
                         jd-border jd-border-gray-800/40 group-hover:jd-border-gray-700/70
                         ${!tool.disabled ? "group-hover:jd-scale-110" : ""}`, children: tool.icon }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-flex-grow jd-text-left jd-overflow-hidden", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-font-semibold jd-text-foreground group-hover:jd-text-white jd-transition-colors jd-duration-300", children: tool.name }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-text-xs jd-text-muted-foreground jd-truncate jd-max-w-[160px] group-hover:jd-text-gray-300 jd-transition-colors jd-duration-300", children: tool.description })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-flex-shrink-0 jd-ml-1 jd-text-muted-foreground jd-opacity-70 group-hover:jd-opacity-100 jd-transition-opacity jd-duration-300", children: !tool.disabled ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-p-1 jd-rounded-full jd-bg-gray-800/50 group-hover:jd-bg-blue-600/20 jd-transition-colors jd-duration-300", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "jd-h-4 jd-w-4 group-hover:jd-text-blue-400 jd-transition-colors jd-duration-300" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "jd-text-[10px] jd-font-medium jd-opacity-60", children: getMessage("comingSoon", void 0, "Coming Soon") }) })
          ] }),
          !tool.disabled && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-absolute jd-top-0 jd-left-0 jd-w-full jd-h-full jd-overflow-hidden jd-rounded-lg jd-pointer-events-none jd-opacity-40 group-hover:jd-opacity-70 jd-transition-opacity jd-duration-300", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-absolute jd-top-1 jd-right-1 jd-w-10 jd-h-10 jd-bg-blue-500/20 jd-rounded-full jd-blur-sm" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-absolute jd-bottom-1 jd-left-1 jd-w-12 jd-h-12 jd-bg-indigo-500/20 jd-rounded-full jd-blur-sm" })
          ] })
        ]
      }
    )
  ] });
};
const AI_TOOLS = [
  {
    name: "ChatGPT",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: "https://vetoswvwgsebhxetqppa.supabase.co/storage/v1/object/public/images/ai_tools/chatgpt_logo.png", alt: "ChatGPT", className: "jd-h-8 jd-w-8" }),
    url: "https://chat.openai.com/",
    description: getMessage("aiTools.description.ChatGPT", void 0, "OpenAI's conversational AI"),
    disabled: false,
    color: "jd-from-green-500/20 jd-to-emerald-500/20"
  },
  {
    name: "Copilot",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: "https://vetoswvwgsebhxetqppa.supabase.co/storage/v1/object/public/images/ai_tools/copilot_logo.png", alt: "Perplexity", className: "jd-h-8 jd-w-8" }),
    url: "https://copilot.microsoft.com//",
    description: getMessage("aiTools.description.Copilot", void 0, "Microsoft Copilot AI-powered search and chat"),
    disabled: false,
    color: "jd-from-pink-500/20 jd-to-rose-500/20"
  },
  {
    name: "Mistral",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: "https://vetoswvwgsebhxetqppa.supabase.co/storage/v1/object/public/images/ai_tools/mistral_logo.png", alt: "Mistral", className: "jd-h-8 jd-w-8" }),
    url: "https://chat.mistral.ai/",
    description: getMessage("aiTools.description.Mistral", void 0, "Mistral AI's conversational model"),
    disabled: false,
    color: "jd-from-amber-500/20 jd-to-yellow-500/20"
  },
  {
    name: "Claude",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: "https://vetoswvwgsebhxetqppa.supabase.co/storage/v1/object/public/images/ai_tools/claude_logo.png", alt: "Claude", className: "jd-h-8 jd-w-8" }),
    url: "https://claude.ai/",
    description: getMessage("aiTools.description.Claude", void 0, "Anthropic's AI assistant"),
    disabled: false,
    color: "jd-from-purple-500/20 jd-to-indigo-500/20"
  },
  {
    name: "Gemini",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: "https://vetoswvwgsebhxetqppa.supabase.co/storage/v1/object/public/images/ai_tools/gemini_logo.png", alt: "Gemini", className: "jd-h-8 jd-w-8" }),
    url: "https://gemini.google.com/",
    description: getMessage("aiTools.description.Gemini", void 0, "Google's generative AI"),
    disabled: true,
    color: "jd-from-blue-500/20 jd-to-sky-500/20"
  },
  {
    name: "Perplexity",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: "https://vetoswvwgsebhxetqppa.supabase.co/storage/v1/object/public/images/ai_tools/perplexity_logo.png", alt: "Perplexity", className: "jd-h-8 jd-w-8" }),
    url: "https://www.perplexity.ai/",
    description: getMessage("aiTools.description.Perplexity", void 0, "AI-powered search and chat"),
    disabled: true,
    color: "jd-from-pink-500/20 jd-to-rose-500/20"
  }
];
const Toaster = ({ ...props }) => {
  const { theme = "system" } = z();
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Toaster$1,
    {
      theme,
      className: "jd-toaster jd-group",
      toastOptions: {
        classNames: {
          toast: "jd-group jd-toast jd-group-[.jd-toaster]:jd-bg-background jd-group-[.jd-toaster]:jd-text-foreground jd-group-[.jd-toaster]:jd-border-border jd-group-[.jd-toaster]:jd-shadow-lg",
          description: "jd-group-[.jd-toast]:jd-text-muted-foreground",
          actionButton: "jd-group-[.jd-toast]:jd-bg-primary jd-group-[.jd-toast]:jd-text-primary-foreground",
          cancelButton: "jd-group-[.jd-toast]:jd-bg-muted jd-group-[.jd-toast]:jd-text-muted-foreground"
        }
      },
      ...props
    }
  );
};
export {
  AI_TOOLS as A,
  ToolCard as T,
  Toaster as a
};
//# sourceMappingURL=sonner.2jWs1Hhi.js.map
