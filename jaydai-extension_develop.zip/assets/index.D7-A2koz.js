var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
import { c as createLucideIcon, W as onEvent, X as AppEvent, Y as config$1, q as debug, Z as AbstractBaseService, _ as ENV, $ as emitEvent, r as reactExports, a0 as useCallbackRef$1, u as useComposedRefs, j as jsxRuntimeExports, f as Primitive, R as React, d as client$1, e as createContextScope, i as createSlot, n as useId, h as composeEventHandlers, m as useControllableState, P as Presence, o as cn, g as getMessage, b as authService, a as LogIn, U as UserPlus, L as Label$1, I as Input, B as Button, t as toast, K as createPopperScope, S as Anchor, a1 as useLayoutEffect2, y as reactDomExports, k as Portal$1, D as DismissableLayer, M as Content$1, Q as Root2$2, a2 as VISUALLY_HIDDEN_STYLES, V as Arrow, w as getCurrentLanguage, C as ChevronRight, a3 as createRoot, a4 as TokenService, a5 as AuthService } from "./index.DcWboGrL.js";
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$m = [
  ["path", { d: "m12 19-7-7 7-7", key: "1l729n" }],
  ["path", { d: "M19 12H5", key: "x3x0zl" }]
];
const ArrowLeft = createLucideIcon("ArrowLeft", __iconNode$m);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$l = [
  ["path", { d: "M5 12h14", key: "1ays0h" }],
  ["path", { d: "m12 5 7 7-7 7", key: "xquz4c" }]
];
const ArrowRight = createLucideIcon("ArrowRight", __iconNode$l);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$k = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "m4.9 4.9 14.2 14.2", key: "1m5liu" }]
];
const Ban = createLucideIcon("Ban", __iconNode$k);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$j = [["path", { d: "M20 6 9 17l-5-5", key: "1gmf2c" }]];
const Check = createLucideIcon("Check", __iconNode$j);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$i = [["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }]];
const ChevronDown = createLucideIcon("ChevronDown", __iconNode$i);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$h = [["path", { d: "m18 15-6-6-6 6", key: "153udz" }]];
const ChevronUp = createLucideIcon("ChevronUp", __iconNode$h);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$g = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["line", { x1: "12", x2: "12", y1: "8", y2: "12", key: "1pkeuh" }],
  ["line", { x1: "12", x2: "12.01", y1: "16", y2: "16", key: "4dfq90" }]
];
const CircleAlert = createLucideIcon("CircleAlert", __iconNode$g);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$f = [
  ["path", { d: "M21.801 10A10 10 0 1 1 17 3.335", key: "yps3ct" }],
  ["path", { d: "m9 11 3 3L22 4", key: "1pflzl" }]
];
const CircleCheckBig = createLucideIcon("CircleCheckBig", __iconNode$f);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$e = [
  ["path", { d: "M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z", key: "1rqfz7" }],
  ["path", { d: "M14 2v4a2 2 0 0 0 2 2h4", key: "tnqrlb" }],
  ["path", { d: "M10 9H8", key: "b1mrlr" }],
  ["path", { d: "M16 13H8", key: "t4e002" }],
  ["path", { d: "M16 17H8", key: "z1uh3a" }]
];
const FileText = createLucideIcon("FileText", __iconNode$e);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$d = [
  ["polyline", { points: "15 3 21 3 21 9", key: "mznyad" }],
  ["polyline", { points: "9 21 3 21 3 15", key: "1avn1i" }],
  ["line", { x1: "21", x2: "14", y1: "3", y2: "10", key: "ota7mn" }],
  ["line", { x1: "3", x2: "10", y1: "21", y2: "14", key: "1atl0r" }]
];
const Maximize2 = createLucideIcon("Maximize2", __iconNode$d);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$c = [
  ["path", { d: "M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z", key: "1lielz" }]
];
const MessageSquare = createLucideIcon("MessageSquare", __iconNode$c);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$b = [
  ["circle", { cx: "13.5", cy: "6.5", r: ".5", fill: "currentColor", key: "1okk4w" }],
  ["circle", { cx: "17.5", cy: "10.5", r: ".5", fill: "currentColor", key: "f64h9f" }],
  ["circle", { cx: "8.5", cy: "7.5", r: ".5", fill: "currentColor", key: "fotxhn" }],
  ["circle", { cx: "6.5", cy: "12.5", r: ".5", fill: "currentColor", key: "qy21gx" }],
  [
    "path",
    {
      d: "M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z",
      key: "12rzf8"
    }
  ]
];
const Palette = createLucideIcon("Palette", __iconNode$b);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$a = [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M3 9h18", key: "1pudct" }],
  ["path", { d: "M9 21V9", key: "1oto5p" }]
];
const PanelsTopLeft = createLucideIcon("PanelsTopLeft", __iconNode$a);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$9 = [
  ["path", { d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8", key: "v9h5vc" }],
  ["path", { d: "M21 3v5h-5", key: "1q7to0" }],
  ["path", { d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16", key: "3uifl3" }],
  ["path", { d: "M8 16H3v5", key: "1cv678" }]
];
const RefreshCw = createLucideIcon("RefreshCw", __iconNode$9);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$8 = [
  ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }],
  ["path", { d: "m21 21-4.3-4.3", key: "1qie3q" }]
];
const Search = createLucideIcon("Search", __iconNode$8);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$7 = [
  [
    "path",
    {
      d: "M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z",
      key: "4pj2yx"
    }
  ],
  ["path", { d: "M20 3v4", key: "1olli1" }],
  ["path", { d: "M22 5h-4", key: "1gvqau" }],
  ["path", { d: "M4 17v2", key: "vumght" }],
  ["path", { d: "M5 18H3", key: "zchphs" }]
];
const Sparkles = createLucideIcon("Sparkles", __iconNode$7);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$6 = [
  [
    "path",
    {
      d: "M11.525 2.295a.53.53 0 0 1 .95 0l2.31 4.679a2.123 2.123 0 0 0 1.595 1.16l5.166.756a.53.53 0 0 1 .294.904l-3.736 3.638a2.123 2.123 0 0 0-.611 1.878l.882 5.14a.53.53 0 0 1-.771.56l-4.618-2.428a2.122 2.122 0 0 0-1.973 0L6.396 21.01a.53.53 0 0 1-.77-.56l.881-5.139a2.122 2.122 0 0 0-.611-1.879L2.16 9.795a.53.53 0 0 1 .294-.906l5.165-.755a2.122 2.122 0 0 0 1.597-1.16z",
      key: "r04s7s"
    }
  ]
];
const Star = createLucideIcon("Star", __iconNode$6);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$5 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["circle", { cx: "12", cy: "12", r: "6", key: "1vlfrh" }],
  ["circle", { cx: "12", cy: "12", r: "2", key: "1c9p78" }]
];
const Target = createLucideIcon("Target", __iconNode$5);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$4 = [
  ["polyline", { points: "4 7 4 4 20 4 20 7", key: "1nosan" }],
  ["line", { x1: "9", x2: "15", y1: "20", y2: "20", key: "swin9y" }],
  ["line", { x1: "12", x2: "12", y1: "4", y2: "20", key: "1tx1rr" }]
];
const Type = createLucideIcon("Type", __iconNode$4);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$3 = [
  ["path", { d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2", key: "975kel" }],
  ["circle", { cx: "12", cy: "7", r: "4", key: "17ys0d" }]
];
const User = createLucideIcon("User", __iconNode$3);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$2 = [
  ["path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", key: "1yyitq" }],
  ["circle", { cx: "9", cy: "7", r: "4", key: "nufk8" }],
  ["path", { d: "M22 21v-2a4 4 0 0 0-3-3.87", key: "kshegd" }],
  ["path", { d: "M16 3.13a4 4 0 0 1 0 7.75", key: "1da9ce" }]
];
const Users = createLucideIcon("Users", __iconNode$2);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$1 = [
  ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
  ["path", { d: "m6 6 12 12", key: "d8bk6v" }]
];
const X = createLucideIcon("X", __iconNode$1);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode = [
  [
    "path",
    {
      d: "M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z",
      key: "1xq2db"
    }
  ]
];
const Zap = createLucideIcon("Zap", __iconNode);
var extendStatics = function(d, b) {
  extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
    d2.__proto__ = b2;
  } || function(d2, b2) {
    for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
  };
  return extendStatics(d, b);
};
function __extends(d, b) {
  if (typeof b !== "function" && b !== null)
    throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
  extendStatics(d, b);
  function __() {
    this.constructor = d;
  }
  d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
}
var __assign$1 = function() {
  __assign$1 = Object.assign || function __assign2(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign$1.apply(this, arguments);
};
function __rest(s, e) {
  var t = {};
  for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
    t[p] = s[p];
  if (s != null && typeof Object.getOwnPropertySymbols === "function")
    for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
      if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i]))
        t[p[i]] = s[p[i]];
    }
  return t;
}
function __awaiter(thisArg, _arguments, P, generator) {
  function adopt(value) {
    return value instanceof P ? value : new P(function(resolve) {
      resolve(value);
    });
  }
  return new (P || (P = Promise))(function(resolve, reject) {
    function fulfilled(value) {
      try {
        step(generator.next(value));
      } catch (e) {
        reject(e);
      }
    }
    function rejected(value) {
      try {
        step(generator["throw"](value));
      } catch (e) {
        reject(e);
      }
    }
    function step(result) {
      result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
    }
    step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
}
function __generator(thisArg, body) {
  var _ = { label: 0, sent: function() {
    if (t[0] & 1) throw t[1];
    return t[1];
  }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
  return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() {
    return this;
  }), g;
  function verb(n) {
    return function(v) {
      return step([n, v]);
    };
  }
  function step(op) {
    if (f) throw new TypeError("Generator is already executing.");
    while (g && (g = 0, op[0] && (_ = 0)), _) try {
      if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
      if (y = 0, t) op = [op[0] & 2, t.value];
      switch (op[0]) {
        case 0:
        case 1:
          t = op;
          break;
        case 4:
          _.label++;
          return { value: op[1], done: false };
        case 5:
          _.label++;
          y = op[1];
          op = [0];
          continue;
        case 7:
          op = _.ops.pop();
          _.trys.pop();
          continue;
        default:
          if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
            _ = 0;
            continue;
          }
          if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
            _.label = op[1];
            break;
          }
          if (op[0] === 6 && _.label < t[1]) {
            _.label = t[1];
            t = op;
            break;
          }
          if (t && _.label < t[2]) {
            _.label = t[2];
            _.ops.push(op);
            break;
          }
          if (t[2]) _.ops.pop();
          _.trys.pop();
          continue;
      }
      op = body.call(thisArg, _);
    } catch (e) {
      op = [6, e];
      y = 0;
    } finally {
      f = t = 0;
    }
    if (op[0] & 5) throw op[1];
    return { value: op[0] ? op[1] : void 0, done: true };
  }
}
function __values$1(o) {
  var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
  if (m) return m.call(o);
  if (o && typeof o.length === "number") return {
    next: function() {
      if (o && i >= o.length) o = void 0;
      return { value: o && o[i++], done: !o };
    }
  };
  throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}
function __read$1(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m) return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
  } catch (error) {
    e = { error };
  } finally {
    try {
      if (r && !r.done && (m = i["return"])) m.call(i);
    } finally {
      if (e) throw e.error;
    }
  }
  return ar;
}
function __spreadArray(to, from2, pack) {
  if (pack || arguments.length === 2) for (var i = 0, l = from2.length, ar; i < l; i++) {
    if (ar || !(i in from2)) {
      if (!ar) ar = Array.prototype.slice.call(from2, 0, i);
      ar[i] = from2[i];
    }
  }
  return to.concat(ar || Array.prototype.slice.call(from2));
}
function __await(v) {
  return this instanceof __await ? (this.v = v, this) : new __await(v);
}
function __asyncGenerator(thisArg, _arguments, generator) {
  if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
  var g = generator.apply(thisArg, _arguments || []), i, q = [];
  return i = Object.create((typeof AsyncIterator === "function" ? AsyncIterator : Object).prototype), verb("next"), verb("throw"), verb("return", awaitReturn), i[Symbol.asyncIterator] = function() {
    return this;
  }, i;
  function awaitReturn(f) {
    return function(v) {
      return Promise.resolve(v).then(f, reject);
    };
  }
  function verb(n, f) {
    if (g[n]) {
      i[n] = function(v) {
        return new Promise(function(a, b) {
          q.push([n, v, a, b]) > 1 || resume(n, v);
        });
      };
      if (f) i[n] = f(i[n]);
    }
  }
  function resume(n, v) {
    try {
      step(g[n](v));
    } catch (e) {
      settle(q[0][3], e);
    }
  }
  function step(r) {
    r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
  }
  function fulfill(value) {
    resume("next", value);
  }
  function reject(value) {
    resume("throw", value);
  }
  function settle(f, v) {
    if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
  }
}
function __asyncValues(o) {
  if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
  var m = o[Symbol.asyncIterator], i;
  return m ? m.call(o) : (o = typeof __values$1 === "function" ? __values$1(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
    return this;
  }, i);
  function verb(n) {
    i[n] = o[n] && function(v) {
      return new Promise(function(resolve, reject) {
        v = o[n](v), settle(resolve, reject, v.done, v.value);
      });
    };
  }
  function settle(resolve, reject, d, v) {
    Promise.resolve(v).then(function(v2) {
      resolve({ value: v2, done: d });
    }, reject);
  }
}
typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
  var e = new Error(message);
  return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};
var IdentifyOperation$2;
(function(IdentifyOperation2) {
  IdentifyOperation2["SET"] = "$set";
  IdentifyOperation2["SET_ONCE"] = "$setOnce";
  IdentifyOperation2["ADD"] = "$add";
  IdentifyOperation2["APPEND"] = "$append";
  IdentifyOperation2["PREPEND"] = "$prepend";
  IdentifyOperation2["REMOVE"] = "$remove";
  IdentifyOperation2["PREINSERT"] = "$preInsert";
  IdentifyOperation2["POSTINSERT"] = "$postInsert";
  IdentifyOperation2["UNSET"] = "$unset";
  IdentifyOperation2["CLEAR_ALL"] = "$clearAll";
})(IdentifyOperation$2 || (IdentifyOperation$2 = {}));
var SpecialEventType$1;
(function(SpecialEventType2) {
  SpecialEventType2["IDENTIFY"] = "$identify";
  SpecialEventType2["GROUP_IDENTIFY"] = "$groupidentify";
  SpecialEventType2["REVENUE"] = "revenue_amount";
})(SpecialEventType$1 || (SpecialEventType$1 = {}));
var UNSET_VALUE = "-";
var AMPLITUDE_PREFIX = "AMP";
var STORAGE_PREFIX = "".concat(AMPLITUDE_PREFIX, "_unsent");
var AMPLITUDE_SERVER_URL = "https://api2.amplitude.com/2/httpapi";
var EU_AMPLITUDE_SERVER_URL = "https://api.eu.amplitude.com/2/httpapi";
var AMPLITUDE_BATCH_SERVER_URL = "https://api2.amplitude.com/batch";
var EU_AMPLITUDE_BATCH_SERVER_URL = "https://api.eu.amplitude.com/batch";
var MAX_PROPERTY_KEYS = 1e3;
var isValidObject = function(properties) {
  if (Object.keys(properties).length > MAX_PROPERTY_KEYS) {
    return false;
  }
  for (var key in properties) {
    var value = properties[key];
    if (!isValidProperties(key, value))
      return false;
  }
  return true;
};
var isValidProperties = function(property, value) {
  var e_1, _a;
  if (typeof property !== "string")
    return false;
  if (Array.isArray(value)) {
    var isValid = true;
    try {
      for (var value_1 = __values$1(value), value_1_1 = value_1.next(); !value_1_1.done; value_1_1 = value_1.next()) {
        var valueElement = value_1_1.value;
        if (Array.isArray(valueElement)) {
          return false;
        } else if (typeof valueElement === "object") {
          isValid = isValid && isValidObject(valueElement);
        } else if (!["number", "string"].includes(typeof valueElement)) {
          return false;
        }
        if (!isValid) {
          return false;
        }
      }
    } catch (e_1_1) {
      e_1 = { error: e_1_1 };
    } finally {
      try {
        if (value_1_1 && !value_1_1.done && (_a = value_1.return)) _a.call(value_1);
      } finally {
        if (e_1) throw e_1.error;
      }
    }
  } else if (value === null || value === void 0) {
    return false;
  } else if (typeof value === "object") {
    return isValidObject(value);
  } else if (!["number", "string", "boolean"].includes(typeof value)) {
    return false;
  }
  return true;
};
var Identify = (
  /** @class */
  function() {
    function Identify2() {
      this._propertySet = /* @__PURE__ */ new Set();
      this._properties = {};
    }
    Identify2.prototype.getUserProperties = function() {
      return __assign$1({}, this._properties);
    };
    Identify2.prototype.set = function(property, value) {
      this._safeSet(IdentifyOperation$1.SET, property, value);
      return this;
    };
    Identify2.prototype.setOnce = function(property, value) {
      this._safeSet(IdentifyOperation$1.SET_ONCE, property, value);
      return this;
    };
    Identify2.prototype.append = function(property, value) {
      this._safeSet(IdentifyOperation$1.APPEND, property, value);
      return this;
    };
    Identify2.prototype.prepend = function(property, value) {
      this._safeSet(IdentifyOperation$1.PREPEND, property, value);
      return this;
    };
    Identify2.prototype.postInsert = function(property, value) {
      this._safeSet(IdentifyOperation$1.POSTINSERT, property, value);
      return this;
    };
    Identify2.prototype.preInsert = function(property, value) {
      this._safeSet(IdentifyOperation$1.PREINSERT, property, value);
      return this;
    };
    Identify2.prototype.remove = function(property, value) {
      this._safeSet(IdentifyOperation$1.REMOVE, property, value);
      return this;
    };
    Identify2.prototype.add = function(property, value) {
      this._safeSet(IdentifyOperation$1.ADD, property, value);
      return this;
    };
    Identify2.prototype.unset = function(property) {
      this._safeSet(IdentifyOperation$1.UNSET, property, UNSET_VALUE);
      return this;
    };
    Identify2.prototype.clearAll = function() {
      this._properties = {};
      this._properties[IdentifyOperation$1.CLEAR_ALL] = UNSET_VALUE;
      return this;
    };
    Identify2.prototype._safeSet = function(operation, property, value) {
      if (this._validate(operation, property, value)) {
        var userPropertyMap = this._properties[operation];
        if (userPropertyMap === void 0) {
          userPropertyMap = {};
          this._properties[operation] = userPropertyMap;
        }
        userPropertyMap[property] = value;
        this._propertySet.add(property);
        return true;
      }
      return false;
    };
    Identify2.prototype._validate = function(operation, property, value) {
      if (this._properties[IdentifyOperation$1.CLEAR_ALL] !== void 0) {
        return false;
      }
      if (this._propertySet.has(property)) {
        return false;
      }
      if (operation === IdentifyOperation$1.ADD) {
        return typeof value === "number";
      }
      if (operation !== IdentifyOperation$1.UNSET && operation !== IdentifyOperation$1.REMOVE) {
        return isValidProperties(property, value);
      }
      return true;
    };
    return Identify2;
  }()
);
var IdentifyOperation$1;
(function(IdentifyOperation2) {
  IdentifyOperation2["SET"] = "$set";
  IdentifyOperation2["SET_ONCE"] = "$setOnce";
  IdentifyOperation2["ADD"] = "$add";
  IdentifyOperation2["APPEND"] = "$append";
  IdentifyOperation2["PREPEND"] = "$prepend";
  IdentifyOperation2["REMOVE"] = "$remove";
  IdentifyOperation2["PREINSERT"] = "$preInsert";
  IdentifyOperation2["POSTINSERT"] = "$postInsert";
  IdentifyOperation2["UNSET"] = "$unset";
  IdentifyOperation2["CLEAR_ALL"] = "$clearAll";
})(IdentifyOperation$1 || (IdentifyOperation$1 = {}));
var OrderedIdentifyOperations = [
  IdentifyOperation$1.CLEAR_ALL,
  IdentifyOperation$1.UNSET,
  IdentifyOperation$1.SET,
  IdentifyOperation$1.SET_ONCE,
  IdentifyOperation$1.ADD,
  IdentifyOperation$1.APPEND,
  IdentifyOperation$1.PREPEND,
  IdentifyOperation$1.PREINSERT,
  IdentifyOperation$1.POSTINSERT,
  IdentifyOperation$1.REMOVE
];
var SUCCESS_MESSAGE = "Event tracked successfully";
var UNEXPECTED_ERROR_MESSAGE$1 = "Unexpected error occurred";
var MAX_RETRIES_EXCEEDED_MESSAGE$1 = "Event rejected due to exceeded retry count";
var OPT_OUT_MESSAGE = "Event skipped due to optOut config";
var MISSING_API_KEY_MESSAGE = "Event rejected due to missing API key";
var INVALID_API_KEY = "Invalid API key";
var CLIENT_NOT_INITIALIZED = "Client not initialized";
var Status$1;
(function(Status2) {
  Status2["Unknown"] = "unknown";
  Status2["Skipped"] = "skipped";
  Status2["Success"] = "success";
  Status2["RateLimit"] = "rate_limit";
  Status2["PayloadTooLarge"] = "payload_too_large";
  Status2["Invalid"] = "invalid";
  Status2["Failed"] = "failed";
  Status2["Timeout"] = "Timeout";
  Status2["SystemError"] = "SystemError";
})(Status$1 || (Status$1 = {}));
var buildResult = function(event, code, message) {
  if (code === void 0) {
    code = 0;
  }
  if (message === void 0) {
    message = Status$1.Unknown;
  }
  return { event, code, message };
};
var getGlobalScope$1 = function() {
  var ampIntegrationContextName = "ampIntegrationContext";
  if (typeof globalThis !== "undefined" && typeof globalThis[ampIntegrationContextName] !== "undefined") {
    return globalThis[ampIntegrationContextName];
  }
  if (typeof globalThis !== "undefined") {
    return globalThis;
  }
  if (typeof window !== "undefined") {
    return window;
  }
  if (typeof self !== "undefined") {
    return self;
  }
  if (typeof global !== "undefined") {
    return global;
  }
  return void 0;
};
var legacyUUID = function(a) {
  return a ? (
    // a random number from 0 to 15
    (a ^ // unless b is 8,
    Math.random() * // in which case
    16 >> // a random number from
    a / 4).toString(16)
  ) : (
    // or otherwise a concatenated string:
    (String(1e7) + // 10000000 +
    String(-1e3) + // -1000 +
    String(-4e3) + // -4000 +
    String(-8e3) + // -80000000 +
    String(-1e11)).replace(
      // replacing
      /[018]/g,
      // zeroes, ones, and eights with
      UUID
    )
  );
};
var hex = __spreadArray([], __read$1(Array(256).keys()), false).map(function(index) {
  return index.toString(16).padStart(2, "0");
});
var UUID = function(a) {
  var _a;
  var globalScope = getGlobalScope$1();
  if (!((_a = globalScope === null || globalScope === void 0 ? void 0 : globalScope.crypto) === null || _a === void 0 ? void 0 : _a.getRandomValues)) {
    return legacyUUID(a);
  }
  var r = globalScope.crypto.getRandomValues(new Uint8Array(16));
  r[6] = r[6] & 15 | 64;
  r[8] = r[8] & 63 | 128;
  return __spreadArray([], __read$1(r.entries()), false).map(function(_a2) {
    var _b = __read$1(_a2, 2), index = _b[0], int = _b[1];
    return [4, 6, 8, 10].includes(index) ? "-".concat(hex[int]) : hex[int];
  }).join("");
};
var Timeline = (
  /** @class */
  function() {
    function Timeline2(client2) {
      this.client = client2;
      this.queue = [];
      this.applying = false;
      this.plugins = [];
    }
    Timeline2.prototype.register = function(plugin, config2) {
      var _a, _b;
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_c) {
          switch (_c.label) {
            case 0:
              if (this.plugins.some(function(existingPlugin) {
                return existingPlugin.name === plugin.name;
              })) {
                config2.loggerProvider.warn("Plugin with name ".concat(plugin.name, " already exists, skipping registration"));
                return [
                  2
                  /*return*/
                ];
              }
              if (plugin.name === void 0) {
                plugin.name = UUID();
                config2.loggerProvider.warn("Plugin name is undefined. \n      Generating a random UUID for plugin name: ".concat(plugin.name, ". \n      Set a name for the plugin to prevent it from being added multiple times."));
              }
              plugin.type = (_a = plugin.type) !== null && _a !== void 0 ? _a : "enrichment";
              return [4, (_b = plugin.setup) === null || _b === void 0 ? void 0 : _b.call(plugin, config2, this.client)];
            case 1:
              _c.sent();
              this.plugins.push(plugin);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    Timeline2.prototype.deregister = function(pluginName, config2) {
      var _a;
      return __awaiter(this, void 0, void 0, function() {
        var index, plugin;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              index = this.plugins.findIndex(function(plugin2) {
                return plugin2.name === pluginName;
              });
              if (index === -1) {
                config2.loggerProvider.warn("Plugin with name ".concat(pluginName, " does not exist, skipping deregistration"));
                return [
                  2
                  /*return*/
                ];
              }
              plugin = this.plugins[index];
              this.plugins.splice(index, 1);
              return [4, (_a = plugin.teardown) === null || _a === void 0 ? void 0 : _a.call(plugin)];
            case 1:
              _b.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    Timeline2.prototype.reset = function(client2) {
      this.applying = false;
      var plugins = this.plugins;
      plugins.map(function(plugin) {
        var _a;
        return (_a = plugin.teardown) === null || _a === void 0 ? void 0 : _a.call(plugin);
      });
      this.plugins = [];
      this.client = client2;
    };
    Timeline2.prototype.push = function(event) {
      var _this = this;
      return new Promise(function(resolve) {
        _this.queue.push([event, resolve]);
        _this.scheduleApply(0);
      });
    };
    Timeline2.prototype.scheduleApply = function(timeout2) {
      var _this = this;
      if (this.applying)
        return;
      this.applying = true;
      setTimeout(function() {
        void _this.apply(_this.queue.shift()).then(function() {
          _this.applying = false;
          if (_this.queue.length > 0) {
            _this.scheduleApply(0);
          }
        });
      }, timeout2);
    };
    Timeline2.prototype.apply = function(item) {
      return __awaiter(this, void 0, void 0, function() {
        var _a, event, _b, resolve, before, before_1, before_1_1, plugin, e, e_1_1, enrichment, enrichment_1, enrichment_1_1, plugin, e, e_2_1, destination, executeDestinations;
        var e_1, _c, e_2, _d;
        return __generator(this, function(_e) {
          switch (_e.label) {
            case 0:
              if (!item) {
                return [
                  2
                  /*return*/
                ];
              }
              _a = __read$1(item, 1), event = _a[0];
              _b = __read$1(item, 2), resolve = _b[1];
              before = this.plugins.filter(function(plugin2) {
                return plugin2.type === "before";
              });
              _e.label = 1;
            case 1:
              _e.trys.push([1, 6, 7, 8]);
              before_1 = __values$1(before), before_1_1 = before_1.next();
              _e.label = 2;
            case 2:
              if (!!before_1_1.done) return [3, 5];
              plugin = before_1_1.value;
              if (!plugin.execute) {
                return [3, 4];
              }
              return [4, plugin.execute(__assign$1({}, event))];
            case 3:
              e = _e.sent();
              if (e === null) {
                resolve({ event, code: 0, message: "" });
                return [
                  2
                  /*return*/
                ];
              } else {
                event = e;
              }
              _e.label = 4;
            case 4:
              before_1_1 = before_1.next();
              return [3, 2];
            case 5:
              return [3, 8];
            case 6:
              e_1_1 = _e.sent();
              e_1 = { error: e_1_1 };
              return [3, 8];
            case 7:
              try {
                if (before_1_1 && !before_1_1.done && (_c = before_1.return)) _c.call(before_1);
              } finally {
                if (e_1) throw e_1.error;
              }
              return [
                7
                /*endfinally*/
              ];
            case 8:
              enrichment = this.plugins.filter(function(plugin2) {
                return plugin2.type === "enrichment" || plugin2.type === void 0;
              });
              _e.label = 9;
            case 9:
              _e.trys.push([9, 14, 15, 16]);
              enrichment_1 = __values$1(enrichment), enrichment_1_1 = enrichment_1.next();
              _e.label = 10;
            case 10:
              if (!!enrichment_1_1.done) return [3, 13];
              plugin = enrichment_1_1.value;
              if (!plugin.execute) {
                return [3, 12];
              }
              return [4, plugin.execute(__assign$1({}, event))];
            case 11:
              e = _e.sent();
              if (e === null) {
                resolve({ event, code: 0, message: "" });
                return [
                  2
                  /*return*/
                ];
              } else {
                event = e;
              }
              _e.label = 12;
            case 12:
              enrichment_1_1 = enrichment_1.next();
              return [3, 10];
            case 13:
              return [3, 16];
            case 14:
              e_2_1 = _e.sent();
              e_2 = { error: e_2_1 };
              return [3, 16];
            case 15:
              try {
                if (enrichment_1_1 && !enrichment_1_1.done && (_d = enrichment_1.return)) _d.call(enrichment_1);
              } finally {
                if (e_2) throw e_2.error;
              }
              return [
                7
                /*endfinally*/
              ];
            case 16:
              destination = this.plugins.filter(function(plugin2) {
                return plugin2.type === "destination";
              });
              executeDestinations = destination.map(function(plugin2) {
                var eventClone = __assign$1({}, event);
                return plugin2.execute(eventClone).catch(function(e2) {
                  return buildResult(eventClone, 0, String(e2));
                });
              });
              void Promise.all(executeDestinations).then(function(_a2) {
                var _b2 = __read$1(_a2, 1), result = _b2[0];
                var resolveResult = result || buildResult(event, 100, "Event not tracked, no destination plugins on the instance");
                resolve(resolveResult);
              });
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    Timeline2.prototype.flush = function() {
      return __awaiter(this, void 0, void 0, function() {
        var queue, destination, executeDestinations;
        var _this = this;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              queue = this.queue;
              this.queue = [];
              return [4, Promise.all(queue.map(function(item) {
                return _this.apply(item);
              }))];
            case 1:
              _a.sent();
              destination = this.plugins.filter(function(plugin) {
                return plugin.type === "destination";
              });
              executeDestinations = destination.map(function(plugin) {
                return plugin.flush && plugin.flush();
              });
              return [4, Promise.all(executeDestinations)];
            case 2:
              _a.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    Timeline2.prototype.onIdentityChanged = function(identity2) {
      this.plugins.forEach(function(plugin) {
        var _a;
        void ((_a = plugin.onIdentityChanged) === null || _a === void 0 ? void 0 : _a.call(plugin, identity2));
      });
    };
    Timeline2.prototype.onSessionIdChanged = function(sessionId) {
      this.plugins.forEach(function(plugin) {
        var _a;
        void ((_a = plugin.onSessionIdChanged) === null || _a === void 0 ? void 0 : _a.call(plugin, sessionId));
      });
    };
    Timeline2.prototype.onOptOutChanged = function(optOut) {
      this.plugins.forEach(function(plugin) {
        var _a;
        void ((_a = plugin.onOptOutChanged) === null || _a === void 0 ? void 0 : _a.call(plugin, optOut));
      });
    };
    return Timeline2;
  }()
);
var createTrackEvent = function(eventInput, eventProperties, eventOptions) {
  var baseEvent = typeof eventInput === "string" ? { event_type: eventInput } : eventInput;
  return __assign$1(__assign$1(__assign$1({}, baseEvent), eventOptions), eventProperties && { event_properties: eventProperties });
};
var createIdentifyEvent = function(identify2, eventOptions) {
  var identifyEvent = __assign$1(__assign$1({}, eventOptions), { event_type: SpecialEventType$1.IDENTIFY, user_properties: identify2.getUserProperties() });
  return identifyEvent;
};
var createGroupIdentifyEvent = function(groupType, groupName, identify2, eventOptions) {
  var _a;
  var groupIdentify = __assign$1(__assign$1({}, eventOptions), { event_type: SpecialEventType$1.GROUP_IDENTIFY, group_properties: identify2.getUserProperties(), groups: (_a = {}, _a[groupType] = groupName, _a) });
  return groupIdentify;
};
var createGroupEvent = function(groupType, groupName, eventOptions) {
  var _a;
  var identify2 = new Identify();
  identify2.set(groupType, groupName);
  var groupEvent = __assign$1(__assign$1({}, eventOptions), { event_type: SpecialEventType$1.IDENTIFY, user_properties: identify2.getUserProperties(), groups: (_a = {}, _a[groupType] = groupName, _a) });
  return groupEvent;
};
var createRevenueEvent = function(revenue, eventOptions) {
  return __assign$1(__assign$1({}, eventOptions), { event_type: SpecialEventType$1.REVENUE, event_properties: revenue.getEventProperties() });
};
var returnWrapper = function(awaitable) {
  return {
    promise: awaitable || Promise.resolve()
  };
};
var AmplitudeCore = (
  /** @class */
  function() {
    function AmplitudeCore2(name) {
      if (name === void 0) {
        name = "$default";
      }
      this.initializing = false;
      this.isReady = false;
      this.q = [];
      this.dispatchQ = [];
      this.logEvent = this.track.bind(this);
      this.timeline = new Timeline(this);
      this.name = name;
    }
    AmplitudeCore2.prototype._init = function(config2) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              this.config = config2;
              this.timeline.reset(this);
              return [4, this.runQueuedFunctions("q")];
            case 1:
              _a.sent();
              this.isReady = true;
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    AmplitudeCore2.prototype.runQueuedFunctions = function(queueName) {
      return __awaiter(this, void 0, void 0, function() {
        var queuedFunctions, queuedFunctions_1, queuedFunctions_1_1, queuedFunction, val, e_1_1;
        var e_1, _a;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              queuedFunctions = this[queueName];
              this[queueName] = [];
              _b.label = 1;
            case 1:
              _b.trys.push([1, 8, 9, 10]);
              queuedFunctions_1 = __values$1(queuedFunctions), queuedFunctions_1_1 = queuedFunctions_1.next();
              _b.label = 2;
            case 2:
              if (!!queuedFunctions_1_1.done) return [3, 7];
              queuedFunction = queuedFunctions_1_1.value;
              val = queuedFunction();
              if (!(val && "promise" in val)) return [3, 4];
              return [4, val.promise];
            case 3:
              _b.sent();
              return [3, 6];
            case 4:
              return [4, val];
            case 5:
              _b.sent();
              _b.label = 6;
            case 6:
              queuedFunctions_1_1 = queuedFunctions_1.next();
              return [3, 2];
            case 7:
              return [3, 10];
            case 8:
              e_1_1 = _b.sent();
              e_1 = { error: e_1_1 };
              return [3, 10];
            case 9:
              try {
                if (queuedFunctions_1_1 && !queuedFunctions_1_1.done && (_a = queuedFunctions_1.return)) _a.call(queuedFunctions_1);
              } finally {
                if (e_1) throw e_1.error;
              }
              return [
                7
                /*endfinally*/
              ];
            case 10:
              if (!this[queueName].length) return [3, 12];
              return [4, this.runQueuedFunctions(queueName)];
            case 11:
              _b.sent();
              _b.label = 12;
            case 12:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    AmplitudeCore2.prototype.track = function(eventInput, eventProperties, eventOptions) {
      var event = createTrackEvent(eventInput, eventProperties, eventOptions);
      return returnWrapper(this.dispatch(event));
    };
    AmplitudeCore2.prototype.identify = function(identify2, eventOptions) {
      var event = createIdentifyEvent(identify2, eventOptions);
      return returnWrapper(this.dispatch(event));
    };
    AmplitudeCore2.prototype.groupIdentify = function(groupType, groupName, identify2, eventOptions) {
      var event = createGroupIdentifyEvent(groupType, groupName, identify2, eventOptions);
      return returnWrapper(this.dispatch(event));
    };
    AmplitudeCore2.prototype.setGroup = function(groupType, groupName, eventOptions) {
      var event = createGroupEvent(groupType, groupName, eventOptions);
      return returnWrapper(this.dispatch(event));
    };
    AmplitudeCore2.prototype.revenue = function(revenue, eventOptions) {
      var event = createRevenueEvent(revenue, eventOptions);
      return returnWrapper(this.dispatch(event));
    };
    AmplitudeCore2.prototype.add = function(plugin) {
      if (!this.isReady) {
        this.q.push(this._addPlugin.bind(this, plugin));
        return returnWrapper();
      }
      return this._addPlugin(plugin);
    };
    AmplitudeCore2.prototype._addPlugin = function(plugin) {
      return returnWrapper(this.timeline.register(plugin, this.config));
    };
    AmplitudeCore2.prototype.remove = function(pluginName) {
      if (!this.isReady) {
        this.q.push(this._removePlugin.bind(this, pluginName));
        return returnWrapper();
      }
      return this._removePlugin(pluginName);
    };
    AmplitudeCore2.prototype._removePlugin = function(pluginName) {
      return returnWrapper(this.timeline.deregister(pluginName, this.config));
    };
    AmplitudeCore2.prototype.dispatchWithCallback = function(event, callback) {
      if (!this.isReady) {
        return callback(buildResult(event, 0, CLIENT_NOT_INITIALIZED));
      }
      void this.process(event).then(callback);
    };
    AmplitudeCore2.prototype.dispatch = function(event) {
      return __awaiter(this, void 0, void 0, function() {
        var _this = this;
        return __generator(this, function(_a) {
          if (!this.isReady) {
            return [2, new Promise(function(resolve) {
              _this.dispatchQ.push(_this.dispatchWithCallback.bind(_this, event, resolve));
            })];
          }
          return [2, this.process(event)];
        });
      });
    };
    AmplitudeCore2.prototype.getOperationAppliedUserProperties = function(userProperties) {
      var updatedProperties = {};
      if (userProperties === void 0) {
        return updatedProperties;
      }
      var nonOpProperties = {};
      Object.keys(userProperties).forEach(function(key) {
        if (!Object.values(IdentifyOperation$2).includes(key)) {
          nonOpProperties[key] = userProperties[key];
        }
      });
      OrderedIdentifyOperations.forEach(function(operation) {
        if (!Object.keys(userProperties).includes(operation))
          return;
        var opProperties = userProperties[operation];
        switch (operation) {
          case IdentifyOperation$2.CLEAR_ALL:
            Object.keys(updatedProperties).forEach(function(prop) {
              delete updatedProperties[prop];
            });
            break;
          case IdentifyOperation$2.UNSET:
            Object.keys(opProperties).forEach(function(prop) {
              delete updatedProperties[prop];
            });
            break;
          case IdentifyOperation$2.SET:
            Object.assign(updatedProperties, opProperties);
            break;
        }
      });
      Object.assign(updatedProperties, nonOpProperties);
      return updatedProperties;
    };
    AmplitudeCore2.prototype.process = function(event) {
      return __awaiter(this, void 0, void 0, function() {
        var userProperties, result, e_2, message, result;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              _a.trys.push([0, 2, , 3]);
              if (this.config.optOut) {
                return [2, buildResult(event, 0, OPT_OUT_MESSAGE)];
              }
              if (event.event_type === SpecialEventType$1.IDENTIFY) {
                userProperties = this.getOperationAppliedUserProperties(event.user_properties);
                this.timeline.onIdentityChanged({ userProperties });
              }
              return [4, this.timeline.push(event)];
            case 1:
              result = _a.sent();
              result.code === 200 ? this.config.loggerProvider.log(result.message) : result.code === 100 ? this.config.loggerProvider.warn(result.message) : this.config.loggerProvider.error(result.message);
              return [2, result];
            case 2:
              e_2 = _a.sent();
              message = String(e_2);
              this.config.loggerProvider.error(message);
              result = buildResult(event, 0, message);
              return [2, result];
            case 3:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    AmplitudeCore2.prototype.setOptOut = function(optOut) {
      if (!this.isReady) {
        this.q.push(this._setOptOut.bind(this, Boolean(optOut)));
        return;
      }
      this._setOptOut(optOut);
    };
    AmplitudeCore2.prototype._setOptOut = function(optOut) {
      if (this.config.optOut !== optOut) {
        this.timeline.onOptOutChanged(optOut);
        this.config.optOut = Boolean(optOut);
      }
    };
    AmplitudeCore2.prototype.flush = function() {
      return returnWrapper(this.timeline.flush());
    };
    AmplitudeCore2.prototype.plugin = function(name) {
      var plugin = this.timeline.plugins.find(function(plugin2) {
        return plugin2.name === name;
      });
      if (plugin === void 0) {
        this.config.loggerProvider.debug("Cannot find plugin with name ".concat(name));
        return void 0;
      }
      return plugin;
    };
    AmplitudeCore2.prototype.plugins = function(pluginClass) {
      return this.timeline.plugins.filter(function(plugin) {
        return plugin instanceof pluginClass;
      });
    };
    return AmplitudeCore2;
  }()
);
var Revenue = (
  /** @class */
  function() {
    function Revenue2() {
      this.productId = "";
      this.quantity = 1;
      this.price = 0;
    }
    Revenue2.prototype.setProductId = function(productId) {
      this.productId = productId;
      return this;
    };
    Revenue2.prototype.setQuantity = function(quantity) {
      if (quantity > 0) {
        this.quantity = quantity;
      }
      return this;
    };
    Revenue2.prototype.setPrice = function(price) {
      this.price = price;
      return this;
    };
    Revenue2.prototype.setRevenueType = function(revenueType) {
      this.revenueType = revenueType;
      return this;
    };
    Revenue2.prototype.setCurrency = function(currency) {
      this.currency = currency;
      return this;
    };
    Revenue2.prototype.setRevenue = function(revenue) {
      this.revenue = revenue;
      return this;
    };
    Revenue2.prototype.setReceipt = function(receipt) {
      this.receipt = receipt;
      return this;
    };
    Revenue2.prototype.setReceiptSig = function(receiptSig) {
      this.receiptSig = receiptSig;
      return this;
    };
    Revenue2.prototype.setEventProperties = function(properties) {
      if (isValidObject(properties)) {
        this.properties = properties;
      }
      return this;
    };
    Revenue2.prototype.getEventProperties = function() {
      var eventProperties = this.properties ? __assign$1({}, this.properties) : {};
      eventProperties[RevenueProperty$1.REVENUE_PRODUCT_ID] = this.productId;
      eventProperties[RevenueProperty$1.REVENUE_QUANTITY] = this.quantity;
      eventProperties[RevenueProperty$1.REVENUE_PRICE] = this.price;
      eventProperties[RevenueProperty$1.REVENUE_TYPE] = this.revenueType;
      eventProperties[RevenueProperty$1.REVENUE_CURRENCY] = this.currency;
      eventProperties[RevenueProperty$1.REVENUE] = this.revenue;
      eventProperties[RevenueProperty$1.RECEIPT] = this.receipt;
      eventProperties[RevenueProperty$1.RECEIPT_SIG] = this.receiptSig;
      return eventProperties;
    };
    return Revenue2;
  }()
);
var RevenueProperty$1;
(function(RevenueProperty2) {
  RevenueProperty2["REVENUE_PRODUCT_ID"] = "$productId";
  RevenueProperty2["REVENUE_QUANTITY"] = "$quantity";
  RevenueProperty2["REVENUE_PRICE"] = "$price";
  RevenueProperty2["REVENUE_TYPE"] = "$revenueType";
  RevenueProperty2["REVENUE_CURRENCY"] = "$currency";
  RevenueProperty2["REVENUE"] = "$revenue";
  RevenueProperty2["RECEIPT"] = "$receipt";
  RevenueProperty2["RECEIPT_SIG"] = "$receiptSig";
})(RevenueProperty$1 || (RevenueProperty$1 = {}));
var chunk = function(arr, size) {
  var chunkSize = Math.max(size, 1);
  return arr.reduce(function(chunks, element, index) {
    var chunkIndex = Math.floor(index / chunkSize);
    if (!chunks[chunkIndex]) {
      chunks[chunkIndex] = [];
    }
    chunks[chunkIndex].push(element);
    return chunks;
  }, []);
};
var LogLevel;
(function(LogLevel2) {
  LogLevel2[LogLevel2["None"] = 0] = "None";
  LogLevel2[LogLevel2["Error"] = 1] = "Error";
  LogLevel2[LogLevel2["Warn"] = 2] = "Warn";
  LogLevel2[LogLevel2["Verbose"] = 3] = "Verbose";
  LogLevel2[LogLevel2["Debug"] = 4] = "Debug";
})(LogLevel || (LogLevel = {}));
var PREFIX = "Amplitude Logger ";
var Logger = (
  /** @class */
  function() {
    function Logger2() {
      this.logLevel = LogLevel.None;
    }
    Logger2.prototype.disable = function() {
      this.logLevel = LogLevel.None;
    };
    Logger2.prototype.enable = function(logLevel) {
      if (logLevel === void 0) {
        logLevel = LogLevel.Warn;
      }
      this.logLevel = logLevel;
    };
    Logger2.prototype.log = function() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      if (this.logLevel < LogLevel.Verbose) {
        return;
      }
      console.log("".concat(PREFIX, "[Log]: ").concat(args.join(" ")));
    };
    Logger2.prototype.warn = function() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      if (this.logLevel < LogLevel.Warn) {
        return;
      }
      console.warn("".concat(PREFIX, "[Warn]: ").concat(args.join(" ")));
    };
    Logger2.prototype.error = function() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      if (this.logLevel < LogLevel.Error) {
        return;
      }
      console.error("".concat(PREFIX, "[Error]: ").concat(args.join(" ")));
    };
    Logger2.prototype.debug = function() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      if (this.logLevel < LogLevel.Debug) {
        return;
      }
      console.log("".concat(PREFIX, "[Debug]: ").concat(args.join(" ")));
    };
    return Logger2;
  }()
);
var getDefaultConfig = function() {
  return {
    flushMaxRetries: 12,
    flushQueueSize: 200,
    flushIntervalMillis: 1e4,
    instanceName: "$default_instance",
    logLevel: LogLevel.Warn,
    loggerProvider: new Logger(),
    offline: false,
    optOut: false,
    serverUrl: AMPLITUDE_SERVER_URL,
    serverZone: "US",
    useBatch: false
  };
};
var Config = (
  /** @class */
  function() {
    function Config2(options) {
      var _a, _b, _c, _d;
      this._optOut = false;
      var defaultConfig = getDefaultConfig();
      this.apiKey = options.apiKey;
      this.flushIntervalMillis = (_a = options.flushIntervalMillis) !== null && _a !== void 0 ? _a : defaultConfig.flushIntervalMillis;
      this.flushMaxRetries = options.flushMaxRetries || defaultConfig.flushMaxRetries;
      this.flushQueueSize = options.flushQueueSize || defaultConfig.flushQueueSize;
      this.instanceName = options.instanceName || defaultConfig.instanceName;
      this.loggerProvider = options.loggerProvider || defaultConfig.loggerProvider;
      this.logLevel = (_b = options.logLevel) !== null && _b !== void 0 ? _b : defaultConfig.logLevel;
      this.minIdLength = options.minIdLength;
      this.plan = options.plan;
      this.ingestionMetadata = options.ingestionMetadata;
      this.offline = options.offline !== void 0 ? options.offline : defaultConfig.offline;
      this.optOut = (_c = options.optOut) !== null && _c !== void 0 ? _c : defaultConfig.optOut;
      this.serverUrl = options.serverUrl;
      this.serverZone = options.serverZone || defaultConfig.serverZone;
      this.storageProvider = options.storageProvider;
      this.transportProvider = options.transportProvider;
      this.useBatch = (_d = options.useBatch) !== null && _d !== void 0 ? _d : defaultConfig.useBatch;
      this.loggerProvider.enable(this.logLevel);
      var serverConfig = createServerConfig(options.serverUrl, options.serverZone, options.useBatch);
      this.serverZone = serverConfig.serverZone;
      this.serverUrl = serverConfig.serverUrl;
    }
    Object.defineProperty(Config2.prototype, "optOut", {
      get: function() {
        return this._optOut;
      },
      set: function(optOut) {
        this._optOut = optOut;
      },
      enumerable: false,
      configurable: true
    });
    return Config2;
  }()
);
var getServerUrl = function(serverZone, useBatch) {
  if (serverZone === "EU") {
    return useBatch ? EU_AMPLITUDE_BATCH_SERVER_URL : EU_AMPLITUDE_SERVER_URL;
  }
  return useBatch ? AMPLITUDE_BATCH_SERVER_URL : AMPLITUDE_SERVER_URL;
};
var createServerConfig = function(serverUrl, serverZone, useBatch) {
  if (serverUrl === void 0) {
    serverUrl = "";
  }
  if (serverZone === void 0) {
    serverZone = getDefaultConfig().serverZone;
  }
  if (useBatch === void 0) {
    useBatch = getDefaultConfig().useBatch;
  }
  if (serverUrl) {
    return { serverUrl, serverZone: void 0 };
  }
  var _serverZone = ["US", "EU"].includes(serverZone) ? serverZone : getDefaultConfig().serverZone;
  return {
    serverZone: _serverZone,
    serverUrl: getServerUrl(_serverZone, useBatch)
  };
};
var RequestMetadata = (
  /** @class */
  function() {
    function RequestMetadata2() {
      this.sdk = {
        metrics: {
          histogram: {}
        }
      };
    }
    RequestMetadata2.prototype.recordHistogram = function(key, value) {
      this.sdk.metrics.histogram[key] = value;
    };
    return RequestMetadata2;
  }()
);
function getErrorMessage(error) {
  if (error instanceof Error)
    return error.message;
  return String(error);
}
function getResponseBodyString(res) {
  var responseBodyString = "";
  try {
    if ("body" in res) {
      responseBodyString = JSON.stringify(res.body, null, 2);
    }
  } catch (_a) {
  }
  return responseBodyString;
}
var Destination = (
  /** @class */
  function() {
    function Destination2() {
      this.name = "amplitude";
      this.type = "destination";
      this.retryTimeout = 1e3;
      this.throttleTimeout = 3e4;
      this.storageKey = "";
      this.scheduleId = null;
      this.scheduledTimeout = 0;
      this.flushId = null;
      this.queue = [];
    }
    Destination2.prototype.setup = function(config2) {
      var _a;
      return __awaiter(this, void 0, void 0, function() {
        var unsent;
        var _this = this;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              this.config = config2;
              this.storageKey = "".concat(STORAGE_PREFIX, "_").concat(this.config.apiKey.substring(0, 10));
              return [4, (_a = this.config.storageProvider) === null || _a === void 0 ? void 0 : _a.get(this.storageKey)];
            case 1:
              unsent = _b.sent();
              if (unsent && unsent.length > 0) {
                void Promise.all(unsent.map(function(event) {
                  return _this.execute(event);
                })).catch();
              }
              return [2, Promise.resolve(void 0)];
          }
        });
      });
    };
    Destination2.prototype.execute = function(event) {
      var _this = this;
      if (!event.insert_id) {
        event.insert_id = UUID();
      }
      return new Promise(function(resolve) {
        var context = {
          event,
          attempts: 0,
          callback: function(result) {
            return resolve(result);
          },
          timeout: 0
        };
        _this.queue.push(context);
        _this.schedule(_this.config.flushIntervalMillis);
        _this.saveEvents();
      });
    };
    Destination2.prototype.removeEventsExceedFlushMaxRetries = function(list) {
      var _this = this;
      return list.filter(function(context) {
        context.attempts += 1;
        if (context.attempts < _this.config.flushMaxRetries) {
          return true;
        }
        void _this.fulfillRequest([context], 500, MAX_RETRIES_EXCEEDED_MESSAGE$1);
        return false;
      });
    };
    Destination2.prototype.scheduleEvents = function(list) {
      var _this = this;
      list.forEach(function(context) {
        _this.schedule(context.timeout === 0 ? _this.config.flushIntervalMillis : context.timeout);
      });
    };
    Destination2.prototype.schedule = function(timeout2) {
      var _this = this;
      if (this.config.offline) {
        return;
      }
      if (this.scheduleId === null || this.scheduleId && timeout2 > this.scheduledTimeout) {
        if (this.scheduleId) {
          clearTimeout(this.scheduleId);
        }
        this.scheduledTimeout = timeout2;
        this.scheduleId = setTimeout(function() {
          _this.queue = _this.queue.map(function(context) {
            context.timeout = 0;
            return context;
          });
          void _this.flush(true);
        }, timeout2);
        return;
      }
    };
    Destination2.prototype.resetSchedule = function() {
      this.scheduleId = null;
      this.scheduledTimeout = 0;
    };
    Destination2.prototype.flush = function(useRetry) {
      if (useRetry === void 0) {
        useRetry = false;
      }
      return __awaiter(this, void 0, void 0, function() {
        var list, later, batches;
        var _this = this;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              if (this.config.offline) {
                this.resetSchedule();
                this.config.loggerProvider.debug("Skipping flush while offline.");
                return [
                  2
                  /*return*/
                ];
              }
              if (this.flushId) {
                this.resetSchedule();
                this.config.loggerProvider.debug("Skipping flush because previous flush has not resolved.");
                return [
                  2
                  /*return*/
                ];
              }
              this.flushId = this.scheduleId;
              this.resetSchedule();
              list = [];
              later = [];
              this.queue.forEach(function(context) {
                return context.timeout === 0 ? list.push(context) : later.push(context);
              });
              batches = chunk(list, this.config.flushQueueSize);
              return [4, batches.reduce(function(promise, batch) {
                return __awaiter(_this, void 0, void 0, function() {
                  return __generator(this, function(_a2) {
                    switch (_a2.label) {
                      case 0:
                        return [4, promise];
                      case 1:
                        _a2.sent();
                        return [4, this.send(batch, useRetry)];
                      case 2:
                        return [2, _a2.sent()];
                    }
                  });
                });
              }, Promise.resolve())];
            case 1:
              _a.sent();
              this.flushId = null;
              this.scheduleEvents(this.queue);
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    Destination2.prototype.send = function(list, useRetry) {
      if (useRetry === void 0) {
        useRetry = true;
      }
      return __awaiter(this, void 0, void 0, function() {
        var payload, serverUrl, res, e_1, errorMessage;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              if (!this.config.apiKey) {
                return [2, this.fulfillRequest(list, 400, MISSING_API_KEY_MESSAGE)];
              }
              payload = {
                api_key: this.config.apiKey,
                events: list.map(function(context) {
                  var _a2 = context.event;
                  _a2.extra;
                  var eventWithoutExtra = __rest(_a2, ["extra"]);
                  return eventWithoutExtra;
                }),
                options: {
                  min_id_length: this.config.minIdLength
                },
                client_upload_time: (/* @__PURE__ */ new Date()).toISOString(),
                request_metadata: this.config.requestMetadata
              };
              this.config.requestMetadata = new RequestMetadata();
              _a.label = 1;
            case 1:
              _a.trys.push([1, 3, , 4]);
              serverUrl = createServerConfig(this.config.serverUrl, this.config.serverZone, this.config.useBatch).serverUrl;
              return [4, this.config.transportProvider.send(serverUrl, payload)];
            case 2:
              res = _a.sent();
              if (res === null) {
                this.fulfillRequest(list, 0, UNEXPECTED_ERROR_MESSAGE$1);
                return [
                  2
                  /*return*/
                ];
              }
              if (!useRetry) {
                if ("body" in res) {
                  this.fulfillRequest(list, res.statusCode, "".concat(res.status, ": ").concat(getResponseBodyString(res)));
                } else {
                  this.fulfillRequest(list, res.statusCode, res.status);
                }
                return [
                  2
                  /*return*/
                ];
              }
              this.handleResponse(res, list);
              return [3, 4];
            case 3:
              e_1 = _a.sent();
              errorMessage = getErrorMessage(e_1);
              this.config.loggerProvider.error(errorMessage);
              this.handleResponse({ status: Status$1.Failed, statusCode: 0 }, list);
              return [3, 4];
            case 4:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    Destination2.prototype.handleResponse = function(res, list) {
      var status = res.status;
      switch (status) {
        case Status$1.Success: {
          this.handleSuccessResponse(res, list);
          break;
        }
        case Status$1.Invalid: {
          this.handleInvalidResponse(res, list);
          break;
        }
        case Status$1.PayloadTooLarge: {
          this.handlePayloadTooLargeResponse(res, list);
          break;
        }
        case Status$1.RateLimit: {
          this.handleRateLimitResponse(res, list);
          break;
        }
        default: {
          this.config.loggerProvider.warn(`{code: 0, error: "Status '`.concat(status, "' provided for ").concat(list.length, ' events"}'));
          this.handleOtherResponse(list);
          break;
        }
      }
    };
    Destination2.prototype.handleSuccessResponse = function(res, list) {
      this.fulfillRequest(list, res.statusCode, SUCCESS_MESSAGE);
    };
    Destination2.prototype.handleInvalidResponse = function(res, list) {
      var _this = this;
      if (res.body.missingField || res.body.error.startsWith(INVALID_API_KEY)) {
        this.fulfillRequest(list, res.statusCode, res.body.error);
        return;
      }
      var dropIndex = __spreadArray(__spreadArray(__spreadArray(__spreadArray([], __read$1(Object.values(res.body.eventsWithInvalidFields)), false), __read$1(Object.values(res.body.eventsWithMissingFields)), false), __read$1(Object.values(res.body.eventsWithInvalidIdLengths)), false), __read$1(res.body.silencedEvents), false).flat();
      var dropIndexSet = new Set(dropIndex);
      var retry = list.filter(function(context, index) {
        if (dropIndexSet.has(index)) {
          _this.fulfillRequest([context], res.statusCode, res.body.error);
          return;
        }
        return true;
      });
      if (retry.length > 0) {
        this.config.loggerProvider.warn(getResponseBodyString(res));
      }
      var tryable = this.removeEventsExceedFlushMaxRetries(retry);
      this.scheduleEvents(tryable);
    };
    Destination2.prototype.handlePayloadTooLargeResponse = function(res, list) {
      if (list.length === 1) {
        this.fulfillRequest(list, res.statusCode, res.body.error);
        return;
      }
      this.config.loggerProvider.warn(getResponseBodyString(res));
      this.config.flushQueueSize /= 2;
      var tryable = this.removeEventsExceedFlushMaxRetries(list);
      this.scheduleEvents(tryable);
    };
    Destination2.prototype.handleRateLimitResponse = function(res, list) {
      var _this = this;
      var dropUserIds = Object.keys(res.body.exceededDailyQuotaUsers);
      var dropDeviceIds = Object.keys(res.body.exceededDailyQuotaDevices);
      var throttledIndex = res.body.throttledEvents;
      var dropUserIdsSet = new Set(dropUserIds);
      var dropDeviceIdsSet = new Set(dropDeviceIds);
      var throttledIndexSet = new Set(throttledIndex);
      var retry = list.filter(function(context, index) {
        if (context.event.user_id && dropUserIdsSet.has(context.event.user_id) || context.event.device_id && dropDeviceIdsSet.has(context.event.device_id)) {
          _this.fulfillRequest([context], res.statusCode, res.body.error);
          return;
        }
        if (throttledIndexSet.has(index)) {
          context.timeout = _this.throttleTimeout;
        }
        return true;
      });
      if (retry.length > 0) {
        this.config.loggerProvider.warn(getResponseBodyString(res));
      }
      var tryable = this.removeEventsExceedFlushMaxRetries(retry);
      this.scheduleEvents(tryable);
    };
    Destination2.prototype.handleOtherResponse = function(list) {
      var _this = this;
      var later = list.map(function(context) {
        context.timeout = context.attempts * _this.retryTimeout;
        return context;
      });
      var tryable = this.removeEventsExceedFlushMaxRetries(later);
      this.scheduleEvents(tryable);
    };
    Destination2.prototype.fulfillRequest = function(list, code, message) {
      this.removeEvents(list);
      list.forEach(function(context) {
        return context.callback(buildResult(context.event, code, message));
      });
    };
    Destination2.prototype.saveEvents = function() {
      if (!this.config.storageProvider) {
        return;
      }
      var updatedEvents = this.queue.map(function(context) {
        return context.event;
      });
      void this.config.storageProvider.set(this.storageKey, updatedEvents);
    };
    Destination2.prototype.removeEvents = function(eventsToRemove) {
      this.queue = this.queue.filter(function(queuedContext) {
        return !eventsToRemove.some(function(context) {
          return context.event.insert_id === queuedContext.event.insert_id;
        });
      });
      this.saveEvents();
    };
    return Destination2;
  }()
);
var ApplicationContextProviderImpl = (
  /** @class */
  function() {
    function ApplicationContextProviderImpl2() {
    }
    ApplicationContextProviderImpl2.prototype.getApplicationContext = function() {
      return {
        versionName: this.versionName,
        language: getLanguage$1(),
        platform: "Web",
        os: void 0,
        deviceModel: void 0
      };
    };
    return ApplicationContextProviderImpl2;
  }()
);
var getLanguage$1 = function() {
  return typeof navigator !== "undefined" && (navigator.languages && navigator.languages[0] || navigator.language) || "";
};
var EventBridgeImpl = (
  /** @class */
  function() {
    function EventBridgeImpl2() {
      this.queue = [];
    }
    EventBridgeImpl2.prototype.logEvent = function(event) {
      if (!this.receiver) {
        if (this.queue.length < 512) {
          this.queue.push(event);
        }
      } else {
        this.receiver(event);
      }
    };
    EventBridgeImpl2.prototype.setEventReceiver = function(receiver) {
      this.receiver = receiver;
      if (this.queue.length > 0) {
        this.queue.forEach(function(event) {
          receiver(event);
        });
        this.queue = [];
      }
    };
    return EventBridgeImpl2;
  }()
);
var __assign = function() {
  __assign = Object.assign || function __assign2(t) {
    for (var s, i = 1, n = arguments.length; i < n; i++) {
      s = arguments[i];
      for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
    }
    return t;
  };
  return __assign.apply(this, arguments);
};
function __values(o) {
  var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
  if (m) return m.call(o);
  if (o && typeof o.length === "number") return {
    next: function() {
      if (o && i >= o.length) o = void 0;
      return {
        value: o && o[i++],
        done: !o
      };
    }
  };
  throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}
function __read(o, n) {
  var m = typeof Symbol === "function" && o[Symbol.iterator];
  if (!m) return o;
  var i = m.call(o), r, ar = [], e;
  try {
    while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
  } catch (error) {
    e = {
      error
    };
  } finally {
    try {
      if (r && !r.done && (m = i["return"])) m.call(i);
    } finally {
      if (e) throw e.error;
    }
  }
  return ar;
}
typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
  var e = new Error(message);
  return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
};
var isEqual = function(obj1, obj2) {
  var e_1, _a;
  var primitive = ["string", "number", "boolean", "undefined"];
  var typeA = typeof obj1;
  var typeB = typeof obj2;
  if (typeA !== typeB) {
    return false;
  }
  try {
    for (var primitive_1 = __values(primitive), primitive_1_1 = primitive_1.next(); !primitive_1_1.done; primitive_1_1 = primitive_1.next()) {
      var p = primitive_1_1.value;
      if (p === typeA) {
        return obj1 === obj2;
      }
    }
  } catch (e_1_1) {
    e_1 = { error: e_1_1 };
  } finally {
    try {
      if (primitive_1_1 && !primitive_1_1.done && (_a = primitive_1.return)) _a.call(primitive_1);
    } finally {
      if (e_1) throw e_1.error;
    }
  }
  if (obj1 == null && obj2 == null) {
    return true;
  } else if (obj1 == null || obj2 == null) {
    return false;
  }
  if (obj1.length !== obj2.length) {
    return false;
  }
  var isArrayA = Array.isArray(obj1);
  var isArrayB = Array.isArray(obj2);
  if (isArrayA !== isArrayB) {
    return false;
  }
  if (isArrayA && isArrayB) {
    for (var i = 0; i < obj1.length; i++) {
      if (!isEqual(obj1[i], obj2[i])) {
        return false;
      }
    }
  } else {
    var sorted1 = Object.keys(obj1).sort();
    var sorted2 = Object.keys(obj2).sort();
    if (!isEqual(sorted1, sorted2)) {
      return false;
    }
    var result_1 = true;
    Object.keys(obj1).forEach(function(key) {
      if (!isEqual(obj1[key], obj2[key])) {
        result_1 = false;
      }
    });
    return result_1;
  }
  return true;
};
var ID_OP_SET = "$set";
var ID_OP_UNSET = "$unset";
var ID_OP_CLEAR_ALL = "$clearAll";
if (!Object.entries) {
  Object.entries = function(obj) {
    var ownProps = Object.keys(obj);
    var i = ownProps.length;
    var resArray = new Array(i);
    while (i--) {
      resArray[i] = [ownProps[i], obj[ownProps[i]]];
    }
    return resArray;
  };
}
var IdentityStoreImpl = (
  /** @class */
  function() {
    function IdentityStoreImpl2() {
      this.identity = { userProperties: {} };
      this.listeners = /* @__PURE__ */ new Set();
    }
    IdentityStoreImpl2.prototype.editIdentity = function() {
      var self2 = this;
      var actingUserProperties = __assign({}, this.identity.userProperties);
      var actingIdentity = __assign(__assign({}, this.identity), { userProperties: actingUserProperties });
      return {
        setUserId: function(userId) {
          actingIdentity.userId = userId;
          return this;
        },
        setDeviceId: function(deviceId) {
          actingIdentity.deviceId = deviceId;
          return this;
        },
        setUserProperties: function(userProperties) {
          actingIdentity.userProperties = userProperties;
          return this;
        },
        setOptOut: function(optOut) {
          actingIdentity.optOut = optOut;
          return this;
        },
        updateUserProperties: function(actions) {
          var e_1, _a, e_2, _b, e_3, _c;
          var actingProperties = actingIdentity.userProperties || {};
          try {
            for (var _d = __values(Object.entries(actions)), _e = _d.next(); !_e.done; _e = _d.next()) {
              var _f = __read(_e.value, 2), action = _f[0], properties = _f[1];
              switch (action) {
                case ID_OP_SET:
                  try {
                    for (var _g = (e_2 = void 0, __values(Object.entries(properties))), _h = _g.next(); !_h.done; _h = _g.next()) {
                      var _j = __read(_h.value, 2), key = _j[0], value = _j[1];
                      actingProperties[key] = value;
                    }
                  } catch (e_2_1) {
                    e_2 = { error: e_2_1 };
                  } finally {
                    try {
                      if (_h && !_h.done && (_b = _g.return)) _b.call(_g);
                    } finally {
                      if (e_2) throw e_2.error;
                    }
                  }
                  break;
                case ID_OP_UNSET:
                  try {
                    for (var _k = (e_3 = void 0, __values(Object.keys(properties))), _l = _k.next(); !_l.done; _l = _k.next()) {
                      var key = _l.value;
                      delete actingProperties[key];
                    }
                  } catch (e_3_1) {
                    e_3 = { error: e_3_1 };
                  } finally {
                    try {
                      if (_l && !_l.done && (_c = _k.return)) _c.call(_k);
                    } finally {
                      if (e_3) throw e_3.error;
                    }
                  }
                  break;
                case ID_OP_CLEAR_ALL:
                  actingProperties = {};
                  break;
              }
            }
          } catch (e_1_1) {
            e_1 = { error: e_1_1 };
          } finally {
            try {
              if (_e && !_e.done && (_a = _d.return)) _a.call(_d);
            } finally {
              if (e_1) throw e_1.error;
            }
          }
          actingIdentity.userProperties = actingProperties;
          return this;
        },
        commit: function() {
          self2.setIdentity(actingIdentity);
          return this;
        }
      };
    };
    IdentityStoreImpl2.prototype.getIdentity = function() {
      return __assign({}, this.identity);
    };
    IdentityStoreImpl2.prototype.setIdentity = function(identity2) {
      var originalIdentity = __assign({}, this.identity);
      this.identity = __assign({}, identity2);
      if (!isEqual(originalIdentity, this.identity)) {
        this.listeners.forEach(function(listener) {
          listener(identity2);
        });
      }
    };
    IdentityStoreImpl2.prototype.addIdentityListener = function(listener) {
      this.listeners.add(listener);
    };
    IdentityStoreImpl2.prototype.removeIdentityListener = function(listener) {
      this.listeners.delete(listener);
    };
    return IdentityStoreImpl2;
  }()
);
var safeGlobal = typeof globalThis !== "undefined" ? globalThis : typeof global !== "undefined" ? global : self;
var AnalyticsConnector = (
  /** @class */
  function() {
    function AnalyticsConnector2() {
      this.identityStore = new IdentityStoreImpl();
      this.eventBridge = new EventBridgeImpl();
      this.applicationContextProvider = new ApplicationContextProviderImpl();
    }
    AnalyticsConnector2.getInstance = function(instanceName) {
      if (!safeGlobal["analyticsConnectorInstances"]) {
        safeGlobal["analyticsConnectorInstances"] = {};
      }
      if (!safeGlobal["analyticsConnectorInstances"][instanceName]) {
        safeGlobal["analyticsConnectorInstances"][instanceName] = new AnalyticsConnector2();
      }
      return safeGlobal["analyticsConnectorInstances"][instanceName];
    };
    return AnalyticsConnector2;
  }()
);
var getAnalyticsConnector = function(instanceName) {
  if (instanceName === void 0) {
    instanceName = "$default_instance";
  }
  return AnalyticsConnector.getInstance(instanceName);
};
var setConnectorUserId = function(userId, instanceName) {
  getAnalyticsConnector(instanceName).identityStore.editIdentity().setUserId(userId).commit();
};
var setConnectorDeviceId = function(deviceId, instanceName) {
  getAnalyticsConnector(instanceName).identityStore.editIdentity().setDeviceId(deviceId).commit();
};
var IdentityEventSender = (
  /** @class */
  function() {
    function IdentityEventSender2() {
      this.name = "identity";
      this.type = "before";
      this.identityStore = getAnalyticsConnector().identityStore;
    }
    IdentityEventSender2.prototype.execute = function(context) {
      return __awaiter(this, void 0, void 0, function() {
        var userProperties;
        return __generator(this, function(_a) {
          userProperties = context.user_properties;
          if (userProperties) {
            this.identityStore.editIdentity().updateUserProperties(userProperties).commit();
          }
          return [2, context];
        });
      });
    };
    IdentityEventSender2.prototype.setup = function(config2) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          if (config2.instanceName) {
            this.identityStore = getAnalyticsConnector(config2.instanceName).identityStore;
          }
          return [
            2
            /*return*/
          ];
        });
      });
    };
    return IdentityEventSender2;
  }()
);
var isNewSession = function(sessionTimeout, lastEventTime) {
  if (lastEventTime === void 0) {
    lastEventTime = Date.now();
  }
  var currentTime = Date.now();
  var timeSinceLastEvent = currentTime - lastEventTime;
  return timeSinceLastEvent > sessionTimeout;
};
var getCookieName = function(apiKey, postKey, limit) {
  if (postKey === void 0) {
    postKey = "";
  }
  if (limit === void 0) {
    limit = 10;
  }
  return [AMPLITUDE_PREFIX, postKey, apiKey.substring(0, limit)].filter(Boolean).join("_");
};
var getOldCookieName = function(apiKey) {
  return "".concat(AMPLITUDE_PREFIX.toLowerCase(), "_").concat(apiKey.substring(0, 6));
};
var getLanguage = function() {
  var _a, _b, _c, _d;
  if (typeof navigator === "undefined")
    return "";
  var userLanguage = navigator.userLanguage;
  return (_d = (_c = (_b = (_a = navigator.languages) === null || _a === void 0 ? void 0 : _a[0]) !== null && _b !== void 0 ? _b : navigator.language) !== null && _c !== void 0 ? _c : userLanguage) !== null && _d !== void 0 ? _d : "";
};
var getQueryParams$1 = function() {
  var _a;
  var globalScope = getGlobalScope$1();
  if (!((_a = globalScope === null || globalScope === void 0 ? void 0 : globalScope.location) === null || _a === void 0 ? void 0 : _a.search)) {
    return {};
  }
  var pairs = globalScope.location.search.substring(1).split("&").filter(Boolean);
  var params = pairs.reduce(function(acc, curr) {
    var query = curr.split("=", 2);
    var key = tryDecodeURIComponent$1(query[0]);
    var value = tryDecodeURIComponent$1(query[1]);
    if (!value) {
      return acc;
    }
    acc[key] = value;
    return acc;
  }, {});
  return params;
};
var tryDecodeURIComponent$1 = function(value) {
  if (value === void 0) {
    value = "";
  }
  try {
    return decodeURIComponent(value);
  } catch (_a) {
    return "";
  }
};
var getStacktrace = function(ignoreDepth) {
  var trace = new Error().stack || "";
  return trace.split("\n").slice(2 + ignoreDepth).map(function(text) {
    return text.trim();
  });
};
var getClientLogConfig = function(client2) {
  return function() {
    var _a = __assign$1({}, client2.config), logger = _a.loggerProvider, logLevel = _a.logLevel;
    return {
      logger,
      logLevel
    };
  };
};
var getValueByStringPath = function(obj, path) {
  var e_1, _a;
  path = path.replace(/\[(\w+)\]/g, ".$1");
  path = path.replace(/^\./, "");
  try {
    for (var _b = __values$1(path.split(".")), _c = _b.next(); !_c.done; _c = _b.next()) {
      var attr = _c.value;
      if (attr in obj) {
        obj = obj[attr];
      } else {
        return;
      }
    }
  } catch (e_1_1) {
    e_1 = { error: e_1_1 };
  } finally {
    try {
      if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
    } finally {
      if (e_1) throw e_1.error;
    }
  }
  return obj;
};
var getClientStates = function(client2, paths) {
  return function() {
    var e_2, _a;
    var res = {};
    try {
      for (var paths_1 = __values$1(paths), paths_1_1 = paths_1.next(); !paths_1_1.done; paths_1_1 = paths_1.next()) {
        var path = paths_1_1.value;
        res[path] = getValueByStringPath(client2, path);
      }
    } catch (e_2_1) {
      e_2 = { error: e_2_1 };
    } finally {
      try {
        if (paths_1_1 && !paths_1_1.done && (_a = paths_1.return)) _a.call(paths_1);
      } finally {
        if (e_2) throw e_2.error;
      }
    }
    return res;
  };
};
var debugWrapper = function(fn, fnName, getLogConfig, getStates, fnContext) {
  if (fnContext === void 0) {
    fnContext = null;
  }
  return function() {
    var args = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      args[_i] = arguments[_i];
    }
    var _a = getLogConfig(), logger = _a.logger, logLevel = _a.logLevel;
    if (logLevel && logLevel < LogLevel.Debug || !logLevel || !logger) {
      return fn.apply(fnContext, args);
    }
    var debugContext = {
      type: "invoke public method",
      name: fnName,
      args,
      stacktrace: getStacktrace(1),
      time: {
        start: (/* @__PURE__ */ new Date()).toISOString()
      },
      states: {}
    };
    if (getStates && debugContext.states) {
      debugContext.states.before = getStates();
    }
    var result = fn.apply(fnContext, args);
    if (result && result.promise) {
      result.promise.then(function() {
        if (getStates && debugContext.states) {
          debugContext.states.after = getStates();
        }
        if (debugContext.time) {
          debugContext.time.end = (/* @__PURE__ */ new Date()).toISOString();
        }
        logger.debug(JSON.stringify(debugContext, null, 2));
      });
    } else {
      if (getStates && debugContext.states) {
        debugContext.states.after = getStates();
      }
      if (debugContext.time) {
        debugContext.time.end = (/* @__PURE__ */ new Date()).toISOString();
      }
      logger.debug(JSON.stringify(debugContext, null, 2));
    }
    return result;
  };
};
var MemoryStorage = (
  /** @class */
  function() {
    function MemoryStorage2() {
      this.memoryStorage = /* @__PURE__ */ new Map();
    }
    MemoryStorage2.prototype.isEnabled = function() {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          return [2, true];
        });
      });
    };
    MemoryStorage2.prototype.get = function(key) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          return [2, this.memoryStorage.get(key)];
        });
      });
    };
    MemoryStorage2.prototype.getRaw = function(key) {
      return __awaiter(this, void 0, void 0, function() {
        var value;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              return [4, this.get(key)];
            case 1:
              value = _a.sent();
              return [2, value ? JSON.stringify(value) : void 0];
          }
        });
      });
    };
    MemoryStorage2.prototype.set = function(key, value) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          this.memoryStorage.set(key, value);
          return [
            2
            /*return*/
          ];
        });
      });
    };
    MemoryStorage2.prototype.remove = function(key) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          this.memoryStorage.delete(key);
          return [
            2
            /*return*/
          ];
        });
      });
    };
    MemoryStorage2.prototype.reset = function() {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          this.memoryStorage.clear();
          return [
            2
            /*return*/
          ];
        });
      });
    };
    return MemoryStorage2;
  }()
);
var CookieStorage = (
  /** @class */
  function() {
    function CookieStorage2(options) {
      this.options = __assign$1({}, options);
    }
    CookieStorage2.prototype.isEnabled = function() {
      return __awaiter(this, void 0, void 0, function() {
        var testStrorage, testKey, value;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              if (!getGlobalScope$1()) {
                return [2, false];
              }
              CookieStorage2.testValue = String(Date.now());
              testStrorage = new CookieStorage2(this.options);
              testKey = "AMP_TEST";
              _b.label = 1;
            case 1:
              _b.trys.push([1, 4, 5, 7]);
              return [4, testStrorage.set(testKey, CookieStorage2.testValue)];
            case 2:
              _b.sent();
              return [4, testStrorage.get(testKey)];
            case 3:
              value = _b.sent();
              return [2, value === CookieStorage2.testValue];
            case 4:
              _b.sent();
              return [2, false];
            case 5:
              return [4, testStrorage.remove(testKey)];
            case 6:
              _b.sent();
              return [
                7
                /*endfinally*/
              ];
            case 7:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    CookieStorage2.prototype.get = function(key) {
      var _a;
      return __awaiter(this, void 0, void 0, function() {
        var value, decodedValue;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              return [4, this.getRaw(key)];
            case 1:
              value = _b.sent();
              if (!value) {
                return [2, void 0];
              }
              try {
                decodedValue = (_a = decodeCookiesAsDefault(value)) !== null && _a !== void 0 ? _a : decodeCookiesWithDoubleUrlEncoding(value);
                if (decodedValue === void 0) {
                  console.error("Amplitude Logger [Error]: Failed to decode cookie value for key: ".concat(key, ", value: ").concat(value));
                  return [2, void 0];
                }
                return [2, JSON.parse(decodedValue)];
              } catch (_c) {
                console.error("Amplitude Logger [Error]: Failed to parse cookie value for key: ".concat(key, ", value: ").concat(value));
                return [2, void 0];
              }
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    CookieStorage2.prototype.getRaw = function(key) {
      var _a, _b;
      return __awaiter(this, void 0, void 0, function() {
        var globalScope, cookie, match;
        return __generator(this, function(_c) {
          globalScope = getGlobalScope$1();
          cookie = (_b = (_a = globalScope === null || globalScope === void 0 ? void 0 : globalScope.document) === null || _a === void 0 ? void 0 : _a.cookie.split("; ")) !== null && _b !== void 0 ? _b : [];
          match = cookie.find(function(c) {
            return c.indexOf(key + "=") === 0;
          });
          if (!match) {
            return [2, void 0];
          }
          return [2, match.substring(key.length + 1)];
        });
      });
    };
    CookieStorage2.prototype.set = function(key, value) {
      var _a;
      return __awaiter(this, void 0, void 0, function() {
        var expirationDays, expires, expireDate, date, str, globalScope, errorMessage;
        return __generator(this, function(_b) {
          try {
            expirationDays = (_a = this.options.expirationDays) !== null && _a !== void 0 ? _a : 0;
            expires = value !== null ? expirationDays : -1;
            expireDate = void 0;
            if (expires) {
              date = /* @__PURE__ */ new Date();
              date.setTime(date.getTime() + expires * 24 * 60 * 60 * 1e3);
              expireDate = date;
            }
            str = "".concat(key, "=").concat(btoa(encodeURIComponent(JSON.stringify(value))));
            if (expireDate) {
              str += "; expires=".concat(expireDate.toUTCString());
            }
            str += "; path=/";
            if (this.options.domain) {
              str += "; domain=".concat(this.options.domain);
            }
            if (this.options.secure) {
              str += "; Secure";
            }
            if (this.options.sameSite) {
              str += "; SameSite=".concat(this.options.sameSite);
            }
            globalScope = getGlobalScope$1();
            if (globalScope) {
              globalScope.document.cookie = str;
            }
          } catch (error) {
            errorMessage = error instanceof Error ? error.message : String(error);
            console.error("Amplitude Logger [Error]: Failed to set cookie for key: ".concat(key, ". Error: ").concat(errorMessage));
          }
          return [
            2
            /*return*/
          ];
        });
      });
    };
    CookieStorage2.prototype.remove = function(key) {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              return [4, this.set(key, null)];
            case 1:
              _a.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    CookieStorage2.prototype.reset = function() {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          return [
            2
            /*return*/
          ];
        });
      });
    };
    return CookieStorage2;
  }()
);
var decodeCookiesAsDefault = function(value) {
  try {
    return decodeURIComponent(atob(value));
  } catch (_a) {
    return void 0;
  }
};
var decodeCookiesWithDoubleUrlEncoding = function(value) {
  try {
    return decodeURIComponent(atob(decodeURIComponent(value)));
  } catch (_a) {
    return void 0;
  }
};
var getStorageKey = function(apiKey, postKey, limit) {
  if (limit === void 0) {
    limit = 10;
  }
  return [AMPLITUDE_PREFIX, postKey, apiKey.substring(0, limit)].filter(Boolean).join("_");
};
var BaseTransport = (
  /** @class */
  function() {
    function BaseTransport2() {
    }
    BaseTransport2.prototype.send = function(_serverUrl, _payload) {
      return Promise.resolve(null);
    };
    BaseTransport2.prototype.buildResponse = function(responseJSON) {
      var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x;
      if (typeof responseJSON !== "object") {
        return null;
      }
      var statusCode = responseJSON.code || 0;
      var status = this.buildStatus(statusCode);
      switch (status) {
        case Status$1.Success:
          return {
            status,
            statusCode,
            body: {
              eventsIngested: (_a = responseJSON.events_ingested) !== null && _a !== void 0 ? _a : 0,
              payloadSizeBytes: (_b = responseJSON.payload_size_bytes) !== null && _b !== void 0 ? _b : 0,
              serverUploadTime: (_c = responseJSON.server_upload_time) !== null && _c !== void 0 ? _c : 0
            }
          };
        case Status$1.Invalid:
          return {
            status,
            statusCode,
            body: {
              error: (_d = responseJSON.error) !== null && _d !== void 0 ? _d : "",
              missingField: (_e = responseJSON.missing_field) !== null && _e !== void 0 ? _e : "",
              eventsWithInvalidFields: (_f = responseJSON.events_with_invalid_fields) !== null && _f !== void 0 ? _f : {},
              eventsWithMissingFields: (_g = responseJSON.events_with_missing_fields) !== null && _g !== void 0 ? _g : {},
              eventsWithInvalidIdLengths: (_h = responseJSON.events_with_invalid_id_lengths) !== null && _h !== void 0 ? _h : {},
              epsThreshold: (_j = responseJSON.eps_threshold) !== null && _j !== void 0 ? _j : 0,
              exceededDailyQuotaDevices: (_k = responseJSON.exceeded_daily_quota_devices) !== null && _k !== void 0 ? _k : {},
              silencedDevices: (_l = responseJSON.silenced_devices) !== null && _l !== void 0 ? _l : [],
              silencedEvents: (_m = responseJSON.silenced_events) !== null && _m !== void 0 ? _m : [],
              throttledDevices: (_o = responseJSON.throttled_devices) !== null && _o !== void 0 ? _o : {},
              throttledEvents: (_p = responseJSON.throttled_events) !== null && _p !== void 0 ? _p : []
            }
          };
        case Status$1.PayloadTooLarge:
          return {
            status,
            statusCode,
            body: {
              error: (_q = responseJSON.error) !== null && _q !== void 0 ? _q : ""
            }
          };
        case Status$1.RateLimit:
          return {
            status,
            statusCode,
            body: {
              error: (_r = responseJSON.error) !== null && _r !== void 0 ? _r : "",
              epsThreshold: (_s = responseJSON.eps_threshold) !== null && _s !== void 0 ? _s : 0,
              throttledDevices: (_t = responseJSON.throttled_devices) !== null && _t !== void 0 ? _t : {},
              throttledUsers: (_u = responseJSON.throttled_users) !== null && _u !== void 0 ? _u : {},
              exceededDailyQuotaDevices: (_v = responseJSON.exceeded_daily_quota_devices) !== null && _v !== void 0 ? _v : {},
              exceededDailyQuotaUsers: (_w = responseJSON.exceeded_daily_quota_users) !== null && _w !== void 0 ? _w : {},
              throttledEvents: (_x = responseJSON.throttled_events) !== null && _x !== void 0 ? _x : []
            }
          };
        case Status$1.Timeout:
        default:
          return {
            status,
            statusCode
          };
      }
    };
    BaseTransport2.prototype.buildStatus = function(code) {
      if (code >= 200 && code < 300) {
        return Status$1.Success;
      }
      if (code === 429) {
        return Status$1.RateLimit;
      }
      if (code === 413) {
        return Status$1.PayloadTooLarge;
      }
      if (code === 408) {
        return Status$1.Timeout;
      }
      if (code >= 400 && code < 500) {
        return Status$1.Invalid;
      }
      if (code >= 500) {
        return Status$1.Failed;
      }
      return Status$1.Unknown;
    };
    return BaseTransport2;
  }()
);
var FetchTransport = (
  /** @class */
  function(_super) {
    __extends(FetchTransport2, _super);
    function FetchTransport2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    FetchTransport2.prototype.send = function(serverUrl, payload) {
      return __awaiter(this, void 0, void 0, function() {
        var options, response, responseText;
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              if (typeof fetch === "undefined") {
                throw new Error("FetchTransport is not supported");
              }
              options = {
                headers: {
                  "Content-Type": "application/json",
                  Accept: "*/*"
                },
                body: JSON.stringify(payload),
                method: "POST"
              };
              return [4, fetch(serverUrl, options)];
            case 1:
              response = _a.sent();
              return [4, response.text()];
            case 2:
              responseText = _a.sent();
              try {
                return [2, this.buildResponse(JSON.parse(responseText))];
              } catch (_b) {
                return [2, this.buildResponse({ code: response.status })];
              }
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    return FetchTransport2;
  }(BaseTransport)
);
var OfflineDisabled = null;
var DEFAULT_CSS_SELECTOR_ALLOWLIST = [
  "a",
  "button",
  "input",
  "select",
  "textarea",
  "label",
  "video",
  "audio",
  '[contenteditable="true" i]',
  "[data-amp-default-track]",
  ".amp-default-track"
];
var DEFAULT_DATA_ATTRIBUTE_PREFIX = "data-amp-track-";
var DEFAULT_ACTION_CLICK_ALLOWLIST = ["div", "span", "h1", "h2", "h3", "h4", "h5", "h6"];
var MAXIMUM_ENTRIES = 100;
function getRequestBodyLength(body) {
  var e_1, _a;
  var global2 = getGlobalScope$1();
  if (!(global2 === null || global2 === void 0 ? void 0 : global2.TextEncoder)) {
    return;
  }
  var TextEncoder = global2.TextEncoder;
  if (typeof body === "string") {
    return new TextEncoder().encode(body).length;
  } else if (body instanceof Blob) {
    return body.size;
  } else if (body instanceof URLSearchParams) {
    return new TextEncoder().encode(body.toString()).length;
  } else if (body instanceof ArrayBuffer) {
    return body.byteLength;
  } else if (ArrayBuffer.isView(body)) {
    return body.byteLength;
  } else if (body instanceof FormData) {
    var formData = body;
    var total = 0;
    var count2 = 0;
    try {
      for (var _b = __values$1(formData.entries()), _c = _b.next(); !_c.done; _c = _b.next()) {
        var _d = __read$1(_c.value, 2), key = _d[0], value = _d[1];
        total += key.length;
        if (typeof value === "string") {
          total += new TextEncoder().encode(value).length;
        } else if (value.size) {
          total += value.size;
        }
        if (++count2 >= MAXIMUM_ENTRIES) {
          return;
        }
      }
    } catch (e_1_1) {
      e_1 = { error: e_1_1 };
    } finally {
      try {
        if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
      } finally {
        if (e_1) throw e_1.error;
      }
    }
    return total;
  }
  return;
}
var NetworkEventCallback = (
  /** @class */
  /* @__PURE__ */ function() {
    function NetworkEventCallback2(callback, id) {
      if (id === void 0) {
        id = UUID();
      }
      this.callback = callback;
      this.id = id;
    }
    return NetworkEventCallback2;
  }()
);
var NetworkObserver = (
  /** @class */
  function() {
    function NetworkObserver2(logger) {
      var _a;
      this.eventCallbacks = /* @__PURE__ */ new Map();
      this.isObserving = false;
      this.logger = logger;
      var globalScope = getGlobalScope$1();
      if (!NetworkObserver2.isSupported()) {
        return;
      }
      this.globalScope = globalScope;
      this.originalFetch = (_a = this.globalScope) === null || _a === void 0 ? void 0 : _a.fetch;
    }
    NetworkObserver2.isSupported = function() {
      var globalScope = getGlobalScope$1();
      return !!globalScope && !!globalScope.fetch;
    };
    NetworkObserver2.prototype.subscribe = function(eventCallback, logger) {
      if (!this.logger) {
        this.logger = logger;
      }
      this.eventCallbacks.set(eventCallback.id, eventCallback);
      if (!this.isObserving) {
        this.observeFetch();
        this.isObserving = true;
      }
    };
    NetworkObserver2.prototype.unsubscribe = function(eventCallback) {
      this.eventCallbacks.delete(eventCallback.id);
      if (this.originalFetch && this.globalScope && this.eventCallbacks.size === 0 && this.isObserving) {
        this.globalScope.fetch = this.originalFetch;
        this.isObserving = false;
      }
    };
    NetworkObserver2.prototype.triggerEventCallbacks = function(event) {
      var _this = this;
      this.eventCallbacks.forEach(function(callback) {
        var _a;
        try {
          callback.callback(event);
        } catch (err) {
          (_a = _this.logger) === null || _a === void 0 ? void 0 : _a.debug("an unexpected error occurred while triggering event callbacks", err);
        }
      });
    };
    NetworkObserver2.prototype.observeFetch = function() {
      var _this = this;
      if (!this.globalScope || !this.originalFetch) {
        return;
      }
      var originalFetch = this.globalScope.fetch;
      this.globalScope.fetch = function(input, init2) {
        return __awaiter(_this, void 0, void 0, function() {
          var startTime, durationStart, requestEvent, response, headers_1, contentLength_1, error_1, endTime, typedError;
          return __generator(this, function(_a) {
            switch (_a.label) {
              case 0:
                startTime = Date.now();
                durationStart = performance.now();
                requestEvent = {
                  timestamp: startTime,
                  startTime,
                  type: "fetch",
                  method: (init2 === null || init2 === void 0 ? void 0 : init2.method) || "GET",
                  url: input.toString(),
                  requestHeaders: init2 === null || init2 === void 0 ? void 0 : init2.headers,
                  requestBodySize: getRequestBodyLength(init2 === null || init2 === void 0 ? void 0 : init2.body)
                };
                _a.label = 1;
              case 1:
                _a.trys.push([1, 3, , 4]);
                return [4, originalFetch(input, init2)];
              case 2:
                response = _a.sent();
                requestEvent.status = response.status;
                requestEvent.duration = Math.floor(performance.now() - durationStart);
                requestEvent.startTime = startTime;
                requestEvent.endTime = Math.floor(startTime + requestEvent.duration);
                headers_1 = {};
                contentLength_1 = void 0;
                response.headers.forEach(function(value, key) {
                  headers_1[key] = value;
                  if (key === "content-length") {
                    contentLength_1 = parseInt(value, 10) || void 0;
                  }
                });
                requestEvent.responseHeaders = headers_1;
                requestEvent.responseBodySize = contentLength_1;
                this.triggerEventCallbacks(requestEvent);
                return [2, response];
              case 3:
                error_1 = _a.sent();
                endTime = Date.now();
                requestEvent.duration = endTime - startTime;
                typedError = error_1;
                requestEvent.error = {
                  name: typedError.name || "UnknownError",
                  message: typedError.message || "An unknown error occurred"
                };
                if (typedError.name === "AbortError") {
                  requestEvent.error.name = "AbortError";
                  requestEvent.status = 0;
                }
                this.triggerEventCallbacks(requestEvent);
                throw error_1;
              case 4:
                return [
                  2
                  /*return*/
                ];
            }
          });
        });
      };
    };
    return NetworkObserver2;
  }()
);
var networkObserver = new NetworkObserver();
var isTrackingEnabled = function(autocapture, event, defaultValue) {
  if (typeof autocapture === "boolean") {
    return autocapture;
  }
  if (autocapture !== null && typeof autocapture === "object") {
    if (autocapture[event] === false) {
      return false;
    } else if (autocapture[event] === void 0) {
      return defaultValue;
    }
  }
  return true;
};
var isAttributionTrackingEnabled = function(autocapture) {
  return isTrackingEnabled(autocapture, "attribution", true);
};
var isFileDownloadTrackingEnabled = function(autocapture) {
  return isTrackingEnabled(autocapture, "fileDownloads", true);
};
var isFormInteractionTrackingEnabled = function(autocapture) {
  return isTrackingEnabled(autocapture, "formInteractions", true);
};
var isPageViewTrackingEnabled = function(autocapture) {
  return isTrackingEnabled(autocapture, "pageViews", true);
};
var isSessionTrackingEnabled = function(autocapture) {
  return isTrackingEnabled(autocapture, "sessions", true);
};
var isNetworkTrackingEnabled = function(autocapture) {
  return isTrackingEnabled(autocapture, "networkTracking", false);
};
var isElementInteractionsEnabled = function(autocapture) {
  if (typeof autocapture === "boolean") {
    return autocapture;
  }
  if (typeof autocapture === "object" && (autocapture.elementInteractions === true || typeof autocapture.elementInteractions === "object")) {
    return true;
  }
  return false;
};
var getElementInteractionsConfig = function(config2) {
  if (isElementInteractionsEnabled(config2.autocapture) && typeof config2.autocapture === "object" && typeof config2.autocapture.elementInteractions === "object") {
    return config2.autocapture.elementInteractions;
  }
  return void 0;
};
var getNetworkTrackingConfig = function(config2) {
  if (isNetworkTrackingEnabled(config2.autocapture) && config2.networkTrackingOptions) {
    return config2.networkTrackingOptions;
  }
  return;
};
var getPageViewTrackingConfig = function(config2) {
  var trackOn = function() {
    return false;
  };
  var trackHistoryChanges = void 0;
  var eventType;
  var pageCounter = config2.pageCounter;
  var isDefaultPageViewTrackingEnabled = isPageViewTrackingEnabled(config2.defaultTracking);
  if (isDefaultPageViewTrackingEnabled) {
    trackOn = void 0;
    eventType = void 0;
    if (config2.defaultTracking && typeof config2.defaultTracking === "object" && config2.defaultTracking.pageViews && typeof config2.defaultTracking.pageViews === "object") {
      if ("trackOn" in config2.defaultTracking.pageViews) {
        trackOn = config2.defaultTracking.pageViews.trackOn;
      }
      if ("trackHistoryChanges" in config2.defaultTracking.pageViews) {
        trackHistoryChanges = config2.defaultTracking.pageViews.trackHistoryChanges;
      }
      if ("eventType" in config2.defaultTracking.pageViews && config2.defaultTracking.pageViews.eventType) {
        eventType = config2.defaultTracking.pageViews.eventType;
      }
    }
  }
  return {
    trackOn,
    trackHistoryChanges,
    eventType,
    pageCounter
  };
};
var getAttributionTrackingConfig = function(config2) {
  if (isAttributionTrackingEnabled(config2.defaultTracking) && config2.defaultTracking && typeof config2.defaultTracking === "object" && config2.defaultTracking.attribution && typeof config2.defaultTracking.attribution === "object") {
    return __assign$1({}, config2.defaultTracking.attribution);
  }
  return {};
};
var convertProxyObjectToRealObject = function(instance, queue) {
  for (var i = 0; i < queue.length; i++) {
    var _a = queue[i], name_1 = _a.name, args = _a.args, resolve = _a.resolve;
    var fn = instance && instance[name_1];
    if (typeof fn === "function") {
      var result = fn.apply(instance, args);
      if (typeof resolve === "function") {
        resolve(result === null || result === void 0 ? void 0 : result.promise);
      }
    }
  }
  return instance;
};
var isInstanceProxy = function(instance) {
  var instanceProxy = instance;
  return instanceProxy && instanceProxy._q !== void 0;
};
var VERSION = "2.17.6";
var LIBPREFIX = "amplitude-ts";
var BROWSER_PLATFORM = "Web";
var IP_ADDRESS = "$remote";
var Context = (
  /** @class */
  function() {
    function Context2() {
      this.name = "@amplitude/plugin-context-browser";
      this.type = "before";
      this.library = "".concat(LIBPREFIX, "/").concat(VERSION);
      if (typeof navigator !== "undefined") {
        this.userAgent = navigator.userAgent;
      }
    }
    Context2.prototype.setup = function(config2) {
      this.config = config2;
      return Promise.resolve(void 0);
    };
    Context2.prototype.execute = function(context) {
      var _a, _b;
      return __awaiter(this, void 0, void 0, function() {
        var time, lastEventId, nextEventId, event;
        return __generator(this, function(_c) {
          time = (/* @__PURE__ */ new Date()).getTime();
          lastEventId = (_a = this.config.lastEventId) !== null && _a !== void 0 ? _a : -1;
          nextEventId = (_b = context.event_id) !== null && _b !== void 0 ? _b : lastEventId + 1;
          this.config.lastEventId = nextEventId;
          if (!context.time) {
            this.config.lastEventTime = time;
          }
          event = __assign$1(__assign$1(__assign$1(__assign$1(__assign$1(__assign$1(__assign$1(__assign$1({ user_id: this.config.userId, device_id: this.config.deviceId, session_id: this.config.sessionId, time }, this.config.appVersion && { app_version: this.config.appVersion }), this.config.trackingOptions.platform && { platform: BROWSER_PLATFORM }), this.config.trackingOptions.language && { language: getLanguage() }), this.config.trackingOptions.ipAddress && { ip: IP_ADDRESS }), { insert_id: UUID(), partner_id: this.config.partnerId, plan: this.config.plan }), this.config.ingestionMetadata && {
            ingestion_metadata: {
              source_name: this.config.ingestionMetadata.sourceName,
              source_version: this.config.ingestionMetadata.sourceVersion
            }
          }), context), { event_id: nextEventId, library: this.library, user_agent: this.userAgent });
          return [2, event];
        });
      });
    };
    return Context2;
  }()
);
var BrowserStorage = (
  /** @class */
  function() {
    function BrowserStorage2(storage) {
      this.storage = storage;
    }
    BrowserStorage2.prototype.isEnabled = function() {
      return __awaiter(this, void 0, void 0, function() {
        var random, testStorage, testKey, value;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              if (!this.storage) {
                return [2, false];
              }
              random = String(Date.now());
              testStorage = new BrowserStorage2(this.storage);
              testKey = "AMP_TEST";
              _b.label = 1;
            case 1:
              _b.trys.push([1, 4, 5, 7]);
              return [4, testStorage.set(testKey, random)];
            case 2:
              _b.sent();
              return [4, testStorage.get(testKey)];
            case 3:
              value = _b.sent();
              return [2, value === random];
            case 4:
              _b.sent();
              return [2, false];
            case 5:
              return [4, testStorage.remove(testKey)];
            case 6:
              _b.sent();
              return [
                7
                /*endfinally*/
              ];
            case 7:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    BrowserStorage2.prototype.get = function(key) {
      return __awaiter(this, void 0, void 0, function() {
        var value;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              _b.trys.push([0, 2, , 3]);
              return [4, this.getRaw(key)];
            case 1:
              value = _b.sent();
              if (!value) {
                return [2, void 0];
              }
              return [2, JSON.parse(value)];
            case 2:
              _b.sent();
              console.error("[Amplitude] Error: Could not get value from storage");
              return [2, void 0];
            case 3:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    BrowserStorage2.prototype.getRaw = function(key) {
      var _a;
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_b) {
          return [2, ((_a = this.storage) === null || _a === void 0 ? void 0 : _a.getItem(key)) || void 0];
        });
      });
    };
    BrowserStorage2.prototype.set = function(key, value) {
      var _a;
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_b) {
          try {
            (_a = this.storage) === null || _a === void 0 ? void 0 : _a.setItem(key, JSON.stringify(value));
          } catch (_c) {
          }
          return [
            2
            /*return*/
          ];
        });
      });
    };
    BrowserStorage2.prototype.remove = function(key) {
      var _a;
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_b) {
          try {
            (_a = this.storage) === null || _a === void 0 ? void 0 : _a.removeItem(key);
          } catch (_c) {
          }
          return [
            2
            /*return*/
          ];
        });
      });
    };
    BrowserStorage2.prototype.reset = function() {
      var _a;
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_b) {
          try {
            (_a = this.storage) === null || _a === void 0 ? void 0 : _a.clear();
          } catch (_c) {
          }
          return [
            2
            /*return*/
          ];
        });
      });
    };
    return BrowserStorage2;
  }()
);
var MAX_ARRAY_LENGTH = 1e3;
var LocalStorage = (
  /** @class */
  function(_super) {
    __extends(LocalStorage2, _super);
    function LocalStorage2(config2) {
      var _this = this;
      var _a, _b;
      var localStorage;
      try {
        localStorage = (_a = getGlobalScope$1()) === null || _a === void 0 ? void 0 : _a.localStorage;
      } catch (e) {
        (_b = config2 === null || config2 === void 0 ? void 0 : config2.loggerProvider) === null || _b === void 0 ? void 0 : _b.debug("Failed to access localStorage. error=".concat(JSON.stringify(e)));
        localStorage = void 0;
      }
      _this = _super.call(this, localStorage) || this;
      _this.loggerProvider = config2 === null || config2 === void 0 ? void 0 : config2.loggerProvider;
      return _this;
    }
    LocalStorage2.prototype.set = function(key, value) {
      var _a;
      return __awaiter(this, void 0, void 0, function() {
        var droppedEventsCount;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              if (!(Array.isArray(value) && value.length > MAX_ARRAY_LENGTH)) return [3, 2];
              droppedEventsCount = value.length - MAX_ARRAY_LENGTH;
              return [4, _super.prototype.set.call(this, key, value.slice(0, MAX_ARRAY_LENGTH))];
            case 1:
              _b.sent();
              (_a = this.loggerProvider) === null || _a === void 0 ? void 0 : _a.error("Failed to save ".concat(droppedEventsCount, " events because the queue length exceeded ").concat(MAX_ARRAY_LENGTH, "."));
              return [3, 4];
            case 2:
              return [4, _super.prototype.set.call(this, key, value)];
            case 3:
              _b.sent();
              _b.label = 4;
            case 4:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    return LocalStorage2;
  }(BrowserStorage)
);
var SessionStorage = (
  /** @class */
  function(_super) {
    __extends(SessionStorage2, _super);
    function SessionStorage2() {
      var _a;
      return _super.call(this, (_a = getGlobalScope$1()) === null || _a === void 0 ? void 0 : _a.sessionStorage) || this;
    }
    return SessionStorage2;
  }(BrowserStorage)
);
var XHRTransport = (
  /** @class */
  function(_super) {
    __extends(XHRTransport2, _super);
    function XHRTransport2() {
      var _this = _super !== null && _super.apply(this, arguments) || this;
      _this.state = {
        done: 4
      };
      return _this;
    }
    XHRTransport2.prototype.send = function(serverUrl, payload) {
      return __awaiter(this, void 0, void 0, function() {
        var _this = this;
        return __generator(this, function(_a) {
          return [2, new Promise(function(resolve, reject) {
            if (typeof XMLHttpRequest === "undefined") {
              reject(new Error("XHRTransport is not supported."));
            }
            var xhr = new XMLHttpRequest();
            xhr.open("POST", serverUrl, true);
            xhr.onreadystatechange = function() {
              if (xhr.readyState === _this.state.done) {
                var responseText = xhr.responseText;
                try {
                  resolve(_this.buildResponse(JSON.parse(responseText)));
                } catch (_a2) {
                  resolve(_this.buildResponse({ code: xhr.status }));
                }
              }
            };
            xhr.setRequestHeader("Content-Type", "application/json");
            xhr.setRequestHeader("Accept", "*/*");
            xhr.send(JSON.stringify(payload));
          })];
        });
      });
    };
    return XHRTransport2;
  }(BaseTransport)
);
var SendBeaconTransport = (
  /** @class */
  function(_super) {
    __extends(SendBeaconTransport2, _super);
    function SendBeaconTransport2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    SendBeaconTransport2.prototype.send = function(serverUrl, payload) {
      return __awaiter(this, void 0, void 0, function() {
        var _this = this;
        return __generator(this, function(_a) {
          return [2, new Promise(function(resolve, reject) {
            var globalScope = getGlobalScope$1();
            if (!(globalScope === null || globalScope === void 0 ? void 0 : globalScope.navigator.sendBeacon)) {
              throw new Error("SendBeaconTransport is not supported");
            }
            try {
              var data = JSON.stringify(payload);
              var success = globalScope.navigator.sendBeacon(serverUrl, JSON.stringify(payload));
              if (success) {
                return resolve(_this.buildResponse({
                  code: 200,
                  events_ingested: payload.events.length,
                  payload_size_bytes: data.length,
                  server_upload_time: Date.now()
                }));
              }
              return resolve(_this.buildResponse({ code: 500 }));
            } catch (e) {
              reject(e);
            }
          })];
        });
      });
    };
    return SendBeaconTransport2;
  }(BaseTransport)
);
var parseLegacyCookies = function(apiKey, cookieStorage, deleteLegacyCookies) {
  if (deleteLegacyCookies === void 0) {
    deleteLegacyCookies = true;
  }
  return __awaiter(void 0, void 0, void 0, function() {
    var cookieName, cookies, _a, deviceId, userId, optOut, sessionId, lastEventTime, lastEventId;
    return __generator(this, function(_b) {
      switch (_b.label) {
        case 0:
          cookieName = getOldCookieName(apiKey);
          return [4, cookieStorage.getRaw(cookieName)];
        case 1:
          cookies = _b.sent();
          if (!cookies) {
            return [2, {
              optOut: false
            }];
          }
          if (!deleteLegacyCookies) return [3, 3];
          return [4, cookieStorage.remove(cookieName)];
        case 2:
          _b.sent();
          _b.label = 3;
        case 3:
          _a = __read$1(cookies.split("."), 6), deviceId = _a[0], userId = _a[1], optOut = _a[2], sessionId = _a[3], lastEventTime = _a[4], lastEventId = _a[5];
          return [2, {
            deviceId,
            userId: decode(userId),
            sessionId: parseTime(sessionId),
            lastEventId: parseTime(lastEventId),
            lastEventTime: parseTime(lastEventTime),
            optOut: Boolean(optOut)
          }];
      }
    });
  });
};
var parseTime = function(num) {
  var integer = parseInt(num, 32);
  if (isNaN(integer)) {
    return void 0;
  }
  return integer;
};
var decode = function(value) {
  if (!atob || !escape || !value) {
    return void 0;
  }
  try {
    return decodeURIComponent(escape(atob(value)));
  } catch (_a) {
    return void 0;
  }
};
var DEFAULT_EVENT_PREFIX = "[Amplitude]";
var DEFAULT_FORM_START_EVENT = "".concat(DEFAULT_EVENT_PREFIX, " Form Started");
var DEFAULT_FORM_SUBMIT_EVENT = "".concat(DEFAULT_EVENT_PREFIX, " Form Submitted");
var DEFAULT_FILE_DOWNLOAD_EVENT = "".concat(DEFAULT_EVENT_PREFIX, " File Downloaded");
var DEFAULT_SESSION_START_EVENT = "session_start";
var DEFAULT_SESSION_END_EVENT = "session_end";
var FILE_EXTENSION = "".concat(DEFAULT_EVENT_PREFIX, " File Extension");
var FILE_NAME = "".concat(DEFAULT_EVENT_PREFIX, " File Name");
var LINK_ID = "".concat(DEFAULT_EVENT_PREFIX, " Link ID");
var LINK_TEXT = "".concat(DEFAULT_EVENT_PREFIX, " Link Text");
var LINK_URL = "".concat(DEFAULT_EVENT_PREFIX, " Link URL");
var FORM_ID = "".concat(DEFAULT_EVENT_PREFIX, " Form ID");
var FORM_NAME = "".concat(DEFAULT_EVENT_PREFIX, " Form Name");
var FORM_DESTINATION = "".concat(DEFAULT_EVENT_PREFIX, " Form Destination");
var DEFAULT_IDENTITY_STORAGE = "cookie";
var DEFAULT_SERVER_ZONE = "US";
var BrowserConfig = (
  /** @class */
  function(_super) {
    __extends(BrowserConfig2, _super);
    function BrowserConfig2(apiKey, appVersion, cookieStorage, cookieOptions, defaultTracking, autocapture, deviceId, flushIntervalMillis, flushMaxRetries, flushQueueSize, identityStorage, ingestionMetadata, instanceName, lastEventId, lastEventTime, loggerProvider, logLevel, minIdLength, offline, optOut, partnerId, plan, serverUrl, serverZone, sessionId, sessionTimeout, storageProvider, trackingOptions, transport, useBatch, fetchRemoteConfig, userId, pageCounter, debugLogsEnabled, networkTrackingOptions) {
      if (cookieStorage === void 0) {
        cookieStorage = new MemoryStorage();
      }
      if (cookieOptions === void 0) {
        cookieOptions = {
          domain: "",
          expiration: 365,
          sameSite: "Lax",
          secure: false,
          upgrade: true
        };
      }
      if (flushIntervalMillis === void 0) {
        flushIntervalMillis = 1e3;
      }
      if (flushMaxRetries === void 0) {
        flushMaxRetries = 5;
      }
      if (flushQueueSize === void 0) {
        flushQueueSize = 30;
      }
      if (identityStorage === void 0) {
        identityStorage = DEFAULT_IDENTITY_STORAGE;
      }
      if (loggerProvider === void 0) {
        loggerProvider = new Logger();
      }
      if (logLevel === void 0) {
        logLevel = LogLevel.Warn;
      }
      if (offline === void 0) {
        offline = false;
      }
      if (optOut === void 0) {
        optOut = false;
      }
      if (serverUrl === void 0) {
        serverUrl = "";
      }
      if (serverZone === void 0) {
        serverZone = DEFAULT_SERVER_ZONE;
      }
      if (sessionTimeout === void 0) {
        sessionTimeout = 30 * 60 * 1e3;
      }
      if (storageProvider === void 0) {
        storageProvider = new LocalStorage({ loggerProvider });
      }
      if (trackingOptions === void 0) {
        trackingOptions = {
          ipAddress: true,
          language: true,
          platform: true
        };
      }
      if (transport === void 0) {
        transport = "fetch";
      }
      if (useBatch === void 0) {
        useBatch = false;
      }
      if (fetchRemoteConfig === void 0) {
        fetchRemoteConfig = true;
      }
      var _this = _super.call(this, { apiKey, storageProvider, transportProvider: createTransport(transport) }) || this;
      _this.apiKey = apiKey;
      _this.appVersion = appVersion;
      _this.cookieOptions = cookieOptions;
      _this.defaultTracking = defaultTracking;
      _this.autocapture = autocapture;
      _this.flushIntervalMillis = flushIntervalMillis;
      _this.flushMaxRetries = flushMaxRetries;
      _this.flushQueueSize = flushQueueSize;
      _this.identityStorage = identityStorage;
      _this.ingestionMetadata = ingestionMetadata;
      _this.instanceName = instanceName;
      _this.loggerProvider = loggerProvider;
      _this.logLevel = logLevel;
      _this.minIdLength = minIdLength;
      _this.offline = offline;
      _this.partnerId = partnerId;
      _this.plan = plan;
      _this.serverUrl = serverUrl;
      _this.serverZone = serverZone;
      _this.sessionTimeout = sessionTimeout;
      _this.storageProvider = storageProvider;
      _this.trackingOptions = trackingOptions;
      _this.transport = transport;
      _this.useBatch = useBatch;
      _this.fetchRemoteConfig = fetchRemoteConfig;
      _this.networkTrackingOptions = networkTrackingOptions;
      _this.version = VERSION;
      _this._optOut = false;
      _this._cookieStorage = cookieStorage;
      _this.deviceId = deviceId;
      _this.lastEventId = lastEventId;
      _this.lastEventTime = lastEventTime;
      _this.optOut = optOut;
      _this.sessionId = sessionId;
      _this.pageCounter = pageCounter;
      _this.userId = userId;
      _this.debugLogsEnabled = debugLogsEnabled;
      _this.loggerProvider.enable(debugLogsEnabled ? LogLevel.Debug : _this.logLevel);
      _this.networkTrackingOptions = networkTrackingOptions;
      return _this;
    }
    Object.defineProperty(BrowserConfig2.prototype, "cookieStorage", {
      get: function() {
        return this._cookieStorage;
      },
      set: function(cookieStorage) {
        if (this._cookieStorage !== cookieStorage) {
          this._cookieStorage = cookieStorage;
          this.updateStorage();
        }
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(BrowserConfig2.prototype, "deviceId", {
      get: function() {
        return this._deviceId;
      },
      set: function(deviceId) {
        if (this._deviceId !== deviceId) {
          this._deviceId = deviceId;
          this.updateStorage();
        }
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(BrowserConfig2.prototype, "userId", {
      get: function() {
        return this._userId;
      },
      set: function(userId) {
        if (this._userId !== userId) {
          this._userId = userId;
          this.updateStorage();
        }
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(BrowserConfig2.prototype, "sessionId", {
      get: function() {
        return this._sessionId;
      },
      set: function(sessionId) {
        if (this._sessionId !== sessionId) {
          this._sessionId = sessionId;
          this.updateStorage();
        }
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(BrowserConfig2.prototype, "optOut", {
      get: function() {
        return this._optOut;
      },
      set: function(optOut) {
        if (this._optOut !== optOut) {
          this._optOut = optOut;
          this.updateStorage();
        }
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(BrowserConfig2.prototype, "lastEventTime", {
      get: function() {
        return this._lastEventTime;
      },
      set: function(lastEventTime) {
        if (this._lastEventTime !== lastEventTime) {
          this._lastEventTime = lastEventTime;
          this.updateStorage();
        }
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(BrowserConfig2.prototype, "lastEventId", {
      get: function() {
        return this._lastEventId;
      },
      set: function(lastEventId) {
        if (this._lastEventId !== lastEventId) {
          this._lastEventId = lastEventId;
          this.updateStorage();
        }
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(BrowserConfig2.prototype, "pageCounter", {
      get: function() {
        return this._pageCounter;
      },
      set: function(pageCounter) {
        if (this._pageCounter !== pageCounter) {
          this._pageCounter = pageCounter;
          this.updateStorage();
        }
      },
      enumerable: false,
      configurable: true
    });
    Object.defineProperty(BrowserConfig2.prototype, "debugLogsEnabled", {
      set: function(debugLogsEnabled) {
        if (this._debugLogsEnabled !== debugLogsEnabled) {
          this._debugLogsEnabled = debugLogsEnabled;
          this.updateStorage();
        }
      },
      enumerable: false,
      configurable: true
    });
    BrowserConfig2.prototype.updateStorage = function() {
      var cache = {
        deviceId: this._deviceId,
        userId: this._userId,
        sessionId: this._sessionId,
        optOut: this._optOut,
        lastEventTime: this._lastEventTime,
        lastEventId: this._lastEventId,
        pageCounter: this._pageCounter,
        debugLogsEnabled: this._debugLogsEnabled
      };
      void this.cookieStorage.set(getCookieName(this.apiKey), cache);
    };
    return BrowserConfig2;
  }(Config)
);
var useBrowserConfig = function(apiKey, options, amplitudeInstance) {
  if (options === void 0) {
    options = {};
  }
  return __awaiter(void 0, void 0, void 0, function() {
    var identityStorage, cookieOptions, _a, _b, cookieStorage, legacyCookies, previousCookies, queryParams, deviceId, lastEventId, lastEventTime, optOut, sessionId, userId, trackingOptions, pageCounter, debugLogsEnabled, browserConfig;
    var _c;
    var _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s, _t, _u, _v, _w, _x, _y, _z, _0, _1, _2;
    return __generator(this, function(_3) {
      switch (_3.label) {
        case 0:
          identityStorage = options.identityStorage || DEFAULT_IDENTITY_STORAGE;
          _c = {};
          if (!(identityStorage !== DEFAULT_IDENTITY_STORAGE)) return [3, 1];
          _a = "";
          return [3, 5];
        case 1:
          if (!((_e = (_d = options.cookieOptions) === null || _d === void 0 ? void 0 : _d.domain) !== null && _e !== void 0)) return [3, 2];
          _b = _e;
          return [3, 4];
        case 2:
          return [4, getTopLevelDomain()];
        case 3:
          _b = _3.sent();
          _3.label = 4;
        case 4:
          _a = _b;
          _3.label = 5;
        case 5:
          cookieOptions = __assign$1.apply(void 0, [(_c.domain = _a, _c.expiration = 365, _c.sameSite = "Lax", _c.secure = false, _c.upgrade = true, _c), options.cookieOptions]);
          cookieStorage = createCookieStorage(options.identityStorage, cookieOptions);
          return [4, parseLegacyCookies(apiKey, cookieStorage, (_g = (_f = options.cookieOptions) === null || _f === void 0 ? void 0 : _f.upgrade) !== null && _g !== void 0 ? _g : true)];
        case 6:
          legacyCookies = _3.sent();
          return [4, cookieStorage.get(getCookieName(apiKey))];
        case 7:
          previousCookies = _3.sent();
          queryParams = getQueryParams$1();
          deviceId = (_m = (_l = (_k = (_j = (_h = options.deviceId) !== null && _h !== void 0 ? _h : queryParams.ampDeviceId) !== null && _j !== void 0 ? _j : queryParams.deviceId) !== null && _k !== void 0 ? _k : previousCookies === null || previousCookies === void 0 ? void 0 : previousCookies.deviceId) !== null && _l !== void 0 ? _l : legacyCookies.deviceId) !== null && _m !== void 0 ? _m : UUID();
          lastEventId = (_o = previousCookies === null || previousCookies === void 0 ? void 0 : previousCookies.lastEventId) !== null && _o !== void 0 ? _o : legacyCookies.lastEventId;
          lastEventTime = (_p = previousCookies === null || previousCookies === void 0 ? void 0 : previousCookies.lastEventTime) !== null && _p !== void 0 ? _p : legacyCookies.lastEventTime;
          optOut = (_r = (_q = options.optOut) !== null && _q !== void 0 ? _q : previousCookies === null || previousCookies === void 0 ? void 0 : previousCookies.optOut) !== null && _r !== void 0 ? _r : legacyCookies.optOut;
          sessionId = (_s = previousCookies === null || previousCookies === void 0 ? void 0 : previousCookies.sessionId) !== null && _s !== void 0 ? _s : legacyCookies.sessionId;
          userId = (_u = (_t = options.userId) !== null && _t !== void 0 ? _t : previousCookies === null || previousCookies === void 0 ? void 0 : previousCookies.userId) !== null && _u !== void 0 ? _u : legacyCookies.userId;
          amplitudeInstance.previousSessionDeviceId = (_v = previousCookies === null || previousCookies === void 0 ? void 0 : previousCookies.deviceId) !== null && _v !== void 0 ? _v : legacyCookies.deviceId;
          amplitudeInstance.previousSessionUserId = (_w = previousCookies === null || previousCookies === void 0 ? void 0 : previousCookies.userId) !== null && _w !== void 0 ? _w : legacyCookies.userId;
          trackingOptions = {
            ipAddress: (_y = (_x = options.trackingOptions) === null || _x === void 0 ? void 0 : _x.ipAddress) !== null && _y !== void 0 ? _y : true,
            language: (_0 = (_z = options.trackingOptions) === null || _z === void 0 ? void 0 : _z.language) !== null && _0 !== void 0 ? _0 : true,
            platform: (_2 = (_1 = options.trackingOptions) === null || _1 === void 0 ? void 0 : _1.platform) !== null && _2 !== void 0 ? _2 : true
          };
          pageCounter = previousCookies === null || previousCookies === void 0 ? void 0 : previousCookies.pageCounter;
          debugLogsEnabled = previousCookies === null || previousCookies === void 0 ? void 0 : previousCookies.debugLogsEnabled;
          if (options.autocapture !== void 0) {
            options.defaultTracking = options.autocapture;
          }
          browserConfig = new BrowserConfig(apiKey, options.appVersion, cookieStorage, cookieOptions, options.defaultTracking, options.autocapture, deviceId, options.flushIntervalMillis, options.flushMaxRetries, options.flushQueueSize, identityStorage, options.ingestionMetadata, options.instanceName, lastEventId, lastEventTime, options.loggerProvider, options.logLevel, options.minIdLength, options.offline, optOut, options.partnerId, options.plan, options.serverUrl, options.serverZone, sessionId, options.sessionTimeout, options.storageProvider, trackingOptions, options.transport, options.useBatch, options.fetchRemoteConfig, userId, pageCounter, debugLogsEnabled, options.networkTrackingOptions);
          return [4, browserConfig.storageProvider.isEnabled()];
        case 8:
          if (!_3.sent()) {
            browserConfig.loggerProvider.warn("Storage provider ".concat(browserConfig.storageProvider.constructor.name, " is not enabled. Falling back to MemoryStorage."));
            browserConfig.storageProvider = new MemoryStorage();
          }
          return [2, browserConfig];
      }
    });
  });
};
var createCookieStorage = function(identityStorage, cookieOptions) {
  if (identityStorage === void 0) {
    identityStorage = DEFAULT_IDENTITY_STORAGE;
  }
  if (cookieOptions === void 0) {
    cookieOptions = {};
  }
  switch (identityStorage) {
    case "localStorage":
      return new LocalStorage();
    case "sessionStorage":
      return new SessionStorage();
    case "none":
      return new MemoryStorage();
    case "cookie":
    default:
      return new CookieStorage(__assign$1(__assign$1({}, cookieOptions), { expirationDays: cookieOptions.expiration }));
  }
};
var createTransport = function(transport) {
  if (transport === "xhr") {
    return new XHRTransport();
  }
  if (transport === "beacon") {
    return new SendBeaconTransport();
  }
  return new FetchTransport();
};
var getTopLevelDomain = function(url) {
  return __awaiter(void 0, void 0, void 0, function() {
    var host, parts, levels, storageKey, i, i, domain, options, storage, value;
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          return [4, new CookieStorage().isEnabled()];
        case 1:
          if (!_a.sent() || (typeof location === "undefined" || !location.hostname)) {
            return [2, ""];
          }
          host = location.hostname;
          parts = host.split(".");
          levels = [];
          storageKey = "AMP_TLDTEST";
          for (i = parts.length - 2; i >= 0; --i) {
            levels.push(parts.slice(i).join("."));
          }
          i = 0;
          _a.label = 2;
        case 2:
          if (!(i < levels.length)) return [3, 7];
          domain = levels[i];
          options = { domain: "." + domain };
          storage = new CookieStorage(options);
          return [4, storage.set(storageKey, 1)];
        case 3:
          _a.sent();
          return [4, storage.get(storageKey)];
        case 4:
          value = _a.sent();
          if (!value) return [3, 6];
          return [4, storage.remove(storageKey)];
        case 5:
          _a.sent();
          return [2, "." + domain];
        case 6:
          i++;
          return [3, 2];
        case 7:
          return [2, ""];
      }
    });
  });
};
var getGlobalScope = function() {
  var ampIntegrationContextName = "ampIntegrationContext";
  if (typeof globalThis !== "undefined" && typeof globalThis[ampIntegrationContextName] !== "undefined") {
    return globalThis[ampIntegrationContextName];
  }
  if (typeof globalThis !== "undefined") {
    return globalThis;
  }
  if (typeof window !== "undefined") {
    return window;
  }
  if (typeof self !== "undefined") {
    return self;
  }
  if (typeof global !== "undefined") {
    return global;
  }
  return void 0;
};
var getQueryParams = function() {
  var _a;
  var globalScope = getGlobalScope();
  if (!((_a = globalScope === null || globalScope === void 0 ? void 0 : globalScope.location) === null || _a === void 0 ? void 0 : _a.search)) {
    return {};
  }
  var pairs = globalScope.location.search.substring(1).split("&").filter(Boolean);
  var params = pairs.reduce(function(acc, curr) {
    var query = curr.split("=", 2);
    var key = tryDecodeURIComponent(query[0]);
    var value = tryDecodeURIComponent(query[1]);
    if (!value) {
      return acc;
    }
    acc[key] = value;
    return acc;
  }, {});
  return params;
};
var tryDecodeURIComponent = function(value) {
  if (value === void 0) {
    value = "";
  }
  try {
    return decodeURIComponent(value);
  } catch (_a) {
    return "";
  }
};
var UTM_CAMPAIGN$1 = "utm_campaign";
var UTM_CONTENT$1 = "utm_content";
var UTM_ID$1 = "utm_id";
var UTM_MEDIUM$1 = "utm_medium";
var UTM_SOURCE$1 = "utm_source";
var UTM_TERM$1 = "utm_term";
var DCLID$1 = "dclid";
var FBCLID$1 = "fbclid";
var GBRAID$1 = "gbraid";
var GCLID$1 = "gclid";
var KO_CLICK_ID$1 = "ko_click_id";
var LI_FAT_ID$1 = "li_fat_id";
var MSCLKID$1 = "msclkid";
var RDT_CID$1 = "rtd_cid";
var TTCLID$1 = "ttclid";
var TWCLID$1 = "twclid";
var WBRAID$1 = "wbraid";
var BASE_CAMPAIGN$1 = {
  utm_campaign: void 0,
  utm_content: void 0,
  utm_id: void 0,
  utm_medium: void 0,
  utm_source: void 0,
  utm_term: void 0,
  referrer: void 0,
  referring_domain: void 0,
  dclid: void 0,
  gbraid: void 0,
  gclid: void 0,
  fbclid: void 0,
  ko_click_id: void 0,
  li_fat_id: void 0,
  msclkid: void 0,
  rtd_cid: void 0,
  ttclid: void 0,
  twclid: void 0,
  wbraid: void 0
};
var CampaignParser$1 = (
  /** @class */
  function() {
    function CampaignParser2() {
    }
    CampaignParser2.prototype.parse = function() {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          return [2, __assign$1(__assign$1(__assign$1(__assign$1({}, BASE_CAMPAIGN$1), this.getUtmParam()), this.getReferrer()), this.getClickIds())];
        });
      });
    };
    CampaignParser2.prototype.getUtmParam = function() {
      var params = getQueryParams();
      var utmCampaign = params[UTM_CAMPAIGN$1];
      var utmContent = params[UTM_CONTENT$1];
      var utmId = params[UTM_ID$1];
      var utmMedium = params[UTM_MEDIUM$1];
      var utmSource = params[UTM_SOURCE$1];
      var utmTerm = params[UTM_TERM$1];
      return {
        utm_campaign: utmCampaign,
        utm_content: utmContent,
        utm_id: utmId,
        utm_medium: utmMedium,
        utm_source: utmSource,
        utm_term: utmTerm
      };
    };
    CampaignParser2.prototype.getReferrer = function() {
      var _a, _b;
      var data = {
        referrer: void 0,
        referring_domain: void 0
      };
      try {
        data.referrer = document.referrer || void 0;
        data.referring_domain = (_b = (_a = data.referrer) === null || _a === void 0 ? void 0 : _a.split("/")[2]) !== null && _b !== void 0 ? _b : void 0;
      } catch (_c) {
      }
      return data;
    };
    CampaignParser2.prototype.getClickIds = function() {
      var _a;
      var params = getQueryParams();
      return _a = {}, _a[DCLID$1] = params[DCLID$1], _a[FBCLID$1] = params[FBCLID$1], _a[GBRAID$1] = params[GBRAID$1], _a[GCLID$1] = params[GCLID$1], _a[KO_CLICK_ID$1] = params[KO_CLICK_ID$1], _a[LI_FAT_ID$1] = params[LI_FAT_ID$1], _a[MSCLKID$1] = params[MSCLKID$1], _a[RDT_CID$1] = params[RDT_CID$1], _a[TTCLID$1] = params[TTCLID$1], _a[TWCLID$1] = params[TWCLID$1], _a[WBRAID$1] = params[WBRAID$1], _a;
    };
    return CampaignParser2;
  }()
);
var IdentifyOperation;
(function(IdentifyOperation2) {
  IdentifyOperation2["SET"] = "$set";
  IdentifyOperation2["SET_ONCE"] = "$setOnce";
  IdentifyOperation2["ADD"] = "$add";
  IdentifyOperation2["APPEND"] = "$append";
  IdentifyOperation2["PREPEND"] = "$prepend";
  IdentifyOperation2["REMOVE"] = "$remove";
  IdentifyOperation2["PREINSERT"] = "$preInsert";
  IdentifyOperation2["POSTINSERT"] = "$postInsert";
  IdentifyOperation2["UNSET"] = "$unset";
  IdentifyOperation2["CLEAR_ALL"] = "$clearAll";
})(IdentifyOperation || (IdentifyOperation = {}));
var RevenueProperty;
(function(RevenueProperty2) {
  RevenueProperty2["REVENUE_PRODUCT_ID"] = "$productId";
  RevenueProperty2["REVENUE_QUANTITY"] = "$quantity";
  RevenueProperty2["REVENUE_PRICE"] = "$price";
  RevenueProperty2["REVENUE_TYPE"] = "$revenueType";
  RevenueProperty2["REVENUE_CURRENCY"] = "$currency";
  RevenueProperty2["REVENUE"] = "$revenue";
})(RevenueProperty || (RevenueProperty = {}));
var SpecialEventType;
(function(SpecialEventType2) {
  SpecialEventType2["IDENTIFY"] = "$identify";
  SpecialEventType2["GROUP_IDENTIFY"] = "$groupidentify";
  SpecialEventType2["REVENUE"] = "revenue_amount";
})(SpecialEventType || (SpecialEventType = {}));
var ServerZone;
(function(ServerZone2) {
  ServerZone2["US"] = "US";
  ServerZone2["EU"] = "EU";
})(ServerZone || (ServerZone = {}));
var Status;
(function(Status2) {
  Status2["Unknown"] = "unknown";
  Status2["Skipped"] = "skipped";
  Status2["Success"] = "success";
  Status2["RateLimit"] = "rate_limit";
  Status2["PayloadTooLarge"] = "payload_too_large";
  Status2["Invalid"] = "invalid";
  Status2["Failed"] = "failed";
  Status2["Timeout"] = "Timeout";
  Status2["SystemError"] = "SystemError";
})(Status || (Status = {}));
var omitUndefined = function(input) {
  var obj = {};
  for (var key in input) {
    var val = input[key];
    if (val) {
      obj[key] = val;
    }
  }
  return obj;
};
var defaultPageViewEvent = "[Amplitude] Page Viewed";
var pageViewTrackingPlugin = function(options) {
  if (options === void 0) {
    options = {};
  }
  var amplitude;
  var globalScope = getGlobalScope();
  var loggerProvider = void 0;
  var isTracking = false;
  var localConfig;
  var trackOn = options.trackOn, trackHistoryChanges = options.trackHistoryChanges, _a = options.eventType, eventType = _a === void 0 ? defaultPageViewEvent : _a;
  var getDecodeURI = function(locationStr) {
    var decodedLocationStr = locationStr;
    try {
      decodedLocationStr = decodeURI(locationStr);
    } catch (e) {
      loggerProvider === null || loggerProvider === void 0 ? void 0 : loggerProvider.error("Malformed URI sequence: ", e);
    }
    return decodedLocationStr;
  };
  var createPageViewEvent = function() {
    return __awaiter(void 0, void 0, void 0, function() {
      var locationHREF, _a2;
      var _b;
      return __generator(this, function(_c) {
        switch (_c.label) {
          case 0:
            locationHREF = getDecodeURI(typeof location !== "undefined" && location.href || "");
            _b = {
              event_type: eventType
            };
            _a2 = [{}];
            return [4, getCampaignParams()];
          case 1:
            return [2, (_b.event_properties = __assign$1.apply(void 0, [__assign$1.apply(void 0, _a2.concat([_c.sent()])), { "[Amplitude] Page Domain": (
              /* istanbul ignore next */
              typeof location !== "undefined" && location.hostname || ""
            ), "[Amplitude] Page Location": locationHREF, "[Amplitude] Page Path": (
              /* istanbul ignore next */
              typeof location !== "undefined" && getDecodeURI(location.pathname) || ""
            ), "[Amplitude] Page Title": (
              /* istanbul ignore next */
              typeof document !== "undefined" && document.title || ""
            ), "[Amplitude] Page URL": locationHREF.split("?")[0] }]), _b)];
        }
      });
    });
  };
  var shouldTrackOnPageLoad = function() {
    return typeof trackOn === "undefined" || typeof trackOn === "function" && trackOn();
  };
  var previousURL = typeof location !== "undefined" ? location.href : null;
  var trackHistoryPageView = function() {
    return __awaiter(void 0, void 0, void 0, function() {
      var newURL, shouldTrackPageView, _b, _c;
      return __generator(this, function(_d) {
        switch (_d.label) {
          case 0:
            newURL = location.href;
            shouldTrackPageView = shouldTrackHistoryPageView(trackHistoryChanges, newURL, previousURL || "") && shouldTrackOnPageLoad();
            previousURL = newURL;
            if (!shouldTrackPageView) return [3, 4];
            loggerProvider === null || loggerProvider === void 0 ? void 0 : loggerProvider.log("Tracking page view event");
            if (!(amplitude === null || amplitude === void 0)) return [3, 1];
            return [3, 3];
          case 1:
            _c = (_b = amplitude).track;
            return [4, createPageViewEvent()];
          case 2:
            _c.apply(_b, [_d.sent()]);
            _d.label = 3;
          case 3:
            _d.label = 4;
          case 4:
            return [
              2
              /*return*/
            ];
        }
      });
    });
  };
  var trackHistoryPageViewWrapper = function() {
    void trackHistoryPageView();
  };
  var plugin = {
    name: "@amplitude/plugin-page-view-tracking-browser",
    type: "enrichment",
    setup: function(config2, client2) {
      return __awaiter(void 0, void 0, void 0, function() {
        var _a2, _b;
        return __generator(this, function(_c) {
          switch (_c.label) {
            case 0:
              amplitude = client2;
              localConfig = config2;
              loggerProvider = config2.loggerProvider;
              loggerProvider.log("Installing @amplitude/plugin-page-view-tracking-browser");
              isTracking = true;
              if (globalScope) {
                globalScope.addEventListener("popstate", trackHistoryPageViewWrapper);
                globalScope.history.pushState = new Proxy(globalScope.history.pushState, {
                  apply: function(target, thisArg, _a3) {
                    var _b2 = __read$1(_a3, 3), state = _b2[0], unused = _b2[1], url = _b2[2];
                    target.apply(thisArg, [state, unused, url]);
                    if (isTracking) {
                      void trackHistoryPageView();
                    }
                  }
                });
              }
              if (!shouldTrackOnPageLoad()) return [3, 2];
              loggerProvider.log("Tracking page view event");
              _b = (_a2 = amplitude).track;
              return [4, createPageViewEvent()];
            case 1:
              _b.apply(_a2, [_c.sent()]);
              _c.label = 2;
            case 2:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    },
    execute: function(event) {
      return __awaiter(void 0, void 0, void 0, function() {
        var pageViewEvent;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              if (!(trackOn === "attribution" && isCampaignEvent(event))) return [3, 2];
              loggerProvider === null || loggerProvider === void 0 ? void 0 : loggerProvider.log("Enriching campaign event to page view event with campaign parameters");
              return [4, createPageViewEvent()];
            case 1:
              pageViewEvent = _a2.sent();
              event.event_type = pageViewEvent.event_type;
              event.event_properties = __assign$1(__assign$1({}, event.event_properties), pageViewEvent.event_properties);
              _a2.label = 2;
            case 2:
              if (localConfig && event.event_type === eventType) {
                localConfig.pageCounter = !localConfig.pageCounter ? 1 : localConfig.pageCounter + 1;
                event.event_properties = __assign$1(__assign$1({}, event.event_properties), { "[Amplitude] Page Counter": localConfig.pageCounter });
              }
              return [2, event];
          }
        });
      });
    },
    teardown: function() {
      return __awaiter(void 0, void 0, void 0, function() {
        return __generator(this, function(_a2) {
          if (globalScope) {
            globalScope.removeEventListener("popstate", trackHistoryPageViewWrapper);
            isTracking = false;
          }
          return [
            2
            /*return*/
          ];
        });
      });
    }
  };
  return plugin;
};
var getCampaignParams = function() {
  return __awaiter(void 0, void 0, void 0, function() {
    var _a;
    return __generator(this, function(_b) {
      switch (_b.label) {
        case 0:
          _a = omitUndefined;
          return [4, new CampaignParser$1().parse()];
        case 1:
          return [2, _a.apply(void 0, [_b.sent()])];
      }
    });
  });
};
var isCampaignEvent = function(event) {
  if (event.event_type === "$identify" && event.user_properties) {
    var properties = event.user_properties;
    var $set = properties[IdentifyOperation.SET] || {};
    var $unset = properties[IdentifyOperation.UNSET] || {};
    var userProperties_1 = __spreadArray(__spreadArray([], __read$1(Object.keys($set)), false), __read$1(Object.keys($unset)), false);
    return Object.keys(BASE_CAMPAIGN$1).every(function(value) {
      return userProperties_1.includes(value);
    });
  }
  return false;
};
var shouldTrackHistoryPageView = function(trackingOption, newURLStr, oldURLStr) {
  switch (trackingOption) {
    case "pathOnly": {
      if (oldURLStr == "")
        return true;
      var newURL = new URL(newURLStr);
      var oldURL = new URL(oldURLStr);
      var newBaseStr = newURL.origin + newURL.pathname;
      var oldBaseStr = oldURL.origin + oldURL.pathname;
      return newBaseStr !== oldBaseStr;
    }
    default:
      return newURLStr !== oldURLStr;
  }
};
var formInteractionTracking = function() {
  var observer;
  var eventListeners = [];
  var addEventListener = function(element, type2, handler) {
    element.addEventListener(type2, handler);
    eventListeners.push({
      element,
      type: type2,
      handler
    });
  };
  var removeClickListeners = function() {
    eventListeners.forEach(function(_a) {
      var element = _a.element, type2 = _a.type, handler = _a.handler;
      element === null || element === void 0 ? void 0 : element.removeEventListener(type2, handler);
    });
    eventListeners = [];
  };
  var name = "@amplitude/plugin-form-interaction-tracking-browser";
  var type = "enrichment";
  var setup = function(config2, amplitude) {
    return __awaiter(void 0, void 0, void 0, function() {
      var initializeFormTracking, window_1;
      return __generator(this, function(_a) {
        initializeFormTracking = function() {
          if (!amplitude) {
            config2.loggerProvider.warn("Form interaction tracking requires a later version of @amplitude/analytics-browser. Form interaction events are not tracked.");
            return;
          }
          if (typeof document === "undefined") {
            return;
          }
          var addFormInteractionListener = function(form) {
            var hasFormChanged = false;
            addEventListener(form, "change", function() {
              var _a2;
              var formDestination = extractFormAction(form);
              if (!hasFormChanged) {
                amplitude.track(DEFAULT_FORM_START_EVENT, (_a2 = {}, _a2[FORM_ID] = stringOrUndefined(form.id), _a2[FORM_NAME] = stringOrUndefined(form.name), _a2[FORM_DESTINATION] = formDestination, _a2));
              }
              hasFormChanged = true;
            });
            addEventListener(form, "submit", function() {
              var _a2, _b;
              var formDestination = extractFormAction(form);
              if (!hasFormChanged) {
                amplitude.track(DEFAULT_FORM_START_EVENT, (_a2 = {}, _a2[FORM_ID] = stringOrUndefined(form.id), _a2[FORM_NAME] = stringOrUndefined(form.name), _a2[FORM_DESTINATION] = formDestination, _a2));
              }
              amplitude.track(DEFAULT_FORM_SUBMIT_EVENT, (_b = {}, _b[FORM_ID] = stringOrUndefined(form.id), _b[FORM_NAME] = stringOrUndefined(form.name), _b[FORM_DESTINATION] = formDestination, _b));
              hasFormChanged = false;
            });
          };
          var forms = Array.from(document.getElementsByTagName("form"));
          forms.forEach(addFormInteractionListener);
          if (typeof MutationObserver !== "undefined") {
            observer = new MutationObserver(function(mutations) {
              mutations.forEach(function(mutation) {
                mutation.addedNodes.forEach(function(node) {
                  if (node.nodeName === "FORM") {
                    addFormInteractionListener(node);
                  }
                  if ("querySelectorAll" in node && typeof node.querySelectorAll === "function") {
                    Array.from(node.querySelectorAll("form")).map(addFormInteractionListener);
                  }
                });
              });
            });
            observer.observe(document.body, {
              subtree: true,
              childList: true
            });
          }
        };
        if (document.readyState === "complete") {
          initializeFormTracking();
        } else {
          window_1 = getGlobalScope$1();
          if (window_1) {
            window_1.addEventListener("load", initializeFormTracking);
          } else {
            config2.loggerProvider.debug("Form interaction tracking is not installed because global is undefined.");
          }
        }
        return [
          2
          /*return*/
        ];
      });
    });
  };
  var execute = function(event) {
    return __awaiter(void 0, void 0, void 0, function() {
      return __generator(this, function(_a) {
        return [2, event];
      });
    });
  };
  var teardown = function() {
    return __awaiter(void 0, void 0, void 0, function() {
      return __generator(this, function(_a) {
        observer === null || observer === void 0 ? void 0 : observer.disconnect();
        removeClickListeners();
        return [
          2
          /*return*/
        ];
      });
    });
  };
  return {
    name,
    type,
    setup,
    execute,
    teardown
  };
};
var stringOrUndefined = function(name) {
  if (typeof name !== "string") {
    return void 0;
  }
  return name;
};
var extractFormAction = function(form) {
  var formDestination = form.getAttribute("action");
  try {
    formDestination = new URL(encodeURI(formDestination !== null && formDestination !== void 0 ? formDestination : ""), window.location.href).href;
  } catch (_a) {
  }
  return formDestination;
};
var fileDownloadTracking = function() {
  var observer;
  var eventListeners = [];
  var addEventListener = function(element, type2, handler) {
    element.addEventListener(type2, handler);
    eventListeners.push({
      element,
      type: type2,
      handler
    });
  };
  var removeClickListeners = function() {
    eventListeners.forEach(function(_a) {
      var element = _a.element, type2 = _a.type, handler = _a.handler;
      element === null || element === void 0 ? void 0 : element.removeEventListener(type2, handler);
    });
    eventListeners = [];
  };
  var name = "@amplitude/plugin-file-download-tracking-browser";
  var type = "enrichment";
  var setup = function(config2, amplitude) {
    return __awaiter(void 0, void 0, void 0, function() {
      var initializeFileDownloadTracking, window_1;
      return __generator(this, function(_a) {
        initializeFileDownloadTracking = function() {
          if (!amplitude) {
            config2.loggerProvider.warn("File download tracking requires a later version of @amplitude/analytics-browser. File download events are not tracked.");
            return;
          }
          if (typeof document === "undefined") {
            return;
          }
          var addFileDownloadListener = function(a) {
            var url;
            try {
              url = new URL(a.href, window.location.href);
            } catch (_a2) {
              return;
            }
            var result = ext.exec(url.href);
            var fileExtension = result === null || result === void 0 ? void 0 : result[1];
            if (fileExtension) {
              addEventListener(a, "click", function() {
                var _a2;
                if (fileExtension) {
                  amplitude.track(DEFAULT_FILE_DOWNLOAD_EVENT, (_a2 = {}, _a2[FILE_EXTENSION] = fileExtension, _a2[FILE_NAME] = url.pathname, _a2[LINK_ID] = a.id, _a2[LINK_TEXT] = a.text, _a2[LINK_URL] = a.href, _a2));
                }
              });
            }
          };
          var ext = /\.(pdf|xlsx?|docx?|txt|rtf|csv|exe|key|pp(s|t|tx)|7z|pkg|rar|gz|zip|avi|mov|mp4|mpe?g|wmv|midi?|mp3|wav|wma)(\?.+)?$/;
          var links = Array.from(document.getElementsByTagName("a"));
          links.forEach(addFileDownloadListener);
          if (typeof MutationObserver !== "undefined") {
            observer = new MutationObserver(function(mutations) {
              mutations.forEach(function(mutation) {
                mutation.addedNodes.forEach(function(node) {
                  if (node.nodeName === "A") {
                    addFileDownloadListener(node);
                  }
                  if ("querySelectorAll" in node && typeof node.querySelectorAll === "function") {
                    Array.from(node.querySelectorAll("a")).map(addFileDownloadListener);
                  }
                });
              });
            });
            observer.observe(document.body, {
              subtree: true,
              childList: true
            });
          }
        };
        if (document.readyState === "complete") {
          initializeFileDownloadTracking();
        } else {
          window_1 = getGlobalScope$1();
          if (window_1) {
            window_1.addEventListener("load", initializeFileDownloadTracking);
          } else {
            config2.loggerProvider.debug("File download tracking is not installed because global is undefined.");
          }
        }
        return [
          2
          /*return*/
        ];
      });
    });
  };
  var execute = function(event) {
    return __awaiter(void 0, void 0, void 0, function() {
      return __generator(this, function(_a) {
        return [2, event];
      });
    });
  };
  var teardown = function() {
    return __awaiter(void 0, void 0, void 0, function() {
      return __generator(this, function(_a) {
        observer === null || observer === void 0 ? void 0 : observer.disconnect();
        removeClickListeners();
        return [
          2
          /*return*/
        ];
      });
    });
  };
  return {
    name,
    type,
    setup,
    execute,
    teardown
  };
};
var notified = false;
var detNotify = function(config2) {
  if (notified || config2.defaultTracking !== void 0) {
    return;
  }
  var message = "`options.defaultTracking` is set to undefined. This implicitly configures your Amplitude instance to track Page Views, Sessions, File Downloads, and Form Interactions. You can suppress this warning by explicitly setting a value to `options.defaultTracking`. The value must either be a boolean, to enable and disable all default events, or an object, for advanced configuration. For example:\n\namplitude.init(<YOUR_API_KEY>, {\n  defaultTracking: true,\n});\n\nVisit https://www.docs.developers.amplitude.com/data/sdks/browser-2/#tracking-default-events for more details.";
  config2.loggerProvider.warn(message);
  notified = true;
};
var networkConnectivityCheckerPlugin = function() {
  var name = "@amplitude/plugin-network-checker-browser";
  var type = "before";
  var globalScope = getGlobalScope$1();
  var eventListeners = [];
  var addNetworkListener = function(type2, handler) {
    if (globalScope) {
      globalScope.addEventListener(type2, handler);
      eventListeners.push({
        type: type2,
        handler
      });
    }
  };
  var removeNetworkListeners = function() {
    eventListeners.forEach(function(_a) {
      var type2 = _a.type, handler = _a.handler;
      if (globalScope) {
        globalScope.removeEventListener(type2, handler);
      }
    });
    eventListeners = [];
  };
  var setup = function(config2, amplitude) {
    return __awaiter(void 0, void 0, void 0, function() {
      return __generator(this, function(_a) {
        if (typeof navigator === "undefined") {
          config2.loggerProvider.debug("Network connectivity checker plugin is disabled because navigator is not available.");
          config2.offline = false;
          return [
            2
            /*return*/
          ];
        }
        config2.offline = !navigator.onLine;
        addNetworkListener("online", function() {
          config2.loggerProvider.debug("Network connectivity changed to online.");
          config2.offline = false;
          setTimeout(function() {
            amplitude.flush();
          }, config2.flushIntervalMillis);
        });
        addNetworkListener("offline", function() {
          config2.loggerProvider.debug("Network connectivity changed to offline.");
          config2.offline = true;
        });
        return [
          2
          /*return*/
        ];
      });
    });
  };
  var teardown = function() {
    return __awaiter(void 0, void 0, void 0, function() {
      return __generator(this, function(_a) {
        removeNetworkListeners();
        return [
          2
          /*return*/
        ];
      });
    });
  };
  return {
    name,
    type,
    setup,
    teardown
  };
};
var UNEXPECTED_NETWORK_ERROR_MESSAGE = "Network error occurred, remote config fetch failed";
var SUCCESS_REMOTE_CONFIG = "Remote config successfully fetched";
var MAX_RETRIES_EXCEEDED_MESSAGE = "Remote config fetch rejected due to exceeded retry count";
var TIMEOUT_MESSAGE = "Remote config fetch rejected due to timeout after 5 seconds";
var UNEXPECTED_ERROR_MESSAGE = "Unexpected error occurred";
var REMOTE_CONFIG_SERVER_URL = "https://sr-client-cfg.amplitude.com/config";
var REMOTE_CONFIG_SERVER_URL_STAGING = "https://sr-client-cfg.stag2.amplitude.com/config";
var REMOTE_CONFIG_SERVER_URL_EU = "https://sr-client-cfg.eu.amplitude.com/config";
var RemoteConfigFetch = (
  /** @class */
  function() {
    function RemoteConfigFetch2(_a) {
      var localConfig = _a.localConfig, configKeys = _a.configKeys;
      var _this = this;
      this.retryTimeout = 1e3;
      this.attempts = 0;
      this.sessionTargetingMatch = false;
      this.metrics = {};
      this.getRemoteConfig = function(configNamespace, key, sessionId) {
        return __awaiter(_this, void 0, void 0, function() {
          var fetchStartTime, configAPIResponse, remoteConfig;
          return __generator(this, function(_a2) {
            switch (_a2.label) {
              case 0:
                fetchStartTime = Date.now();
                return [4, this.fetchWithTimeout(sessionId)];
              case 1:
                configAPIResponse = _a2.sent();
                if (configAPIResponse) {
                  remoteConfig = configAPIResponse.configs && configAPIResponse.configs[configNamespace];
                  if (remoteConfig) {
                    this.metrics.fetchTimeAPISuccess = Date.now() - fetchStartTime;
                    return [2, remoteConfig[key]];
                  }
                }
                this.metrics.fetchTimeAPIFail = Date.now() - fetchStartTime;
                return [2, void 0];
            }
          });
        });
      };
      this.fetchWithTimeout = function(sessionId) {
        return __awaiter(_this, void 0, void 0, function() {
          var controller, timeoutId, remoteConfig;
          return __generator(this, function(_a2) {
            switch (_a2.label) {
              case 0:
                controller = new AbortController();
                timeoutId = setTimeout(function() {
                  return controller.abort();
                }, 5e3);
                return [4, this.fetchRemoteConfig(controller.signal, sessionId)];
              case 1:
                remoteConfig = _a2.sent();
                clearTimeout(timeoutId);
                return [2, remoteConfig];
            }
          });
        });
      };
      this.fetchRemoteConfig = function(signal, sessionId) {
        return __awaiter(_this, void 0, void 0, function() {
          var urlParams, _a2, _b, configKey, options, serverUrl, res, parsedStatus, e_1, knownError;
          var e_2, _c;
          var _d;
          return __generator(this, function(_e) {
            switch (_e.label) {
              case 0:
                if (sessionId === this.lastFetchedSessionId && this.attempts >= this.localConfig.flushMaxRetries) {
                  return [2, this.completeRequest({ err: MAX_RETRIES_EXCEEDED_MESSAGE })];
                } else if (signal.aborted) {
                  return [2, this.completeRequest({ err: TIMEOUT_MESSAGE })];
                } else if (sessionId !== this.lastFetchedSessionId) {
                  this.lastFetchedSessionId = sessionId;
                  this.attempts = 0;
                }
                _e.label = 1;
              case 1:
                _e.trys.push([1, 3, , 4]);
                urlParams = new URLSearchParams({
                  api_key: this.localConfig.apiKey
                });
                try {
                  for (_a2 = __values$1(this.configKeys), _b = _a2.next(); !_b.done; _b = _a2.next()) {
                    configKey = _b.value;
                    urlParams.append("config_keys", configKey);
                  }
                } catch (e_2_1) {
                  e_2 = { error: e_2_1 };
                } finally {
                  try {
                    if (_b && !_b.done && (_c = _a2.return)) _c.call(_a2);
                  } finally {
                    if (e_2) throw e_2.error;
                  }
                }
                if (sessionId) {
                  urlParams.set("session_id", String(sessionId));
                }
                options = {
                  headers: {
                    Accept: "*/*"
                  },
                  method: "GET"
                };
                serverUrl = "".concat(this.getServerUrl(), "?").concat(urlParams.toString());
                this.attempts += 1;
                return [4, fetch(serverUrl, __assign$1(__assign$1({}, options), { signal }))];
              case 2:
                res = _e.sent();
                if (res === null) {
                  return [2, this.completeRequest({ err: UNEXPECTED_ERROR_MESSAGE })];
                }
                parsedStatus = new BaseTransport().buildStatus(res.status);
                switch (parsedStatus) {
                  case Status.Success:
                    this.attempts = 0;
                    return [2, this.parseAndStoreConfig(res)];
                  case Status.Failed:
                    return [2, this.retryFetch(signal, sessionId)];
                  default:
                    return [2, this.completeRequest({ err: UNEXPECTED_NETWORK_ERROR_MESSAGE })];
                }
              case 3:
                e_1 = _e.sent();
                knownError = e_1;
                if (signal.aborted) {
                  return [2, this.completeRequest({ err: TIMEOUT_MESSAGE })];
                }
                return [2, this.completeRequest({ err: (_d = knownError.message) !== null && _d !== void 0 ? _d : UNEXPECTED_ERROR_MESSAGE })];
              case 4:
                return [
                  2
                  /*return*/
                ];
            }
          });
        });
      };
      this.retryFetch = function(signal, sessionId) {
        return __awaiter(_this, void 0, void 0, function() {
          var _this2 = this;
          return __generator(this, function(_a2) {
            switch (_a2.label) {
              case 0:
                return [4, new Promise(function(resolve) {
                  return setTimeout(resolve, _this2.attempts * _this2.retryTimeout);
                })];
              case 1:
                _a2.sent();
                return [2, this.fetchRemoteConfig(signal, sessionId)];
            }
          });
        });
      };
      this.parseAndStoreConfig = function(res) {
        return __awaiter(_this, void 0, void 0, function() {
          var remoteConfig;
          return __generator(this, function(_a2) {
            switch (_a2.label) {
              case 0:
                return [4, res.json()];
              case 1:
                remoteConfig = _a2.sent();
                this.completeRequest({ success: SUCCESS_REMOTE_CONFIG });
                return [2, remoteConfig];
            }
          });
        });
      };
      this.localConfig = localConfig;
      this.configKeys = configKeys;
    }
    RemoteConfigFetch2.prototype.getServerUrl = function() {
      if (this.localConfig.serverZone === ServerZone.STAGING) {
        return REMOTE_CONFIG_SERVER_URL_STAGING;
      }
      if (this.localConfig.serverZone === ServerZone.EU) {
        return REMOTE_CONFIG_SERVER_URL_EU;
      }
      return REMOTE_CONFIG_SERVER_URL;
    };
    RemoteConfigFetch2.prototype.completeRequest = function(_a) {
      var err = _a.err, success = _a.success;
      if (err) {
        throw new Error(err);
      } else if (success) {
        this.localConfig.loggerProvider.log(success);
      }
    };
    return RemoteConfigFetch2;
  }()
);
var createRemoteConfigFetch$1 = function(_a) {
  var localConfig = _a.localConfig, configKeys = _a.configKeys;
  return __awaiter(void 0, void 0, void 0, function() {
    return __generator(this, function(_b) {
      return [2, new RemoteConfigFetch({ localConfig, configKeys })];
    });
  });
};
var createRemoteConfigFetch = createRemoteConfigFetch$1;
var BrowserJoinedConfigGenerator = (
  /** @class */
  function() {
    function BrowserJoinedConfigGenerator2(localConfig) {
      this.config = localConfig;
      this.config.loggerProvider.debug("Local configuration before merging with remote config", JSON.stringify(this.config, null, 2));
    }
    BrowserJoinedConfigGenerator2.prototype.initialize = function() {
      return __awaiter(this, void 0, void 0, function() {
        var _a;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              _a = this;
              return [4, createRemoteConfigFetch({
                localConfig: this.config,
                configKeys: ["analyticsSDK"]
              })];
            case 1:
              _a.remoteConfigFetch = _b.sent();
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    BrowserJoinedConfigGenerator2.prototype.generateJoinedConfig = function() {
      var _a, _b, _c, _d, _e;
      var _f;
      return __awaiter(this, void 0, void 0, function() {
        var remoteConfig, _g, transformedAutocaptureRemoteConfig, transformedRcElementInteractions, exactAllowList, regexList, _h, _j, pattern, combinedPageUrlAllowlist, e_1;
        var e_2, _k;
        return __generator(this, function(_l) {
          switch (_l.label) {
            case 0:
              _l.trys.push([0, 3, , 4]);
              _g = this.remoteConfigFetch;
              if (!_g) return [3, 2];
              return [4, this.remoteConfigFetch.getRemoteConfig("analyticsSDK", "browserSDK", this.config.sessionId)];
            case 1:
              _g = _l.sent();
              _l.label = 2;
            case 2:
              remoteConfig = _g;
              this.config.loggerProvider.debug("Remote configuration:", JSON.stringify(remoteConfig, null, 2));
              if (remoteConfig && "autocapture" in remoteConfig) {
                if (typeof remoteConfig.autocapture === "boolean") {
                  this.config.autocapture = remoteConfig.autocapture;
                }
                if (typeof remoteConfig.autocapture === "object") {
                  transformedAutocaptureRemoteConfig = __assign$1({}, remoteConfig.autocapture);
                  if (this.config.autocapture === void 0) {
                    this.config.autocapture = remoteConfig.autocapture;
                  }
                  if (typeof remoteConfig.autocapture.elementInteractions === "object" && ((_a = remoteConfig.autocapture.elementInteractions.pageUrlAllowlistRegex) === null || _a === void 0 ? void 0 : _a.length)) {
                    transformedAutocaptureRemoteConfig.elementInteractions = __assign$1({}, remoteConfig.autocapture.elementInteractions);
                    transformedRcElementInteractions = transformedAutocaptureRemoteConfig.elementInteractions;
                    exactAllowList = (_b = transformedRcElementInteractions.pageUrlAllowlist) !== null && _b !== void 0 ? _b : [];
                    regexList = [];
                    try {
                      for (_h = __values$1(remoteConfig.autocapture.elementInteractions.pageUrlAllowlistRegex), _j = _h.next(); !_j.done; _j = _h.next()) {
                        pattern = _j.value;
                        try {
                          regexList.push(new RegExp(pattern));
                        } catch (regexError) {
                          this.config.loggerProvider.warn("Invalid regex pattern: ".concat(pattern), regexError);
                        }
                      }
                    } catch (e_2_1) {
                      e_2 = { error: e_2_1 };
                    } finally {
                      try {
                        if (_j && !_j.done && (_k = _h.return)) _k.call(_h);
                      } finally {
                        if (e_2) throw e_2.error;
                      }
                    }
                    combinedPageUrlAllowlist = exactAllowList.concat(regexList);
                    transformedRcElementInteractions.pageUrlAllowlist = combinedPageUrlAllowlist;
                    delete transformedRcElementInteractions.pageUrlAllowlistRegex;
                  }
                  if (typeof this.config.autocapture === "boolean") {
                    this.config.autocapture = __assign$1({ attribution: this.config.autocapture, fileDownloads: this.config.autocapture, formInteractions: this.config.autocapture, pageViews: this.config.autocapture, sessions: this.config.autocapture, elementInteractions: this.config.autocapture }, transformedAutocaptureRemoteConfig);
                  }
                  if (typeof this.config.autocapture === "object") {
                    this.config.autocapture = __assign$1(__assign$1({}, this.config.autocapture), transformedAutocaptureRemoteConfig);
                  }
                }
                this.config.defaultTracking = this.config.autocapture;
              }
              this.config.loggerProvider.debug("Joined configuration: ", JSON.stringify(this.config, null, 2));
              (_c = (_f = this.config).requestMetadata) !== null && _c !== void 0 ? _c : _f.requestMetadata = new RequestMetadata();
              if ((_d = this.remoteConfigFetch) === null || _d === void 0 ? void 0 : _d.metrics.fetchTimeAPISuccess) {
                this.config.requestMetadata.recordHistogram("remote_config_fetch_time_API_success", this.remoteConfigFetch.metrics.fetchTimeAPISuccess);
              }
              if ((_e = this.remoteConfigFetch) === null || _e === void 0 ? void 0 : _e.metrics.fetchTimeAPIFail) {
                this.config.requestMetadata.recordHistogram("remote_config_fetch_time_API_fail", this.remoteConfigFetch.metrics.fetchTimeAPIFail);
              }
              return [3, 4];
            case 3:
              e_1 = _l.sent();
              this.config.loggerProvider.error("Failed to fetch remote configuration because of error: ", e_1);
              return [3, 4];
            case 4:
              return [2, this.config];
          }
        });
      });
    };
    return BrowserJoinedConfigGenerator2;
  }()
);
var createBrowserJoinedConfigGenerator = function(localConfig) {
  return __awaiter(void 0, void 0, void 0, function() {
    var joinedConfigGenerator;
    return __generator(this, function(_a) {
      switch (_a.label) {
        case 0:
          joinedConfigGenerator = new BrowserJoinedConfigGenerator(localConfig);
          return [4, joinedConfigGenerator.initialize()];
        case 1:
          _a.sent();
          return [2, joinedConfigGenerator];
      }
    });
  });
};
var PLUGIN_NAME$1 = "@amplitude/plugin-autocapture-browser";
var AMPLITUDE_ELEMENT_CLICKED_EVENT = "[Amplitude] Element Clicked";
var AMPLITUDE_ELEMENT_CHANGED_EVENT = "[Amplitude] Element Changed";
var AMPLITUDE_EVENT_PROP_ELEMENT_ID = "[Amplitude] Element ID";
var AMPLITUDE_EVENT_PROP_ELEMENT_CLASS = "[Amplitude] Element Class";
var AMPLITUDE_EVENT_PROP_ELEMENT_TAG = "[Amplitude] Element Tag";
var AMPLITUDE_EVENT_PROP_ELEMENT_TEXT = "[Amplitude] Element Text";
var AMPLITUDE_EVENT_PROP_ELEMENT_HIERARCHY = "[Amplitude] Element Hierarchy";
var AMPLITUDE_EVENT_PROP_ELEMENT_HREF = "[Amplitude] Element Href";
var AMPLITUDE_EVENT_PROP_ELEMENT_POSITION_LEFT = "[Amplitude] Element Position Left";
var AMPLITUDE_EVENT_PROP_ELEMENT_POSITION_TOP = "[Amplitude] Element Position Top";
var AMPLITUDE_EVENT_PROP_ELEMENT_ARIA_LABEL = "[Amplitude] Element Aria Label";
var AMPLITUDE_EVENT_PROP_ELEMENT_ATTRIBUTES = "[Amplitude] Element Attributes";
var AMPLITUDE_EVENT_PROP_ELEMENT_PARENT_LABEL = "[Amplitude] Element Parent Label";
var AMPLITUDE_EVENT_PROP_PAGE_URL = "[Amplitude] Page URL";
var AMPLITUDE_EVENT_PROP_PAGE_TITLE = "[Amplitude] Page Title";
var AMPLITUDE_EVENT_PROP_VIEWPORT_HEIGHT = "[Amplitude] Viewport Height";
var AMPLITUDE_EVENT_PROP_VIEWPORT_WIDTH = "[Amplitude] Viewport Width";
var AMPLITUDE_ORIGIN = "https://app.amplitude.com";
var AMPLITUDE_ORIGIN_EU = "https://app.eu.amplitude.com";
var AMPLITUDE_ORIGIN_STAGING = "https://apps.stag2.amplitude.com";
var AMPLITUDE_ORIGINS_MAP = {
  US: AMPLITUDE_ORIGIN,
  EU: AMPLITUDE_ORIGIN_EU,
  STAGING: AMPLITUDE_ORIGIN_STAGING
};
var AMPLITUDE_VISUAL_TAGGING_SELECTOR_SCRIPT_URL = "https://cdn.amplitude.com/libs/visual-tagging-selector-1.0.0-alpha.js.gz";
var AMPLITUDE_VISUAL_TAGGING_HIGHLIGHT_CLASS = "amp-visual-tagging-selector-highlight";
function isFunction(value) {
  return typeof value === "function";
}
function createErrorClass(createImpl) {
  var _super = function(instance) {
    Error.call(instance);
    instance.stack = new Error().stack;
  };
  var ctorFunc = createImpl(_super);
  ctorFunc.prototype = Object.create(Error.prototype);
  ctorFunc.prototype.constructor = ctorFunc;
  return ctorFunc;
}
var UnsubscriptionError = createErrorClass(function(_super) {
  return function UnsubscriptionErrorImpl(errors) {
    _super(this);
    this.message = errors ? errors.length + " errors occurred during unsubscription:\n" + errors.map(function(err, i) {
      return i + 1 + ") " + err.toString();
    }).join("\n  ") : "";
    this.name = "UnsubscriptionError";
    this.errors = errors;
  };
});
function arrRemove(arr, item) {
  if (arr) {
    var index = arr.indexOf(item);
    0 <= index && arr.splice(index, 1);
  }
}
var Subscription = function() {
  function Subscription2(initialTeardown) {
    this.initialTeardown = initialTeardown;
    this.closed = false;
    this._parentage = null;
    this._finalizers = null;
  }
  Subscription2.prototype.unsubscribe = function() {
    var e_1, _a, e_2, _b;
    var errors;
    if (!this.closed) {
      this.closed = true;
      var _parentage = this._parentage;
      if (_parentage) {
        this._parentage = null;
        if (Array.isArray(_parentage)) {
          try {
            for (var _parentage_1 = __values$1(_parentage), _parentage_1_1 = _parentage_1.next(); !_parentage_1_1.done; _parentage_1_1 = _parentage_1.next()) {
              var parent_1 = _parentage_1_1.value;
              parent_1.remove(this);
            }
          } catch (e_1_1) {
            e_1 = { error: e_1_1 };
          } finally {
            try {
              if (_parentage_1_1 && !_parentage_1_1.done && (_a = _parentage_1.return)) _a.call(_parentage_1);
            } finally {
              if (e_1) throw e_1.error;
            }
          }
        } else {
          _parentage.remove(this);
        }
      }
      var initialFinalizer = this.initialTeardown;
      if (isFunction(initialFinalizer)) {
        try {
          initialFinalizer();
        } catch (e) {
          errors = e instanceof UnsubscriptionError ? e.errors : [e];
        }
      }
      var _finalizers = this._finalizers;
      if (_finalizers) {
        this._finalizers = null;
        try {
          for (var _finalizers_1 = __values$1(_finalizers), _finalizers_1_1 = _finalizers_1.next(); !_finalizers_1_1.done; _finalizers_1_1 = _finalizers_1.next()) {
            var finalizer = _finalizers_1_1.value;
            try {
              execFinalizer(finalizer);
            } catch (err) {
              errors = errors !== null && errors !== void 0 ? errors : [];
              if (err instanceof UnsubscriptionError) {
                errors = __spreadArray(__spreadArray([], __read$1(errors)), __read$1(err.errors));
              } else {
                errors.push(err);
              }
            }
          }
        } catch (e_2_1) {
          e_2 = { error: e_2_1 };
        } finally {
          try {
            if (_finalizers_1_1 && !_finalizers_1_1.done && (_b = _finalizers_1.return)) _b.call(_finalizers_1);
          } finally {
            if (e_2) throw e_2.error;
          }
        }
      }
      if (errors) {
        throw new UnsubscriptionError(errors);
      }
    }
  };
  Subscription2.prototype.add = function(teardown) {
    var _a;
    if (teardown && teardown !== this) {
      if (this.closed) {
        execFinalizer(teardown);
      } else {
        if (teardown instanceof Subscription2) {
          if (teardown.closed || teardown._hasParent(this)) {
            return;
          }
          teardown._addParent(this);
        }
        (this._finalizers = (_a = this._finalizers) !== null && _a !== void 0 ? _a : []).push(teardown);
      }
    }
  };
  Subscription2.prototype._hasParent = function(parent) {
    var _parentage = this._parentage;
    return _parentage === parent || Array.isArray(_parentage) && _parentage.includes(parent);
  };
  Subscription2.prototype._addParent = function(parent) {
    var _parentage = this._parentage;
    this._parentage = Array.isArray(_parentage) ? (_parentage.push(parent), _parentage) : _parentage ? [_parentage, parent] : parent;
  };
  Subscription2.prototype._removeParent = function(parent) {
    var _parentage = this._parentage;
    if (_parentage === parent) {
      this._parentage = null;
    } else if (Array.isArray(_parentage)) {
      arrRemove(_parentage, parent);
    }
  };
  Subscription2.prototype.remove = function(teardown) {
    var _finalizers = this._finalizers;
    _finalizers && arrRemove(_finalizers, teardown);
    if (teardown instanceof Subscription2) {
      teardown._removeParent(this);
    }
  };
  Subscription2.EMPTY = function() {
    var empty = new Subscription2();
    empty.closed = true;
    return empty;
  }();
  return Subscription2;
}();
var EMPTY_SUBSCRIPTION = Subscription.EMPTY;
function isSubscription(value) {
  return value instanceof Subscription || value && "closed" in value && isFunction(value.remove) && isFunction(value.add) && isFunction(value.unsubscribe);
}
function execFinalizer(finalizer) {
  if (isFunction(finalizer)) {
    finalizer();
  } else {
    finalizer.unsubscribe();
  }
}
var config = {
  Promise: void 0
};
var timeoutProvider = {
  setTimeout: function(handler, timeout2) {
    var args = [];
    for (var _i = 2; _i < arguments.length; _i++) {
      args[_i - 2] = arguments[_i];
    }
    return setTimeout.apply(void 0, __spreadArray([handler, timeout2], __read$1(args)));
  },
  clearTimeout: function(handle) {
    return clearTimeout(handle);
  },
  delegate: void 0
};
function reportUnhandledError(err) {
  timeoutProvider.setTimeout(function() {
    {
      throw err;
    }
  });
}
function noop() {
}
function errorContext(cb) {
  {
    cb();
  }
}
var Subscriber = function(_super) {
  __extends(Subscriber2, _super);
  function Subscriber2(destination) {
    var _this = _super.call(this) || this;
    _this.isStopped = false;
    if (destination) {
      _this.destination = destination;
      if (isSubscription(destination)) {
        destination.add(_this);
      }
    } else {
      _this.destination = EMPTY_OBSERVER;
    }
    return _this;
  }
  Subscriber2.create = function(next, error, complete) {
    return new SafeSubscriber(next, error, complete);
  };
  Subscriber2.prototype.next = function(value) {
    if (this.isStopped) ;
    else {
      this._next(value);
    }
  };
  Subscriber2.prototype.error = function(err) {
    if (this.isStopped) ;
    else {
      this.isStopped = true;
      this._error(err);
    }
  };
  Subscriber2.prototype.complete = function() {
    if (this.isStopped) ;
    else {
      this.isStopped = true;
      this._complete();
    }
  };
  Subscriber2.prototype.unsubscribe = function() {
    if (!this.closed) {
      this.isStopped = true;
      _super.prototype.unsubscribe.call(this);
      this.destination = null;
    }
  };
  Subscriber2.prototype._next = function(value) {
    this.destination.next(value);
  };
  Subscriber2.prototype._error = function(err) {
    try {
      this.destination.error(err);
    } finally {
      this.unsubscribe();
    }
  };
  Subscriber2.prototype._complete = function() {
    try {
      this.destination.complete();
    } finally {
      this.unsubscribe();
    }
  };
  return Subscriber2;
}(Subscription);
var ConsumerObserver = function() {
  function ConsumerObserver2(partialObserver) {
    this.partialObserver = partialObserver;
  }
  ConsumerObserver2.prototype.next = function(value) {
    var partialObserver = this.partialObserver;
    if (partialObserver.next) {
      try {
        partialObserver.next(value);
      } catch (error) {
        handleUnhandledError(error);
      }
    }
  };
  ConsumerObserver2.prototype.error = function(err) {
    var partialObserver = this.partialObserver;
    if (partialObserver.error) {
      try {
        partialObserver.error(err);
      } catch (error) {
        handleUnhandledError(error);
      }
    } else {
      handleUnhandledError(err);
    }
  };
  ConsumerObserver2.prototype.complete = function() {
    var partialObserver = this.partialObserver;
    if (partialObserver.complete) {
      try {
        partialObserver.complete();
      } catch (error) {
        handleUnhandledError(error);
      }
    }
  };
  return ConsumerObserver2;
}();
var SafeSubscriber = function(_super) {
  __extends(SafeSubscriber2, _super);
  function SafeSubscriber2(observerOrNext, error, complete) {
    var _this = _super.call(this) || this;
    var partialObserver;
    if (isFunction(observerOrNext) || !observerOrNext) {
      partialObserver = {
        next: observerOrNext !== null && observerOrNext !== void 0 ? observerOrNext : void 0,
        error: error !== null && error !== void 0 ? error : void 0,
        complete: complete !== null && complete !== void 0 ? complete : void 0
      };
    } else {
      {
        partialObserver = observerOrNext;
      }
    }
    _this.destination = new ConsumerObserver(partialObserver);
    return _this;
  }
  return SafeSubscriber2;
}(Subscriber);
function handleUnhandledError(error) {
  {
    reportUnhandledError(error);
  }
}
function defaultErrorHandler(err) {
  throw err;
}
var EMPTY_OBSERVER = {
  closed: true,
  next: noop,
  error: defaultErrorHandler,
  complete: noop
};
var observable = function() {
  return typeof Symbol === "function" && Symbol.observable || "@@observable";
}();
function identity(x) {
  return x;
}
function pipeFromArray(fns) {
  if (fns.length === 0) {
    return identity;
  }
  if (fns.length === 1) {
    return fns[0];
  }
  return function piped(input) {
    return fns.reduce(function(prev, fn) {
      return fn(prev);
    }, input);
  };
}
var Observable = function() {
  function Observable2(subscribe) {
    if (subscribe) {
      this._subscribe = subscribe;
    }
  }
  Observable2.prototype.lift = function(operator) {
    var observable2 = new Observable2();
    observable2.source = this;
    observable2.operator = operator;
    return observable2;
  };
  Observable2.prototype.subscribe = function(observerOrNext, error, complete) {
    var _this = this;
    var subscriber = isSubscriber(observerOrNext) ? observerOrNext : new SafeSubscriber(observerOrNext, error, complete);
    errorContext(function() {
      var _a = _this, operator = _a.operator, source = _a.source;
      subscriber.add(operator ? operator.call(subscriber, source) : source ? _this._subscribe(subscriber) : _this._trySubscribe(subscriber));
    });
    return subscriber;
  };
  Observable2.prototype._trySubscribe = function(sink) {
    try {
      return this._subscribe(sink);
    } catch (err) {
      sink.error(err);
    }
  };
  Observable2.prototype.forEach = function(next, promiseCtor) {
    var _this = this;
    promiseCtor = getPromiseCtor(promiseCtor);
    return new promiseCtor(function(resolve, reject) {
      var subscriber = new SafeSubscriber({
        next: function(value) {
          try {
            next(value);
          } catch (err) {
            reject(err);
            subscriber.unsubscribe();
          }
        },
        error: reject,
        complete: resolve
      });
      _this.subscribe(subscriber);
    });
  };
  Observable2.prototype._subscribe = function(subscriber) {
    var _a;
    return (_a = this.source) === null || _a === void 0 ? void 0 : _a.subscribe(subscriber);
  };
  Observable2.prototype[observable] = function() {
    return this;
  };
  Observable2.prototype.pipe = function() {
    var operations = [];
    for (var _i = 0; _i < arguments.length; _i++) {
      operations[_i] = arguments[_i];
    }
    return pipeFromArray(operations)(this);
  };
  Observable2.prototype.toPromise = function(promiseCtor) {
    var _this = this;
    promiseCtor = getPromiseCtor(promiseCtor);
    return new promiseCtor(function(resolve, reject) {
      var value;
      _this.subscribe(function(x) {
        return value = x;
      }, function(err) {
        return reject(err);
      }, function() {
        return resolve(value);
      });
    });
  };
  Observable2.create = function(subscribe) {
    return new Observable2(subscribe);
  };
  return Observable2;
}();
function getPromiseCtor(promiseCtor) {
  var _a;
  return (_a = promiseCtor !== null && promiseCtor !== void 0 ? promiseCtor : config.Promise) !== null && _a !== void 0 ? _a : Promise;
}
function isObserver(value) {
  return value && isFunction(value.next) && isFunction(value.error) && isFunction(value.complete);
}
function isSubscriber(value) {
  return value && value instanceof Subscriber || isObserver(value) && isSubscription(value);
}
function hasLift(source) {
  return isFunction(source === null || source === void 0 ? void 0 : source.lift);
}
function operate(init2) {
  return function(source) {
    if (hasLift(source)) {
      return source.lift(function(liftedSource) {
        try {
          return init2(liftedSource, this);
        } catch (err) {
          this.error(err);
        }
      });
    }
    throw new TypeError("Unable to lift unknown Observable type");
  };
}
function createOperatorSubscriber(destination, onNext, onComplete, onError, onFinalize) {
  return new OperatorSubscriber(destination, onNext, onComplete, onError, onFinalize);
}
var OperatorSubscriber = function(_super) {
  __extends(OperatorSubscriber2, _super);
  function OperatorSubscriber2(destination, onNext, onComplete, onError, onFinalize, shouldUnsubscribe) {
    var _this = _super.call(this, destination) || this;
    _this.onFinalize = onFinalize;
    _this.shouldUnsubscribe = shouldUnsubscribe;
    _this._next = onNext ? function(value) {
      try {
        onNext(value);
      } catch (err) {
        destination.error(err);
      }
    } : _super.prototype._next;
    _this._error = onError ? function(err) {
      try {
        onError(err);
      } catch (err2) {
        destination.error(err2);
      } finally {
        this.unsubscribe();
      }
    } : _super.prototype._error;
    _this._complete = onComplete ? function() {
      try {
        onComplete();
      } catch (err) {
        destination.error(err);
      } finally {
        this.unsubscribe();
      }
    } : _super.prototype._complete;
    return _this;
  }
  OperatorSubscriber2.prototype.unsubscribe = function() {
    var _a;
    if (!this.shouldUnsubscribe || this.shouldUnsubscribe()) {
      var closed_1 = this.closed;
      _super.prototype.unsubscribe.call(this);
      !closed_1 && ((_a = this.onFinalize) === null || _a === void 0 ? void 0 : _a.call(this));
    }
  };
  return OperatorSubscriber2;
}(Subscriber);
var ObjectUnsubscribedError = createErrorClass(function(_super) {
  return function ObjectUnsubscribedErrorImpl() {
    _super(this);
    this.name = "ObjectUnsubscribedError";
    this.message = "object unsubscribed";
  };
});
var Subject = function(_super) {
  __extends(Subject2, _super);
  function Subject2() {
    var _this = _super.call(this) || this;
    _this.closed = false;
    _this.currentObservers = null;
    _this.observers = [];
    _this.isStopped = false;
    _this.hasError = false;
    _this.thrownError = null;
    return _this;
  }
  Subject2.prototype.lift = function(operator) {
    var subject = new AnonymousSubject(this, this);
    subject.operator = operator;
    return subject;
  };
  Subject2.prototype._throwIfClosed = function() {
    if (this.closed) {
      throw new ObjectUnsubscribedError();
    }
  };
  Subject2.prototype.next = function(value) {
    var _this = this;
    errorContext(function() {
      var e_1, _a;
      _this._throwIfClosed();
      if (!_this.isStopped) {
        if (!_this.currentObservers) {
          _this.currentObservers = Array.from(_this.observers);
        }
        try {
          for (var _b = __values$1(_this.currentObservers), _c = _b.next(); !_c.done; _c = _b.next()) {
            var observer = _c.value;
            observer.next(value);
          }
        } catch (e_1_1) {
          e_1 = { error: e_1_1 };
        } finally {
          try {
            if (_c && !_c.done && (_a = _b.return)) _a.call(_b);
          } finally {
            if (e_1) throw e_1.error;
          }
        }
      }
    });
  };
  Subject2.prototype.error = function(err) {
    var _this = this;
    errorContext(function() {
      _this._throwIfClosed();
      if (!_this.isStopped) {
        _this.hasError = _this.isStopped = true;
        _this.thrownError = err;
        var observers = _this.observers;
        while (observers.length) {
          observers.shift().error(err);
        }
      }
    });
  };
  Subject2.prototype.complete = function() {
    var _this = this;
    errorContext(function() {
      _this._throwIfClosed();
      if (!_this.isStopped) {
        _this.isStopped = true;
        var observers = _this.observers;
        while (observers.length) {
          observers.shift().complete();
        }
      }
    });
  };
  Subject2.prototype.unsubscribe = function() {
    this.isStopped = this.closed = true;
    this.observers = this.currentObservers = null;
  };
  Object.defineProperty(Subject2.prototype, "observed", {
    get: function() {
      var _a;
      return ((_a = this.observers) === null || _a === void 0 ? void 0 : _a.length) > 0;
    },
    enumerable: false,
    configurable: true
  });
  Subject2.prototype._trySubscribe = function(subscriber) {
    this._throwIfClosed();
    return _super.prototype._trySubscribe.call(this, subscriber);
  };
  Subject2.prototype._subscribe = function(subscriber) {
    this._throwIfClosed();
    this._checkFinalizedStatuses(subscriber);
    return this._innerSubscribe(subscriber);
  };
  Subject2.prototype._innerSubscribe = function(subscriber) {
    var _this = this;
    var _a = this, hasError = _a.hasError, isStopped = _a.isStopped, observers = _a.observers;
    if (hasError || isStopped) {
      return EMPTY_SUBSCRIPTION;
    }
    this.currentObservers = null;
    observers.push(subscriber);
    return new Subscription(function() {
      _this.currentObservers = null;
      arrRemove(observers, subscriber);
    });
  };
  Subject2.prototype._checkFinalizedStatuses = function(subscriber) {
    var _a = this, hasError = _a.hasError, thrownError = _a.thrownError, isStopped = _a.isStopped;
    if (hasError) {
      subscriber.error(thrownError);
    } else if (isStopped) {
      subscriber.complete();
    }
  };
  Subject2.prototype.asObservable = function() {
    var observable2 = new Observable();
    observable2.source = this;
    return observable2;
  };
  Subject2.create = function(destination, source) {
    return new AnonymousSubject(destination, source);
  };
  return Subject2;
}(Observable);
var AnonymousSubject = function(_super) {
  __extends(AnonymousSubject2, _super);
  function AnonymousSubject2(destination, source) {
    var _this = _super.call(this) || this;
    _this.destination = destination;
    _this.source = source;
    return _this;
  }
  AnonymousSubject2.prototype.next = function(value) {
    var _a, _b;
    (_b = (_a = this.destination) === null || _a === void 0 ? void 0 : _a.next) === null || _b === void 0 ? void 0 : _b.call(_a, value);
  };
  AnonymousSubject2.prototype.error = function(err) {
    var _a, _b;
    (_b = (_a = this.destination) === null || _a === void 0 ? void 0 : _a.error) === null || _b === void 0 ? void 0 : _b.call(_a, err);
  };
  AnonymousSubject2.prototype.complete = function() {
    var _a, _b;
    (_b = (_a = this.destination) === null || _a === void 0 ? void 0 : _a.complete) === null || _b === void 0 ? void 0 : _b.call(_a);
  };
  AnonymousSubject2.prototype._subscribe = function(subscriber) {
    var _a, _b;
    return (_b = (_a = this.source) === null || _a === void 0 ? void 0 : _a.subscribe(subscriber)) !== null && _b !== void 0 ? _b : EMPTY_SUBSCRIPTION;
  };
  return AnonymousSubject2;
}(Subject);
var dateTimestampProvider = {
  now: function() {
    return Date.now();
  }
};
var Action = function(_super) {
  __extends(Action2, _super);
  function Action2(scheduler, work) {
    return _super.call(this) || this;
  }
  Action2.prototype.schedule = function(state, delay2) {
    return this;
  };
  return Action2;
}(Subscription);
var intervalProvider = {
  setInterval: function(handler, timeout2) {
    var args = [];
    for (var _i = 2; _i < arguments.length; _i++) {
      args[_i - 2] = arguments[_i];
    }
    return setInterval.apply(void 0, __spreadArray([handler, timeout2], __read$1(args)));
  },
  clearInterval: function(handle) {
    return clearInterval(handle);
  },
  delegate: void 0
};
var AsyncAction = function(_super) {
  __extends(AsyncAction2, _super);
  function AsyncAction2(scheduler, work) {
    var _this = _super.call(this, scheduler, work) || this;
    _this.scheduler = scheduler;
    _this.work = work;
    _this.pending = false;
    return _this;
  }
  AsyncAction2.prototype.schedule = function(state, delay2) {
    var _a;
    if (delay2 === void 0) {
      delay2 = 0;
    }
    if (this.closed) {
      return this;
    }
    this.state = state;
    var id = this.id;
    var scheduler = this.scheduler;
    if (id != null) {
      this.id = this.recycleAsyncId(scheduler, id, delay2);
    }
    this.pending = true;
    this.delay = delay2;
    this.id = (_a = this.id) !== null && _a !== void 0 ? _a : this.requestAsyncId(scheduler, this.id, delay2);
    return this;
  };
  AsyncAction2.prototype.requestAsyncId = function(scheduler, _id, delay2) {
    if (delay2 === void 0) {
      delay2 = 0;
    }
    return intervalProvider.setInterval(scheduler.flush.bind(scheduler, this), delay2);
  };
  AsyncAction2.prototype.recycleAsyncId = function(_scheduler, id, delay2) {
    if (delay2 === void 0) {
      delay2 = 0;
    }
    if (delay2 != null && this.delay === delay2 && this.pending === false) {
      return id;
    }
    if (id != null) {
      intervalProvider.clearInterval(id);
    }
    return void 0;
  };
  AsyncAction2.prototype.execute = function(state, delay2) {
    if (this.closed) {
      return new Error("executing a cancelled action");
    }
    this.pending = false;
    var error = this._execute(state, delay2);
    if (error) {
      return error;
    } else if (this.pending === false && this.id != null) {
      this.id = this.recycleAsyncId(this.scheduler, this.id, null);
    }
  };
  AsyncAction2.prototype._execute = function(state, _delay) {
    var errored = false;
    var errorValue;
    try {
      this.work(state);
    } catch (e) {
      errored = true;
      errorValue = e ? e : new Error("Scheduled action threw falsy error");
    }
    if (errored) {
      this.unsubscribe();
      return errorValue;
    }
  };
  AsyncAction2.prototype.unsubscribe = function() {
    if (!this.closed) {
      var _a = this, id = _a.id, scheduler = _a.scheduler;
      var actions = scheduler.actions;
      this.work = this.state = this.scheduler = null;
      this.pending = false;
      arrRemove(actions, this);
      if (id != null) {
        this.id = this.recycleAsyncId(scheduler, id, null);
      }
      this.delay = null;
      _super.prototype.unsubscribe.call(this);
    }
  };
  return AsyncAction2;
}(Action);
var Scheduler = function() {
  function Scheduler2(schedulerActionCtor, now) {
    if (now === void 0) {
      now = Scheduler2.now;
    }
    this.schedulerActionCtor = schedulerActionCtor;
    this.now = now;
  }
  Scheduler2.prototype.schedule = function(work, delay2, state) {
    if (delay2 === void 0) {
      delay2 = 0;
    }
    return new this.schedulerActionCtor(this, work).schedule(state, delay2);
  };
  Scheduler2.now = dateTimestampProvider.now;
  return Scheduler2;
}();
var AsyncScheduler = function(_super) {
  __extends(AsyncScheduler2, _super);
  function AsyncScheduler2(SchedulerAction, now) {
    if (now === void 0) {
      now = Scheduler.now;
    }
    var _this = _super.call(this, SchedulerAction, now) || this;
    _this.actions = [];
    _this._active = false;
    return _this;
  }
  AsyncScheduler2.prototype.flush = function(action) {
    var actions = this.actions;
    if (this._active) {
      actions.push(action);
      return;
    }
    var error;
    this._active = true;
    do {
      if (error = action.execute(action.state, action.delay)) {
        break;
      }
    } while (action = actions.shift());
    this._active = false;
    if (error) {
      while (action = actions.shift()) {
        action.unsubscribe();
      }
      throw error;
    }
  };
  return AsyncScheduler2;
}(Scheduler);
var asyncScheduler = new AsyncScheduler(AsyncAction);
var async = asyncScheduler;
var EMPTY = new Observable(function(subscriber) {
  return subscriber.complete();
});
function isScheduler(value) {
  return value && isFunction(value.schedule);
}
function last(arr) {
  return arr[arr.length - 1];
}
function popScheduler(args) {
  return isScheduler(last(args)) ? args.pop() : void 0;
}
function popNumber(args, defaultValue) {
  return typeof last(args) === "number" ? args.pop() : defaultValue;
}
var isArrayLike = function(x) {
  return x && typeof x.length === "number" && typeof x !== "function";
};
function isPromise(value) {
  return isFunction(value === null || value === void 0 ? void 0 : value.then);
}
function isInteropObservable(input) {
  return isFunction(input[observable]);
}
function isAsyncIterable(obj) {
  return Symbol.asyncIterator && isFunction(obj === null || obj === void 0 ? void 0 : obj[Symbol.asyncIterator]);
}
function createInvalidObservableTypeError(input) {
  return new TypeError("You provided " + (input !== null && typeof input === "object" ? "an invalid object" : "'" + input + "'") + " where a stream was expected. You can provide an Observable, Promise, ReadableStream, Array, AsyncIterable, or Iterable.");
}
function getSymbolIterator() {
  if (typeof Symbol !== "function" || !Symbol.iterator) {
    return "@@iterator";
  }
  return Symbol.iterator;
}
var iterator = getSymbolIterator();
function isIterable(input) {
  return isFunction(input === null || input === void 0 ? void 0 : input[iterator]);
}
function readableStreamLikeToAsyncGenerator(readableStream) {
  return __asyncGenerator(this, arguments, function readableStreamLikeToAsyncGenerator_1() {
    var reader, _a, value, done;
    return __generator(this, function(_b) {
      switch (_b.label) {
        case 0:
          reader = readableStream.getReader();
          _b.label = 1;
        case 1:
          _b.trys.push([1, , 9, 10]);
          _b.label = 2;
        case 2:
          return [4, __await(reader.read())];
        case 3:
          _a = _b.sent(), value = _a.value, done = _a.done;
          if (!done) return [3, 5];
          return [4, __await(void 0)];
        case 4:
          return [2, _b.sent()];
        case 5:
          return [4, __await(value)];
        case 6:
          return [4, _b.sent()];
        case 7:
          _b.sent();
          return [3, 2];
        case 8:
          return [3, 10];
        case 9:
          reader.releaseLock();
          return [7];
        case 10:
          return [2];
      }
    });
  });
}
function isReadableStreamLike(obj) {
  return isFunction(obj === null || obj === void 0 ? void 0 : obj.getReader);
}
function innerFrom(input) {
  if (input instanceof Observable) {
    return input;
  }
  if (input != null) {
    if (isInteropObservable(input)) {
      return fromInteropObservable(input);
    }
    if (isArrayLike(input)) {
      return fromArrayLike(input);
    }
    if (isPromise(input)) {
      return fromPromise(input);
    }
    if (isAsyncIterable(input)) {
      return fromAsyncIterable(input);
    }
    if (isIterable(input)) {
      return fromIterable(input);
    }
    if (isReadableStreamLike(input)) {
      return fromReadableStreamLike(input);
    }
  }
  throw createInvalidObservableTypeError(input);
}
function fromInteropObservable(obj) {
  return new Observable(function(subscriber) {
    var obs = obj[observable]();
    if (isFunction(obs.subscribe)) {
      return obs.subscribe(subscriber);
    }
    throw new TypeError("Provided object does not correctly implement Symbol.observable");
  });
}
function fromArrayLike(array) {
  return new Observable(function(subscriber) {
    for (var i = 0; i < array.length && !subscriber.closed; i++) {
      subscriber.next(array[i]);
    }
    subscriber.complete();
  });
}
function fromPromise(promise) {
  return new Observable(function(subscriber) {
    promise.then(function(value) {
      if (!subscriber.closed) {
        subscriber.next(value);
        subscriber.complete();
      }
    }, function(err) {
      return subscriber.error(err);
    }).then(null, reportUnhandledError);
  });
}
function fromIterable(iterable) {
  return new Observable(function(subscriber) {
    var e_1, _a;
    try {
      for (var iterable_1 = __values$1(iterable), iterable_1_1 = iterable_1.next(); !iterable_1_1.done; iterable_1_1 = iterable_1.next()) {
        var value = iterable_1_1.value;
        subscriber.next(value);
        if (subscriber.closed) {
          return;
        }
      }
    } catch (e_1_1) {
      e_1 = { error: e_1_1 };
    } finally {
      try {
        if (iterable_1_1 && !iterable_1_1.done && (_a = iterable_1.return)) _a.call(iterable_1);
      } finally {
        if (e_1) throw e_1.error;
      }
    }
    subscriber.complete();
  });
}
function fromAsyncIterable(asyncIterable) {
  return new Observable(function(subscriber) {
    process(asyncIterable, subscriber).catch(function(err) {
      return subscriber.error(err);
    });
  });
}
function fromReadableStreamLike(readableStream) {
  return fromAsyncIterable(readableStreamLikeToAsyncGenerator(readableStream));
}
function process(asyncIterable, subscriber) {
  var asyncIterable_1, asyncIterable_1_1;
  var e_2, _a;
  return __awaiter(this, void 0, void 0, function() {
    var value, e_2_1;
    return __generator(this, function(_b) {
      switch (_b.label) {
        case 0:
          _b.trys.push([0, 5, 6, 11]);
          asyncIterable_1 = __asyncValues(asyncIterable);
          _b.label = 1;
        case 1:
          return [4, asyncIterable_1.next()];
        case 2:
          if (!(asyncIterable_1_1 = _b.sent(), !asyncIterable_1_1.done)) return [3, 4];
          value = asyncIterable_1_1.value;
          subscriber.next(value);
          if (subscriber.closed) {
            return [2];
          }
          _b.label = 3;
        case 3:
          return [3, 1];
        case 4:
          return [3, 11];
        case 5:
          e_2_1 = _b.sent();
          e_2 = { error: e_2_1 };
          return [3, 11];
        case 6:
          _b.trys.push([6, , 9, 10]);
          if (!(asyncIterable_1_1 && !asyncIterable_1_1.done && (_a = asyncIterable_1.return))) return [3, 8];
          return [4, _a.call(asyncIterable_1)];
        case 7:
          _b.sent();
          _b.label = 8;
        case 8:
          return [3, 10];
        case 9:
          if (e_2) throw e_2.error;
          return [7];
        case 10:
          return [7];
        case 11:
          subscriber.complete();
          return [2];
      }
    });
  });
}
function executeSchedule(parentSubscription, scheduler, work, delay2, repeat) {
  if (delay2 === void 0) {
    delay2 = 0;
  }
  if (repeat === void 0) {
    repeat = false;
  }
  var scheduleSubscription = scheduler.schedule(function() {
    work();
    if (repeat) {
      parentSubscription.add(this.schedule(null, delay2));
    } else {
      this.unsubscribe();
    }
  }, delay2);
  parentSubscription.add(scheduleSubscription);
  if (!repeat) {
    return scheduleSubscription;
  }
}
function observeOn(scheduler, delay2) {
  if (delay2 === void 0) {
    delay2 = 0;
  }
  return operate(function(source, subscriber) {
    source.subscribe(createOperatorSubscriber(subscriber, function(value) {
      return executeSchedule(subscriber, scheduler, function() {
        return subscriber.next(value);
      }, delay2);
    }, function() {
      return executeSchedule(subscriber, scheduler, function() {
        return subscriber.complete();
      }, delay2);
    }, function(err) {
      return executeSchedule(subscriber, scheduler, function() {
        return subscriber.error(err);
      }, delay2);
    }));
  });
}
function subscribeOn(scheduler, delay2) {
  if (delay2 === void 0) {
    delay2 = 0;
  }
  return operate(function(source, subscriber) {
    subscriber.add(scheduler.schedule(function() {
      return source.subscribe(subscriber);
    }, delay2));
  });
}
function scheduleObservable(input, scheduler) {
  return innerFrom(input).pipe(subscribeOn(scheduler), observeOn(scheduler));
}
function schedulePromise(input, scheduler) {
  return innerFrom(input).pipe(subscribeOn(scheduler), observeOn(scheduler));
}
function scheduleArray(input, scheduler) {
  return new Observable(function(subscriber) {
    var i = 0;
    return scheduler.schedule(function() {
      if (i === input.length) {
        subscriber.complete();
      } else {
        subscriber.next(input[i++]);
        if (!subscriber.closed) {
          this.schedule();
        }
      }
    });
  });
}
function scheduleIterable(input, scheduler) {
  return new Observable(function(subscriber) {
    var iterator$1;
    executeSchedule(subscriber, scheduler, function() {
      iterator$1 = input[iterator]();
      executeSchedule(subscriber, scheduler, function() {
        var _a;
        var value;
        var done;
        try {
          _a = iterator$1.next(), value = _a.value, done = _a.done;
        } catch (err) {
          subscriber.error(err);
          return;
        }
        if (done) {
          subscriber.complete();
        } else {
          subscriber.next(value);
        }
      }, 0, true);
    });
    return function() {
      return isFunction(iterator$1 === null || iterator$1 === void 0 ? void 0 : iterator$1.return) && iterator$1.return();
    };
  });
}
function scheduleAsyncIterable(input, scheduler) {
  if (!input) {
    throw new Error("Iterable cannot be null");
  }
  return new Observable(function(subscriber) {
    executeSchedule(subscriber, scheduler, function() {
      var iterator2 = input[Symbol.asyncIterator]();
      executeSchedule(subscriber, scheduler, function() {
        iterator2.next().then(function(result) {
          if (result.done) {
            subscriber.complete();
          } else {
            subscriber.next(result.value);
          }
        });
      }, 0, true);
    });
  });
}
function scheduleReadableStreamLike(input, scheduler) {
  return scheduleAsyncIterable(readableStreamLikeToAsyncGenerator(input), scheduler);
}
function scheduled(input, scheduler) {
  if (input != null) {
    if (isInteropObservable(input)) {
      return scheduleObservable(input, scheduler);
    }
    if (isArrayLike(input)) {
      return scheduleArray(input, scheduler);
    }
    if (isPromise(input)) {
      return schedulePromise(input, scheduler);
    }
    if (isAsyncIterable(input)) {
      return scheduleAsyncIterable(input, scheduler);
    }
    if (isIterable(input)) {
      return scheduleIterable(input, scheduler);
    }
    if (isReadableStreamLike(input)) {
      return scheduleReadableStreamLike(input, scheduler);
    }
  }
  throw createInvalidObservableTypeError(input);
}
function from(input, scheduler) {
  return scheduler ? scheduled(input, scheduler) : innerFrom(input);
}
function isValidDate(value) {
  return value instanceof Date && !isNaN(value);
}
var TimeoutError = createErrorClass(function(_super) {
  return function TimeoutErrorImpl(info) {
    if (info === void 0) {
      info = null;
    }
    _super(this);
    this.message = "Timeout has occurred";
    this.name = "TimeoutError";
    this.info = info;
  };
});
function timeout(config2, schedulerArg) {
  var _a = isValidDate(config2) ? { first: config2 } : typeof config2 === "number" ? { each: config2 } : config2, first = _a.first, each = _a.each, _b = _a.with, _with = _b === void 0 ? timeoutErrorFactory : _b, _c = _a.scheduler, scheduler = _c === void 0 ? asyncScheduler : _c, _d = _a.meta, meta = _d === void 0 ? null : _d;
  if (first == null && each == null) {
    throw new TypeError("No timeout provided.");
  }
  return operate(function(source, subscriber) {
    var originalSourceSubscription;
    var timerSubscription;
    var lastValue = null;
    var seen = 0;
    var startTimer = function(delay2) {
      timerSubscription = executeSchedule(subscriber, scheduler, function() {
        try {
          originalSourceSubscription.unsubscribe();
          innerFrom(_with({
            meta,
            lastValue,
            seen
          })).subscribe(subscriber);
        } catch (err) {
          subscriber.error(err);
        }
      }, delay2);
    };
    originalSourceSubscription = source.subscribe(createOperatorSubscriber(subscriber, function(value) {
      timerSubscription === null || timerSubscription === void 0 ? void 0 : timerSubscription.unsubscribe();
      seen++;
      subscriber.next(lastValue = value);
      each > 0 && startTimer(each);
    }, void 0, void 0, function() {
      if (!(timerSubscription === null || timerSubscription === void 0 ? void 0 : timerSubscription.closed)) {
        timerSubscription === null || timerSubscription === void 0 ? void 0 : timerSubscription.unsubscribe();
      }
      lastValue = null;
    }));
    !seen && startTimer(first != null ? typeof first === "number" ? first : +first - scheduler.now() : each);
  });
}
function timeoutErrorFactory(info) {
  throw new TimeoutError(info);
}
function map(project, thisArg) {
  return operate(function(source, subscriber) {
    var index = 0;
    source.subscribe(createOperatorSubscriber(subscriber, function(value) {
      subscriber.next(project.call(thisArg, value, index++));
    }));
  });
}
var isArray = Array.isArray;
function callOrApply(fn, args) {
  return isArray(args) ? fn.apply(void 0, __spreadArray([], __read$1(args))) : fn(args);
}
function mapOneOrManyArgs(fn) {
  return map(function(args) {
    return callOrApply(fn, args);
  });
}
function mergeInternals(source, subscriber, project, concurrent, onBeforeNext, expand, innerSubScheduler, additionalFinalizer) {
  var buffer2 = [];
  var active = 0;
  var index = 0;
  var isComplete = false;
  var checkComplete = function() {
    if (isComplete && !buffer2.length && !active) {
      subscriber.complete();
    }
  };
  var outerNext = function(value) {
    return active < concurrent ? doInnerSub(value) : buffer2.push(value);
  };
  var doInnerSub = function(value) {
    active++;
    var innerComplete = false;
    innerFrom(project(value, index++)).subscribe(createOperatorSubscriber(subscriber, function(innerValue) {
      {
        subscriber.next(innerValue);
      }
    }, function() {
      innerComplete = true;
    }, void 0, function() {
      if (innerComplete) {
        try {
          active--;
          var _loop_1 = function() {
            var bufferedValue = buffer2.shift();
            if (innerSubScheduler) ;
            else {
              doInnerSub(bufferedValue);
            }
          };
          while (buffer2.length && active < concurrent) {
            _loop_1();
          }
          checkComplete();
        } catch (err) {
          subscriber.error(err);
        }
      }
    }));
  };
  source.subscribe(createOperatorSubscriber(subscriber, outerNext, function() {
    isComplete = true;
    checkComplete();
  }));
  return function() {
  };
}
function mergeMap(project, resultSelector, concurrent) {
  if (concurrent === void 0) {
    concurrent = Infinity;
  }
  if (isFunction(resultSelector)) {
    return mergeMap(function(a, i) {
      return map(function(b, ii) {
        return resultSelector(a, b, i, ii);
      })(innerFrom(project(a, i)));
    }, concurrent);
  } else if (typeof resultSelector === "number") {
    concurrent = resultSelector;
  }
  return operate(function(source, subscriber) {
    return mergeInternals(source, subscriber, project, concurrent);
  });
}
function mergeAll(concurrent) {
  if (concurrent === void 0) {
    concurrent = Infinity;
  }
  return mergeMap(identity, concurrent);
}
var nodeEventEmitterMethods = ["addListener", "removeListener"];
var eventTargetMethods = ["addEventListener", "removeEventListener"];
var jqueryMethods = ["on", "off"];
function fromEvent(target, eventName, options, resultSelector) {
  if (isFunction(options)) {
    resultSelector = options;
    options = void 0;
  }
  if (resultSelector) {
    return fromEvent(target, eventName, options).pipe(mapOneOrManyArgs(resultSelector));
  }
  var _a = __read$1(isEventTarget(target) ? eventTargetMethods.map(function(methodName) {
    return function(handler) {
      return target[methodName](eventName, handler, options);
    };
  }) : isNodeStyleEventEmitter(target) ? nodeEventEmitterMethods.map(toCommonHandlerRegistry(target, eventName)) : isJQueryStyleEventEmitter(target) ? jqueryMethods.map(toCommonHandlerRegistry(target, eventName)) : [], 2), add = _a[0], remove = _a[1];
  if (!add) {
    if (isArrayLike(target)) {
      return mergeMap(function(subTarget) {
        return fromEvent(subTarget, eventName, options);
      })(innerFrom(target));
    }
  }
  if (!add) {
    throw new TypeError("Invalid event target");
  }
  return new Observable(function(subscriber) {
    var handler = function() {
      var args = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        args[_i] = arguments[_i];
      }
      return subscriber.next(1 < args.length ? args : args[0]);
    };
    add(handler);
    return function() {
      return remove(handler);
    };
  });
}
function toCommonHandlerRegistry(target, eventName) {
  return function(methodName) {
    return function(handler) {
      return target[methodName](eventName, handler);
    };
  };
}
function isNodeStyleEventEmitter(target) {
  return isFunction(target.addListener) && isFunction(target.removeListener);
}
function isJQueryStyleEventEmitter(target) {
  return isFunction(target.on) && isFunction(target.off);
}
function isEventTarget(target) {
  return isFunction(target.addEventListener) && isFunction(target.removeEventListener);
}
function timer(dueTime, intervalOrScheduler, scheduler) {
  if (scheduler === void 0) {
    scheduler = async;
  }
  var intervalDuration = -1;
  if (intervalOrScheduler != null) {
    if (isScheduler(intervalOrScheduler)) {
      scheduler = intervalOrScheduler;
    } else {
      intervalDuration = intervalOrScheduler;
    }
  }
  return new Observable(function(subscriber) {
    var due = isValidDate(dueTime) ? 0 - scheduler.now() : dueTime;
    if (due < 0) {
      due = 0;
    }
    var n = 0;
    return scheduler.schedule(function() {
      if (!subscriber.closed) {
        subscriber.next(n++);
        if (0 <= intervalDuration) {
          this.schedule(void 0, intervalDuration);
        } else {
          subscriber.complete();
        }
      }
    }, due);
  });
}
function merge() {
  var args = [];
  for (var _i = 0; _i < arguments.length; _i++) {
    args[_i] = arguments[_i];
  }
  var scheduler = popScheduler(args);
  var concurrent = popNumber(args, Infinity);
  var sources = args;
  return !sources.length ? EMPTY : sources.length === 1 ? innerFrom(sources[0]) : mergeAll(concurrent)(from(sources, scheduler));
}
function filter(predicate, thisArg) {
  return operate(function(source, subscriber) {
    var index = 0;
    source.subscribe(createOperatorSubscriber(subscriber, function(value) {
      return predicate.call(thisArg, value, index++) && subscriber.next(value);
    }));
  });
}
function buffer(closingNotifier) {
  return operate(function(source, subscriber) {
    var currentBuffer = [];
    source.subscribe(createOperatorSubscriber(subscriber, function(value) {
      return currentBuffer.push(value);
    }, function() {
      subscriber.next(currentBuffer);
      subscriber.complete();
    }));
    innerFrom(closingNotifier).subscribe(createOperatorSubscriber(subscriber, function() {
      var b = currentBuffer;
      currentBuffer = [];
      subscriber.next(b);
    }, noop));
    return function() {
      currentBuffer = null;
    };
  });
}
function debounceTime(dueTime, scheduler) {
  if (scheduler === void 0) {
    scheduler = asyncScheduler;
  }
  return operate(function(source, subscriber) {
    var activeTask = null;
    var lastValue = null;
    var lastTime = null;
    var emit = function() {
      if (activeTask) {
        activeTask.unsubscribe();
        activeTask = null;
        var value = lastValue;
        lastValue = null;
        subscriber.next(value);
      }
    };
    function emitWhenIdle() {
      var targetTime = lastTime + dueTime;
      var now = scheduler.now();
      if (now < targetTime) {
        activeTask = this.schedule(void 0, targetTime - now);
        subscriber.add(activeTask);
        return;
      }
      emit();
    }
    source.subscribe(createOperatorSubscriber(subscriber, function(value) {
      lastValue = value;
      lastTime = scheduler.now();
      if (!activeTask) {
        activeTask = scheduler.schedule(emitWhenIdle, dueTime);
        subscriber.add(activeTask);
      }
    }, function() {
      emit();
      subscriber.complete();
    }, void 0, function() {
      lastValue = activeTask = null;
    }));
  });
}
function take(count2) {
  return count2 <= 0 ? function() {
    return EMPTY;
  } : operate(function(source, subscriber) {
    var seen = 0;
    source.subscribe(createOperatorSubscriber(subscriber, function(value) {
      if (++seen <= count2) {
        subscriber.next(value);
        if (count2 <= seen) {
          subscriber.complete();
        }
      }
    }));
  });
}
function mapTo(value) {
  return map(function() {
    return value;
  });
}
function delayWhen(delayDurationSelector, subscriptionDelay) {
  return mergeMap(function(value, index) {
    return innerFrom(delayDurationSelector(value, index)).pipe(take(1), mapTo(value));
  });
}
function delay(due, scheduler) {
  if (scheduler === void 0) {
    scheduler = asyncScheduler;
  }
  var duration = timer(due, scheduler);
  return delayWhen(function() {
    return duration;
  });
}
function pairwise() {
  return operate(function(source, subscriber) {
    var prev;
    var hasPrev = false;
    source.subscribe(createOperatorSubscriber(subscriber, function(value) {
      var p = prev;
      prev = value;
      hasPrev && subscriber.next([p, value]);
      hasPrev = true;
    }));
  });
}
function share(options) {
  if (options === void 0) {
    options = {};
  }
  var _a = options.connector, connector = _a === void 0 ? function() {
    return new Subject();
  } : _a, _b = options.resetOnError, resetOnError = _b === void 0 ? true : _b, _c = options.resetOnComplete, resetOnComplete = _c === void 0 ? true : _c, _d = options.resetOnRefCountZero, resetOnRefCountZero = _d === void 0 ? true : _d;
  return function(wrapperSource) {
    var connection;
    var resetConnection;
    var subject;
    var refCount = 0;
    var hasCompleted = false;
    var hasErrored = false;
    var cancelReset = function() {
      resetConnection === null || resetConnection === void 0 ? void 0 : resetConnection.unsubscribe();
      resetConnection = void 0;
    };
    var reset = function() {
      cancelReset();
      connection = subject = void 0;
      hasCompleted = hasErrored = false;
    };
    var resetAndUnsubscribe = function() {
      var conn = connection;
      reset();
      conn === null || conn === void 0 ? void 0 : conn.unsubscribe();
    };
    return operate(function(source, subscriber) {
      refCount++;
      if (!hasErrored && !hasCompleted) {
        cancelReset();
      }
      var dest = subject = subject !== null && subject !== void 0 ? subject : connector();
      subscriber.add(function() {
        refCount--;
        if (refCount === 0 && !hasErrored && !hasCompleted) {
          resetConnection = handleReset(resetAndUnsubscribe, resetOnRefCountZero);
        }
      });
      dest.subscribe(subscriber);
      if (!connection && refCount > 0) {
        connection = new SafeSubscriber({
          next: function(value) {
            return dest.next(value);
          },
          error: function(err) {
            hasErrored = true;
            cancelReset();
            resetConnection = handleReset(reset, resetOnError, err);
            dest.error(err);
          },
          complete: function() {
            hasCompleted = true;
            cancelReset();
            resetConnection = handleReset(reset, resetOnComplete);
            dest.complete();
          }
        });
        innerFrom(source).subscribe(connection);
      }
    })(wrapperSource);
  };
}
function handleReset(reset, on) {
  var args = [];
  for (var _i = 2; _i < arguments.length; _i++) {
    args[_i - 2] = arguments[_i];
  }
  if (on === true) {
    reset();
    return;
  }
  if (on === false) {
    return;
  }
  var onSubscriber = new SafeSubscriber({
    next: function() {
      onSubscriber.unsubscribe();
      reset();
    }
  });
  return innerFrom(on.apply(void 0, __spreadArray([], __read$1(args)))).subscribe(onSubscriber);
}
function switchMap(project, resultSelector) {
  return operate(function(source, subscriber) {
    var innerSubscriber = null;
    var index = 0;
    var isComplete = false;
    var checkComplete = function() {
      return isComplete && !innerSubscriber && subscriber.complete();
    };
    source.subscribe(createOperatorSubscriber(subscriber, function(value) {
      innerSubscriber === null || innerSubscriber === void 0 ? void 0 : innerSubscriber.unsubscribe();
      var innerIndex = 0;
      var outerIndex = index++;
      innerFrom(project(value, outerIndex)).subscribe(innerSubscriber = createOperatorSubscriber(subscriber, function(innerValue) {
        return subscriber.next(resultSelector ? resultSelector(value, innerValue, outerIndex, innerIndex++) : innerValue);
      }, function() {
        innerSubscriber = null;
        checkComplete();
      }));
    }, function() {
      isComplete = true;
      checkComplete();
    }));
  });
}
var SENSITIVE_TAGS = ["input", "select", "textarea"];
var createShouldTrackEvent = function(autocaptureOptions, allowlist) {
  return function(actionType, element) {
    var _a, _b, _c;
    var pageUrlAllowlist = autocaptureOptions.pageUrlAllowlist, shouldTrackEventResolver = autocaptureOptions.shouldTrackEventResolver;
    var tag = (_b = (_a = element === null || element === void 0 ? void 0 : element.tagName) === null || _a === void 0 ? void 0 : _a.toLowerCase) === null || _b === void 0 ? void 0 : _b.call(_a);
    if (!tag) {
      return false;
    }
    if (shouldTrackEventResolver) {
      return shouldTrackEventResolver(actionType, element);
    }
    if (!isPageUrlAllowed(window.location.href, pageUrlAllowlist)) {
      return false;
    }
    var elementType = String(element === null || element === void 0 ? void 0 : element.getAttribute("type")) || "";
    if (typeof elementType === "string") {
      switch (elementType.toLowerCase()) {
        case "hidden":
          return false;
        case "password":
          return false;
      }
    }
    if (allowlist) {
      var hasMatchAnyAllowedSelector = allowlist.some(function(selector) {
        var _a2;
        return !!((_a2 = element === null || element === void 0 ? void 0 : element.matches) === null || _a2 === void 0 ? void 0 : _a2.call(element, selector));
      });
      if (!hasMatchAnyAllowedSelector) {
        return false;
      }
    }
    switch (tag) {
      case "input":
      case "select":
      case "textarea":
        return actionType === "change" || actionType === "click";
      default: {
        var computedStyle = (_c = window === null || window === void 0 ? void 0 : window.getComputedStyle) === null || _c === void 0 ? void 0 : _c.call(window, element);
        if (computedStyle && computedStyle.getPropertyValue("cursor") === "pointer" && actionType === "click") {
          return true;
        }
        return actionType === "click";
      }
    }
  };
};
var isNonSensitiveString = function(text) {
  if (text == null) {
    return false;
  }
  if (typeof text === "string") {
    var ccRegex = /^(?:(4[0-9]{12}(?:[0-9]{3})?)|(5[1-5][0-9]{14})|(6(?:011|5[0-9]{2})[0-9]{12})|(3[47][0-9]{13})|(3(?:0[0-5]|[68][0-9])[0-9]{11})|((?:2131|1800|35[0-9]{3})[0-9]{11}))$/;
    if (ccRegex.test((text || "").replace(/[- ]/g, ""))) {
      return false;
    }
    var ssnRegex = /(^\d{3}-?\d{2}-?\d{4}$)/;
    if (ssnRegex.test(text)) {
      return false;
    }
  }
  return true;
};
var isTextNode = function(node) {
  return !!node && node.nodeType === 3;
};
var isNonSensitiveElement = function(element) {
  var _a, _b, _c;
  var tag = (_b = (_a = element === null || element === void 0 ? void 0 : element.tagName) === null || _a === void 0 ? void 0 : _a.toLowerCase) === null || _b === void 0 ? void 0 : _b.call(_a);
  var isContentEditable = element instanceof HTMLElement ? ((_c = element.getAttribute("contenteditable")) === null || _c === void 0 ? void 0 : _c.toLowerCase()) === "true" : false;
  return !SENSITIVE_TAGS.includes(tag) && !isContentEditable;
};
var getText = function(element) {
  var text = "";
  if (isNonSensitiveElement(element) && element.childNodes && element.childNodes.length) {
    element.childNodes.forEach(function(child) {
      var childText = "";
      if (isTextNode(child)) {
        if (child.textContent) {
          childText = child.textContent;
        }
      } else {
        childText = getText(child);
      }
      text += childText.split(/(\s+)/).filter(isNonSensitiveString).join("").replace(/[\r\n]/g, " ").replace(/[ ]+/g, " ").substring(0, 255);
    });
  }
  return text;
};
var isPageUrlAllowed = function(url, pageUrlAllowlist) {
  if (!pageUrlAllowlist || !pageUrlAllowlist.length) {
    return true;
  }
  return pageUrlAllowlist.some(function(allowedUrl) {
    if (typeof allowedUrl === "string") {
      return url === allowedUrl;
    }
    return url.match(allowedUrl);
  });
};
var getAttributesWithPrefix = function(element, prefix) {
  return element.getAttributeNames().reduce(function(attributes, attributeName) {
    if (attributeName.startsWith(prefix)) {
      var attributeKey = attributeName.replace(prefix, "");
      var attributeValue = element.getAttribute(attributeName);
      if (attributeKey) {
        attributes[attributeKey] = attributeValue || "";
      }
    }
    return attributes;
  }, {});
};
var isEmpty = function(value) {
  return value === void 0 || value === null || typeof value === "object" && Object.keys(value).length === 0 || typeof value === "string" && value.trim().length === 0;
};
var removeEmptyProperties = function(properties) {
  return Object.keys(properties).reduce(function(filteredProperties, key) {
    var value = properties[key];
    if (!isEmpty(value)) {
      filteredProperties[key] = value;
    }
    return filteredProperties;
  }, {});
};
var getNearestLabel = function(element) {
  var parent = element.parentElement;
  if (!parent) {
    return "";
  }
  var labelElement;
  try {
    labelElement = parent.querySelector(":scope>span,h1,h2,h3,h4,h5,h6");
  } catch (error) {
    labelElement = null;
  }
  if (labelElement) {
    var labelText = labelElement.textContent || "";
    return isNonSensitiveString(labelText) ? labelText : "";
  }
  return getNearestLabel(parent);
};
var getClosestElement = function(element, selectors) {
  if (!element) {
    return null;
  }
  if (selectors.some(function(selector) {
    var _a;
    return (_a = element === null || element === void 0 ? void 0 : element.matches) === null || _a === void 0 ? void 0 : _a.call(element, selector);
  })) {
    return element;
  }
  return getClosestElement(element === null || element === void 0 ? void 0 : element.parentElement, selectors);
};
var getEventTagProps = function(element) {
  var _a;
  var _b, _c;
  if (!element) {
    return {};
  }
  var tag = (_c = (_b = element === null || element === void 0 ? void 0 : element.tagName) === null || _b === void 0 ? void 0 : _b.toLowerCase) === null || _c === void 0 ? void 0 : _c.call(_b);
  var properties = (_a = {}, _a[AMPLITUDE_EVENT_PROP_ELEMENT_TAG] = tag, _a[AMPLITUDE_EVENT_PROP_ELEMENT_TEXT] = getText(element), _a[AMPLITUDE_EVENT_PROP_PAGE_URL] = window.location.href.split("?")[0], _a);
  return removeEmptyProperties(properties);
};
var asyncLoadScript = function(url) {
  return new Promise(function(resolve, reject) {
    var _a;
    try {
      var scriptElement = document.createElement("script");
      scriptElement.type = "text/javascript";
      scriptElement.async = true;
      scriptElement.src = url;
      scriptElement.addEventListener("load", function() {
        resolve({ status: true });
      }, { once: true });
      scriptElement.addEventListener("error", function() {
        reject({
          status: false,
          message: "Failed to load the script ".concat(url)
        });
      });
      (_a = document.head) === null || _a === void 0 ? void 0 : _a.appendChild(scriptElement);
    } catch (error) {
      reject(error);
    }
  });
};
function generateUniqueId() {
  return "".concat(Date.now(), "-").concat(Math.random().toString(36).substr(2, 9));
}
var filterOutNonTrackableEvents = function(event) {
  if (event.event.target === null || !event.closestTrackedAncestor) {
    return false;
  }
  return true;
};
var WindowMessenger = (
  /** @class */
  function() {
    function WindowMessenger2(_a) {
      var _b = _a === void 0 ? {} : _a, _c = _b.origin, origin = _c === void 0 ? AMPLITUDE_ORIGIN : _c;
      var _this = this;
      this.endpoint = AMPLITUDE_ORIGIN;
      this.requestCallbacks = {};
      this.onSelect = function(data) {
        _this.notify({ action: "element-selected", data });
      };
      this.onTrack = function(type, properties) {
        if (type === "selector-mode-changed") {
          _this.notify({ action: "track-selector-mode-changed", data: properties });
        } else if (type === "selector-moved") {
          _this.notify({ action: "track-selector-moved", data: properties });
        }
      };
      this.endpoint = origin;
    }
    WindowMessenger2.prototype.notify = function(message) {
      var _a, _b, _c, _d;
      (_b = (_a = this.logger) === null || _a === void 0 ? void 0 : _a.debug) === null || _b === void 0 ? void 0 : _b.call(_a, "Message sent: ", JSON.stringify(message));
      (_d = (_c = window.opener) === null || _c === void 0 ? void 0 : _c.postMessage) === null || _d === void 0 ? void 0 : _d.call(_c, message, this.endpoint);
    };
    WindowMessenger2.prototype.sendRequest = function(action, args, options) {
      var _this = this;
      if (options === void 0) {
        options = { timeout: 15e3 };
      }
      var id = generateUniqueId();
      var request = {
        id,
        action,
        args
      };
      var promise = new Promise(function(resolve, reject) {
        _this.requestCallbacks[id] = { resolve, reject };
        _this.notify(request);
        if ((options === null || options === void 0 ? void 0 : options.timeout) > 0) {
          setTimeout(function() {
            reject(new Error("".concat(action, " timed out (id: ").concat(id, ")")));
            delete _this.requestCallbacks[id];
          }, options.timeout);
        }
      });
      return promise;
    };
    WindowMessenger2.prototype.handleResponse = function(response) {
      var _a;
      if (!this.requestCallbacks[response.id]) {
        (_a = this.logger) === null || _a === void 0 ? void 0 : _a.warn("No callback found for request id: ".concat(response.id));
        return;
      }
      this.requestCallbacks[response.id].resolve(response.responseData);
      delete this.requestCallbacks[response.id];
    };
    WindowMessenger2.prototype.setup = function(_a) {
      var _this = this;
      var _b = _a === void 0 ? {} : _a, logger = _b.logger, endpoint = _b.endpoint, isElementSelectable = _b.isElementSelectable, cssSelectorAllowlist = _b.cssSelectorAllowlist, actionClickAllowlist = _b.actionClickAllowlist;
      this.logger = logger;
      if (endpoint && this.endpoint === AMPLITUDE_ORIGIN) {
        this.endpoint = endpoint;
      }
      var amplitudeVisualTaggingSelectorInstance = null;
      window.addEventListener("message", function(event) {
        var _a2, _b2, _c, _d, _e;
        (_b2 = (_a2 = _this.logger) === null || _a2 === void 0 ? void 0 : _a2.debug) === null || _b2 === void 0 ? void 0 : _b2.call(_a2, "Message received: ", JSON.stringify(event));
        if (_this.endpoint !== event.origin) {
          return;
        }
        var eventData = event === null || event === void 0 ? void 0 : event.data;
        var action = eventData === null || eventData === void 0 ? void 0 : eventData.action;
        if (!action) {
          return;
        }
        if ("id" in eventData) {
          (_d = (_c = _this.logger) === null || _c === void 0 ? void 0 : _c.debug) === null || _d === void 0 ? void 0 : _d.call(_c, "Received Response to previous request: ", JSON.stringify(event));
          _this.handleResponse(eventData);
        } else {
          if (action === "ping") {
            _this.notify({ action: "pong" });
          } else if (action === "initialize-visual-tagging-selector") {
            var actionData_1 = eventData === null || eventData === void 0 ? void 0 : eventData.data;
            asyncLoadScript(AMPLITUDE_VISUAL_TAGGING_SELECTOR_SCRIPT_URL).then(function() {
              var _a3;
              amplitudeVisualTaggingSelectorInstance = (_a3 = window === null || window === void 0 ? void 0 : window.amplitudeVisualTaggingSelector) === null || _a3 === void 0 ? void 0 : _a3.call(window, {
                getEventTagProps,
                isElementSelectable: function(element) {
                  if (isElementSelectable) {
                    return isElementSelectable((actionData_1 === null || actionData_1 === void 0 ? void 0 : actionData_1.actionType) || "click", element);
                  }
                  return true;
                },
                onTrack: _this.onTrack,
                onSelect: _this.onSelect,
                visualHighlightClass: AMPLITUDE_VISUAL_TAGGING_HIGHLIGHT_CLASS,
                messenger: _this,
                cssSelectorAllowlist,
                actionClickAllowlist
              });
              _this.notify({ action: "selector-loaded" });
            }).catch(function() {
              var _a3;
              (_a3 = _this.logger) === null || _a3 === void 0 ? void 0 : _a3.warn("Failed to initialize visual tagging selector");
            });
          } else if (action === "close-visual-tagging-selector") {
            (_e = amplitudeVisualTaggingSelectorInstance === null || amplitudeVisualTaggingSelectorInstance === void 0 ? void 0 : amplitudeVisualTaggingSelectorInstance.close) === null || _e === void 0 ? void 0 : _e.call(amplitudeVisualTaggingSelectorInstance);
          }
        }
      });
      this.notify({ action: "page-loaded" });
    };
    return WindowMessenger2;
  }()
);
var BLOCKED_ATTRIBUTES = [
  // Already captured elsewhere in the hierarchy object
  "id",
  "class",
  // non-useful and potentially large attribute
  "style",
  // sensitive as prefilled form data may populate this attribute
  "value",
  // DOM events
  "onclick",
  "onchange",
  "oninput",
  "onblur",
  "onsubmit",
  "onfocus",
  "onkeydown",
  "onkeyup",
  "onkeypress",
  // React specific
  "data-reactid",
  "data-react-checksum",
  "data-reactroot"
];
var SENSITIVE_ELEMENT_ATTRIBUTE_ALLOWLIST = ["type"];
var SVG_TAGS = ["svg", "path", "g"];
var HIGHLY_SENSITIVE_INPUT_TYPES = ["password", "hidden"];
var MAX_ATTRIBUTE_LENGTH = 128;
var MAX_HIERARCHY_LENGTH = 1024;
function getElementProperties(element) {
  var e_1, _a;
  var _b, _c, _d, _e;
  if (element === null) {
    return null;
  }
  var tagName = String(element.tagName).toLowerCase();
  var properties = {
    tag: tagName
  };
  var siblings = Array.from((_c = (_b = element.parentElement) === null || _b === void 0 ? void 0 : _b.children) !== null && _c !== void 0 ? _c : []);
  if (siblings.length) {
    properties.index = siblings.indexOf(element);
    properties.indexOfType = siblings.filter(function(el) {
      return el.tagName === element.tagName;
    }).indexOf(element);
  }
  var prevSiblingTag = (_e = (_d = element.previousElementSibling) === null || _d === void 0 ? void 0 : _d.tagName) === null || _e === void 0 ? void 0 : _e.toLowerCase();
  if (prevSiblingTag) {
    properties.prevSib = String(prevSiblingTag);
  }
  var id = element.getAttribute("id");
  if (id) {
    properties.id = String(id);
  }
  var classes = Array.from(element.classList);
  if (classes.length) {
    properties.classes = classes;
  }
  var attributes = {};
  var attributesArray = Array.from(element.attributes);
  var filteredAttributes = attributesArray.filter(function(attr2) {
    return !BLOCKED_ATTRIBUTES.includes(attr2.name);
  });
  var isSensitiveElement = !isNonSensitiveElement(element);
  if (!HIGHLY_SENSITIVE_INPUT_TYPES.includes(String(element.getAttribute("type"))) && !SVG_TAGS.includes(tagName)) {
    try {
      for (var filteredAttributes_1 = __values$1(filteredAttributes), filteredAttributes_1_1 = filteredAttributes_1.next(); !filteredAttributes_1_1.done; filteredAttributes_1_1 = filteredAttributes_1.next()) {
        var attr = filteredAttributes_1_1.value;
        if (isSensitiveElement && !SENSITIVE_ELEMENT_ATTRIBUTE_ALLOWLIST.includes(attr.name)) {
          continue;
        }
        attributes[attr.name] = String(attr.value).substring(0, MAX_ATTRIBUTE_LENGTH);
      }
    } catch (e_1_1) {
      e_1 = { error: e_1_1 };
    } finally {
      try {
        if (filteredAttributes_1_1 && !filteredAttributes_1_1.done && (_a = filteredAttributes_1.return)) _a.call(filteredAttributes_1);
      } finally {
        if (e_1) throw e_1.error;
      }
    }
  }
  if (Object.keys(attributes).length) {
    properties.attrs = attributes;
  }
  return properties;
}
function getAncestors(targetEl) {
  var ancestors = [];
  if (!targetEl) {
    return ancestors;
  }
  ancestors.push(targetEl);
  var current = targetEl.parentElement;
  while (current && current.tagName !== "HTML") {
    ancestors.push(current);
    current = current.parentElement;
  }
  return ancestors;
}
var getHierarchy = function(element) {
  var hierarchy = [];
  if (!element) {
    return [];
  }
  var ancestors = getAncestors(element);
  hierarchy = ensureListUnderLimit(ancestors.map(function(el) {
    return getElementProperties(el);
  }), MAX_HIERARCHY_LENGTH);
  return hierarchy;
};
function ensureListUnderLimit(list, bytesLimit) {
  var numChars = 0;
  for (var i = 0; i < list.length; i++) {
    var node = list[i];
    if (node === null) {
      numChars += 4;
    } else {
      var value = ensureUnicodePythonCompatible(node);
      numChars += value ? Array.from(value).length : 4;
    }
    if (numChars > bytesLimit) {
      return list.slice(0, i);
    }
  }
  return list;
}
function ensureUnicodePythonCompatible(value, nested) {
  if (nested === void 0) {
    nested = false;
  }
  try {
    if (value == null) {
      if (nested) {
        return "None";
      }
      return null;
    } else if (typeof value === "string") {
      if (nested) {
        value = value.replace(/\\/g, "\\\\").replace(/\n/g, "\\n").replace(/\t/g, "\\t").replace(/\r/g, "\\r");
        if (value.includes('"')) {
          return "'".concat(value, "'");
        }
        if (value.includes("'")) {
          return '"'.concat(value.replace(/'/g, "\\'"), '"');
        }
        return "'".concat(value, "'");
      }
      return value;
    } else if (typeof value === "boolean") {
      return value ? "True" : "False";
    } else if (Array.isArray(value)) {
      var elements = value.map(function(o) {
        return ensureUnicodePythonCompatible(o, true);
      });
      return "[".concat(elements.join(", "), "]");
    } else if (typeof value === "object") {
      var entries = Object.entries(value).filter(function(_a) {
        var _b = __read$1(_a, 1), key = _b[0];
        return key != null;
      }).map(function(_a) {
        var _b = __read$1(_a, 2), key = _b[0], val = _b[1];
        return "".concat(String(ensureUnicodePythonCompatible(key, true)), ": ").concat(String(ensureUnicodePythonCompatible(val, true)));
      });
      var result = "{".concat(entries.join(", "), "}");
      if (result.includes("\\'")) {
        result = result.replace(/'/g, "'").replace(/'/g, "\\'");
      }
      return result;
    }
    return value.toString();
  } catch (e) {
    return null;
  }
}
var RAGE_CLICK_THRESHOLD = 5;
function trackClicks(_a) {
  var amplitude = _a.amplitude, allObservables = _a.allObservables, options = _a.options, shouldTrackEvent = _a.shouldTrackEvent;
  var clickObservable = allObservables.clickObservable;
  var comparisonTrigger = clickObservable.pipe(pairwise(), filter(function(_a2) {
    var _b = __read$1(_a2, 2), prev = _b[0], current = _b[1];
    var targetChanged = prev.event.target !== current.event.target;
    var samePos = Math.abs(current.event.screenX - prev.event.screenX) <= 20 && Math.abs(current.event.screenY - prev.event.screenY) <= 20;
    return targetChanged && !samePos;
  }));
  var timeoutTrigger = clickObservable.pipe(debounceTime(options.debounceTime), map(function() {
    return "timeout";
  }));
  var triggers = merge(comparisonTrigger, timeoutTrigger);
  var bufferedClicks = clickObservable.pipe(delay(0), filter(filterOutNonTrackableEvents), filter(function(click) {
    return shouldTrackEvent("click", click.closestTrackedAncestor);
  }), buffer(triggers));
  return bufferedClicks.subscribe(function(clicks) {
    var e_1, _a2;
    var clickType = clicks.length >= RAGE_CLICK_THRESHOLD ? AMPLITUDE_ELEMENT_CLICKED_EVENT : AMPLITUDE_ELEMENT_CLICKED_EVENT;
    try {
      for (var clicks_1 = __values$1(clicks), clicks_1_1 = clicks_1.next(); !clicks_1_1.done; clicks_1_1 = clicks_1.next()) {
        var click = clicks_1_1.value;
        amplitude === null || amplitude === void 0 ? void 0 : amplitude.track(clickType, click.targetElementProperties);
      }
    } catch (e_1_1) {
      e_1 = { error: e_1_1 };
    } finally {
      try {
        if (clicks_1_1 && !clicks_1_1.done && (_a2 = clicks_1.return)) _a2.call(clicks_1);
      } finally {
        if (e_1) throw e_1.error;
      }
    }
  });
}
function trackChange(_a) {
  var amplitude = _a.amplitude, allObservables = _a.allObservables, getEventProperties = _a.getEventProperties, shouldTrackEvent = _a.shouldTrackEvent;
  var changeObservable = allObservables.changeObservable;
  var filteredChangeObservable = changeObservable.pipe(filter(filterOutNonTrackableEvents), filter(function(changeEvent) {
    return shouldTrackEvent("change", changeEvent.closestTrackedAncestor);
  }));
  return filteredChangeObservable.subscribe(function(changeEvent) {
    amplitude === null || amplitude === void 0 ? void 0 : amplitude.track(AMPLITUDE_ELEMENT_CHANGED_EVENT, getEventProperties("change", changeEvent.closestTrackedAncestor));
  });
}
function trackActionClick(_a) {
  var amplitude = _a.amplitude, allObservables = _a.allObservables, options = _a.options, getEventProperties = _a.getEventProperties, shouldTrackEvent = _a.shouldTrackEvent, shouldTrackActionClick = _a.shouldTrackActionClick;
  var clickObservable = allObservables.clickObservable, mutationObservable = allObservables.mutationObservable, navigateObservable = allObservables.navigateObservable;
  var filteredClickObservable = clickObservable.pipe(filter(function(click) {
    return !shouldTrackEvent("click", click.closestTrackedAncestor);
  }), map(function(click) {
    var closestActionClickEl = getClosestElement(click.event.target, options.actionClickAllowlist);
    click.closestTrackedAncestor = closestActionClickEl;
    if (click.closestTrackedAncestor !== null) {
      click.targetElementProperties = getEventProperties(click.type, click.closestTrackedAncestor);
    }
    return click;
  }), filter(filterOutNonTrackableEvents), filter(function(clickEvent) {
    return shouldTrackActionClick("click", clickEvent.closestTrackedAncestor);
  }));
  var changeObservables = [mutationObservable];
  if (navigateObservable) {
    changeObservables.push(navigateObservable);
  }
  var mutationOrNavigate = merge.apply(void 0, __spreadArray([], __read$1(changeObservables), false));
  var actionClicks = filteredClickObservable.pipe(
    // If a mutation occurs within 0.5 seconds of a click event (timeout({ first: 500 })), it emits the original first click event.
    // take 1 to only limit the action events in case there are multiple
    switchMap(function(click) {
      return mutationOrNavigate.pipe(
        take(1),
        timeout({ first: 500, with: function() {
          return EMPTY;
        } }),
        // in case of timeout, map to empty to prevent any click from being emitted
        map(function() {
          return click;
        })
      );
    })
  );
  return actionClicks.subscribe(function(actionClick) {
    amplitude === null || amplitude === void 0 ? void 0 : amplitude.track(AMPLITUDE_ELEMENT_CLICKED_EVENT, getEventProperties("click", actionClick.closestTrackedAncestor));
  });
}
var ObservablesEnum$1;
(function(ObservablesEnum2) {
  ObservablesEnum2["ClickObservable"] = "clickObservable";
  ObservablesEnum2["ChangeObservable"] = "changeObservable";
  ObservablesEnum2["NavigateObservable"] = "navigateObservable";
  ObservablesEnum2["MutationObservable"] = "mutationObservable";
})(ObservablesEnum$1 || (ObservablesEnum$1 = {}));
function isElementBasedEvent(event) {
  return event.type === "click" || event.type === "change";
}
var autocapturePlugin = function(options) {
  var _a, _b, _c;
  if (options === void 0) {
    options = {};
  }
  var _d = options.dataAttributePrefix, dataAttributePrefix = _d === void 0 ? DEFAULT_DATA_ATTRIBUTE_PREFIX : _d, _e = options.visualTaggingOptions, visualTaggingOptions = _e === void 0 ? {
    enabled: true,
    messenger: new WindowMessenger()
  } : _e;
  options.cssSelectorAllowlist = (_a = options.cssSelectorAllowlist) !== null && _a !== void 0 ? _a : DEFAULT_CSS_SELECTOR_ALLOWLIST;
  options.actionClickAllowlist = (_b = options.actionClickAllowlist) !== null && _b !== void 0 ? _b : DEFAULT_ACTION_CLICK_ALLOWLIST;
  options.debounceTime = (_c = options.debounceTime) !== null && _c !== void 0 ? _c : 0;
  var name = PLUGIN_NAME$1;
  var type = "enrichment";
  var subscriptions = [];
  var createObservables = function() {
    var _a2;
    var clickObservable = fromEvent(document, "click", { capture: true }).pipe(map(function(click) {
      return addAdditionalEventProperties(click, "click");
    }), share());
    var changeObservable = fromEvent(document, "change", { capture: true }).pipe(map(function(change) {
      return addAdditionalEventProperties(change, "change");
    }), share());
    var navigateObservable;
    if (window.navigation) {
      navigateObservable = fromEvent(window.navigation, "navigate").pipe(map(function(navigate) {
        return addAdditionalEventProperties(navigate, "navigate");
      }), share());
    }
    var mutationObservable = new Observable(function(observer) {
      var mutationObserver = new MutationObserver(function(mutations) {
        observer.next(mutations);
      });
      mutationObserver.observe(document.body, {
        childList: true,
        attributes: true,
        characterData: true,
        subtree: true
      });
      return function() {
        return mutationObserver.disconnect();
      };
    }).pipe(map(function(mutation) {
      return addAdditionalEventProperties(mutation, "mutation");
    }), share());
    return _a2 = {}, _a2[ObservablesEnum$1.ClickObservable] = clickObservable, _a2[ObservablesEnum$1.ChangeObservable] = changeObservable, // [ObservablesEnum.ErrorObservable]: errorObservable,
    _a2[ObservablesEnum$1.NavigateObservable] = navigateObservable, _a2[ObservablesEnum$1.MutationObservable] = mutationObservable, _a2;
  };
  var getEventProperties = function(actionType, element) {
    var _a2;
    var _b2, _c2;
    var tag = (_c2 = (_b2 = element === null || element === void 0 ? void 0 : element.tagName) === null || _b2 === void 0 ? void 0 : _b2.toLowerCase) === null || _c2 === void 0 ? void 0 : _c2.call(_b2);
    var rect = typeof element.getBoundingClientRect === "function" ? element.getBoundingClientRect() : { left: null, top: null };
    var ariaLabel = element.getAttribute("aria-label");
    var attributes = getAttributesWithPrefix(element, dataAttributePrefix);
    var nearestLabel = getNearestLabel(element);
    var properties = (_a2 = {}, _a2[AMPLITUDE_EVENT_PROP_ELEMENT_ID] = element.getAttribute("id") || "", _a2[AMPLITUDE_EVENT_PROP_ELEMENT_CLASS] = element.getAttribute("class"), _a2[AMPLITUDE_EVENT_PROP_ELEMENT_HIERARCHY] = getHierarchy(element), _a2[AMPLITUDE_EVENT_PROP_ELEMENT_TAG] = tag, _a2[AMPLITUDE_EVENT_PROP_ELEMENT_TEXT] = getText(element), _a2[AMPLITUDE_EVENT_PROP_ELEMENT_POSITION_LEFT] = rect.left == null ? null : Math.round(rect.left), _a2[AMPLITUDE_EVENT_PROP_ELEMENT_POSITION_TOP] = rect.top == null ? null : Math.round(rect.top), _a2[AMPLITUDE_EVENT_PROP_ELEMENT_ARIA_LABEL] = ariaLabel, _a2[AMPLITUDE_EVENT_PROP_ELEMENT_ATTRIBUTES] = attributes, _a2[AMPLITUDE_EVENT_PROP_ELEMENT_PARENT_LABEL] = nearestLabel, _a2[AMPLITUDE_EVENT_PROP_PAGE_URL] = window.location.href.split("?")[0], _a2[AMPLITUDE_EVENT_PROP_PAGE_TITLE] = typeof document !== "undefined" && document.title || "", _a2[AMPLITUDE_EVENT_PROP_VIEWPORT_HEIGHT] = window.innerHeight, _a2[AMPLITUDE_EVENT_PROP_VIEWPORT_WIDTH] = window.innerWidth, _a2);
    if (tag === "a" && actionType === "click" && element instanceof HTMLAnchorElement) {
      properties[AMPLITUDE_EVENT_PROP_ELEMENT_HREF] = element.href;
    }
    return removeEmptyProperties(properties);
  };
  var addAdditionalEventProperties = function(event, type2) {
    var baseEvent = {
      event,
      timestamp: Date.now(),
      type: type2
    };
    if (isElementBasedEvent(baseEvent) && baseEvent.event.target !== null) {
      var closestTrackedAncestor = getClosestElement(baseEvent.event.target, options.cssSelectorAllowlist);
      if (closestTrackedAncestor) {
        baseEvent.closestTrackedAncestor = closestTrackedAncestor;
        baseEvent.targetElementProperties = getEventProperties(baseEvent.type, closestTrackedAncestor);
      }
      return baseEvent;
    }
    return baseEvent;
  };
  var setup = function(config2, amplitude) {
    return __awaiter(void 0, void 0, void 0, function() {
      var shouldTrackEvent, shouldTrackActionClick, allObservables, clickTrackingSubscription, changeSubscription, actionClickSubscription, allowlist, actionClickAllowlist;
      var _a2, _b2;
      return __generator(this, function(_c2) {
        if (typeof document === "undefined") {
          return [
            2
            /*return*/
          ];
        }
        shouldTrackEvent = createShouldTrackEvent(options, options.cssSelectorAllowlist);
        shouldTrackActionClick = createShouldTrackEvent(options, options.actionClickAllowlist);
        allObservables = createObservables();
        clickTrackingSubscription = trackClicks({
          allObservables,
          options,
          amplitude,
          shouldTrackEvent
        });
        subscriptions.push(clickTrackingSubscription);
        changeSubscription = trackChange({
          allObservables,
          getEventProperties,
          amplitude,
          shouldTrackEvent
        });
        subscriptions.push(changeSubscription);
        actionClickSubscription = trackActionClick({
          allObservables,
          options,
          getEventProperties,
          amplitude,
          shouldTrackEvent,
          shouldTrackActionClick
        });
        subscriptions.push(actionClickSubscription);
        (_a2 = config2 === null || config2 === void 0 ? void 0 : config2.loggerProvider) === null || _a2 === void 0 ? void 0 : _a2.log("".concat(name, " has been successfully added."));
        if (window.opener && visualTaggingOptions.enabled) {
          allowlist = options.cssSelectorAllowlist;
          actionClickAllowlist = options.actionClickAllowlist;
          (_b2 = visualTaggingOptions.messenger) === null || _b2 === void 0 ? void 0 : _b2.setup(__assign$1(__assign$1({ logger: config2 === null || config2 === void 0 ? void 0 : config2.loggerProvider }, (config2 === null || config2 === void 0 ? void 0 : config2.serverZone) && { endpoint: AMPLITUDE_ORIGINS_MAP[config2.serverZone] }), { isElementSelectable: createShouldTrackEvent(options, __spreadArray(__spreadArray([], __read$1(allowlist), false), __read$1(actionClickAllowlist), false)), cssSelectorAllowlist: allowlist, actionClickAllowlist }));
        }
        return [
          2
          /*return*/
        ];
      });
    });
  };
  var execute = function(event) {
    return __awaiter(void 0, void 0, void 0, function() {
      return __generator(this, function(_a2) {
        return [2, event];
      });
    });
  };
  var teardown = function() {
    return __awaiter(void 0, void 0, void 0, function() {
      var subscriptions_1, subscriptions_1_1, subscription;
      var e_1, _a2;
      return __generator(this, function(_b2) {
        try {
          for (subscriptions_1 = __values$1(subscriptions), subscriptions_1_1 = subscriptions_1.next(); !subscriptions_1_1.done; subscriptions_1_1 = subscriptions_1.next()) {
            subscription = subscriptions_1_1.value;
            subscription.unsubscribe();
          }
        } catch (e_1_1) {
          e_1 = { error: e_1_1 };
        } finally {
          try {
            if (subscriptions_1_1 && !subscriptions_1_1.done && (_a2 = subscriptions_1.return)) _a2.call(subscriptions_1);
          } finally {
            if (e_1) throw e_1.error;
          }
        }
        return [
          2
          /*return*/
        ];
      });
    });
  };
  return {
    name,
    type,
    setup,
    execute,
    teardown
  };
};
var PLUGIN_NAME = "@amplitude/plugin-network-capture-browser";
var AMPLITUDE_NETWORK_REQUEST_EVENT = "[Amplitude] Network Request";
var DEFAULT_STATUS_CODE_RANGE = "500-599";
function wildcardMatch(str, pattern) {
  var escapedPattern = pattern.replace(/[-[\]{}()+?.,\\^$|#\s]/g, "\\$&");
  var regexPattern = "^" + escapedPattern.replace(/\*/g, ".*") + "$";
  var regex = new RegExp(regexPattern);
  return regex.test(str);
}
function isStatusCodeInRange(statusCode, range) {
  var e_1, _a;
  var ranges = range.split(",");
  try {
    for (var ranges_1 = __values$1(ranges), ranges_1_1 = ranges_1.next(); !ranges_1_1.done; ranges_1_1 = ranges_1.next()) {
      var r = ranges_1_1.value;
      var _b = __read$1(r.split("-").map(Number), 2), start = _b[0], end = _b[1];
      if (statusCode === start && end === void 0) {
        return true;
      }
      if (statusCode >= start && statusCode <= end) {
        return true;
      }
    }
  } catch (e_1_1) {
    e_1 = { error: e_1_1 };
  } finally {
    try {
      if (ranges_1_1 && !ranges_1_1.done && (_a = ranges_1.return)) _a.call(ranges_1);
    } finally {
      if (e_1) throw e_1.error;
    }
  }
  return false;
}
function isCaptureRuleMatch(rule, hostname, status) {
  if (rule.hosts && !rule.hosts.find(function(host) {
    return wildcardMatch(hostname, host);
  })) {
    return;
  }
  if (status || status === 0) {
    var statusCodeRange = rule.statusCodeRange || DEFAULT_STATUS_CODE_RANGE;
    if (!isStatusCodeInRange(status, statusCodeRange)) {
      return false;
    }
  }
  return true;
}
function parseUrl(url) {
  var _a;
  try {
    var currentHref = (_a = getGlobalScope$1()) === null || _a === void 0 ? void 0 : _a.location.href;
    var urlObj = new URL(url, currentHref);
    var query = urlObj.searchParams.toString();
    var fragment = urlObj.hash.replace("#", "");
    var href = urlObj.href;
    var host = urlObj.host;
    urlObj.hash = "";
    urlObj.search = "";
    var hrefWithoutQueryOrHash = urlObj.href;
    return { query, fragment, href, hrefWithoutQueryOrHash, host };
  } catch (e) {
    return;
  }
}
function shouldTrackNetworkEvent(networkEvent, options) {
  var _a;
  if (options === void 0) {
    options = {};
  }
  var urlObj = parseUrl(networkEvent.url);
  if (!urlObj) {
    return false;
  }
  var host = urlObj.host;
  if (options.ignoreAmplitudeRequests !== false && (wildcardMatch(host, "*.amplitude.com") || wildcardMatch(host, "amplitude.com"))) {
    return false;
  }
  if ((_a = options.ignoreHosts) === null || _a === void 0 ? void 0 : _a.find(function(ignoreHost) {
    return wildcardMatch(host, ignoreHost);
  })) {
    return false;
  }
  if (!options.captureRules && networkEvent.status !== void 0 && !isStatusCodeInRange(networkEvent.status, DEFAULT_STATUS_CODE_RANGE)) {
    return false;
  }
  if (options.captureRules) {
    var isMatch_1;
    __spreadArray([], __read$1(options.captureRules), false).reverse().find(function(rule) {
      isMatch_1 = isCaptureRuleMatch(rule, host, networkEvent.status);
      return isMatch_1 !== void 0;
    });
    if (!isMatch_1) {
      return false;
    }
  }
  return true;
}
function trackNetworkEvents(_a) {
  var allObservables = _a.allObservables, networkTrackingOptions = _a.networkTrackingOptions, amplitude = _a.amplitude;
  var networkObservable = allObservables.networkObservable;
  var filteredNetworkObservable = networkObservable.pipe(filter(function(event) {
    return shouldTrackNetworkEvent(event.event, networkTrackingOptions);
  }));
  return filteredNetworkObservable.subscribe(function(networkEvent) {
    var _a2;
    var request = networkEvent.event;
    var urlObj = parseUrl(request.url);
    if (!urlObj) {
      return;
    }
    var networkAnalyticsEvent = (_a2 = {}, _a2["[Amplitude] URL"] = urlObj.hrefWithoutQueryOrHash, _a2["[Amplitude] URL Query"] = urlObj.query, _a2["[Amplitude] URL Fragment"] = urlObj.fragment, _a2["[Amplitude] Request Method"] = request.method, _a2["[Amplitude] Status Code"] = request.status, _a2["[Amplitude] Start Time"] = request.startTime, _a2["[Amplitude] Completion Time"] = request.endTime, _a2["[Amplitude] Duration"] = request.duration, _a2["[Amplitude] Request Body Size"] = request.requestBodySize, _a2["[Amplitude] Response Body Size"] = request.responseBodySize, _a2);
    amplitude === null || amplitude === void 0 ? void 0 : amplitude.track(AMPLITUDE_NETWORK_REQUEST_EVENT, networkAnalyticsEvent);
  });
}
var ObservablesEnum;
(function(ObservablesEnum2) {
  ObservablesEnum2["NetworkObservable"] = "networkObservable";
})(ObservablesEnum || (ObservablesEnum = {}));
var networkCapturePlugin = function(options) {
  if (options === void 0) {
    options = {};
  }
  var name = PLUGIN_NAME;
  var type = "enrichment";
  var logger;
  var subscriptions = [];
  var addAdditionalEventProperties = function(event, type2) {
    var baseEvent = {
      event,
      timestamp: Date.now(),
      type: type2
    };
    return baseEvent;
  };
  var createObservables = function() {
    var _a;
    var networkObservable = new Observable(function(observer) {
      var callback = new NetworkEventCallback(function(event) {
        var eventWithProperties = addAdditionalEventProperties(event, "network");
        observer.next(eventWithProperties);
      });
      networkObserver.subscribe(callback, logger);
      return function() {
        networkObserver.unsubscribe(callback);
      };
    });
    return _a = {}, _a[ObservablesEnum.NetworkObservable] = networkObservable, _a;
  };
  var setup = function(config2, amplitude) {
    return __awaiter(void 0, void 0, void 0, function() {
      var allObservables, networkRequestSubscription;
      return __generator(this, function(_a) {
        if (typeof document === "undefined") {
          return [
            2
            /*return*/
          ];
        }
        allObservables = createObservables();
        networkRequestSubscription = trackNetworkEvents({
          allObservables,
          networkTrackingOptions: options,
          amplitude
        });
        subscriptions.push(networkRequestSubscription);
        logger = config2 === null || config2 === void 0 ? void 0 : config2.loggerProvider;
        logger === null || logger === void 0 ? void 0 : logger.log("".concat(name, " has been successfully added."));
        return [
          2
          /*return*/
        ];
      });
    });
  };
  var execute = function(event) {
    return __awaiter(void 0, void 0, void 0, function() {
      return __generator(this, function(_a) {
        return [2, event];
      });
    });
  };
  var teardown = function() {
    return __awaiter(void 0, void 0, void 0, function() {
      var subscriptions_1, subscriptions_1_1, subscription;
      var e_1, _a;
      return __generator(this, function(_b) {
        try {
          for (subscriptions_1 = __values$1(subscriptions), subscriptions_1_1 = subscriptions_1.next(); !subscriptions_1_1.done; subscriptions_1_1 = subscriptions_1.next()) {
            subscription = subscriptions_1_1.value;
            subscription.unsubscribe();
          }
        } catch (e_1_1) {
          e_1 = { error: e_1_1 };
        } finally {
          try {
            if (subscriptions_1_1 && !subscriptions_1_1.done && (_a = subscriptions_1.return)) _a.call(subscriptions_1);
          } finally {
            if (e_1) throw e_1.error;
          }
        }
        return [
          2
          /*return*/
        ];
      });
    });
  };
  return {
    name,
    type,
    setup,
    execute,
    teardown
  };
};
var UTM_CAMPAIGN = "utm_campaign";
var UTM_CONTENT = "utm_content";
var UTM_ID = "utm_id";
var UTM_MEDIUM = "utm_medium";
var UTM_SOURCE = "utm_source";
var UTM_TERM = "utm_term";
var DCLID = "dclid";
var FBCLID = "fbclid";
var GBRAID = "gbraid";
var GCLID = "gclid";
var KO_CLICK_ID = "ko_click_id";
var LI_FAT_ID = "li_fat_id";
var MSCLKID = "msclkid";
var RDT_CID = "rtd_cid";
var TTCLID = "ttclid";
var TWCLID = "twclid";
var WBRAID = "wbraid";
var BASE_CAMPAIGN = {
  utm_campaign: void 0,
  utm_content: void 0,
  utm_id: void 0,
  utm_medium: void 0,
  utm_source: void 0,
  utm_term: void 0,
  referrer: void 0,
  referring_domain: void 0,
  dclid: void 0,
  gbraid: void 0,
  gclid: void 0,
  fbclid: void 0,
  ko_click_id: void 0,
  li_fat_id: void 0,
  msclkid: void 0,
  rtd_cid: void 0,
  ttclid: void 0,
  twclid: void 0,
  wbraid: void 0
};
var domainWithoutSubdomain = function(domain) {
  var parts = domain.split(".");
  if (parts.length <= 2) {
    return domain;
  }
  return parts.slice(parts.length - 2, parts.length).join(".");
};
var isDirectTraffic = function(current) {
  return Object.values(current).every(function(value) {
    return !value;
  });
};
var isNewCampaign = function(current, previous, options, logger, isNewSession2) {
  if (isNewSession2 === void 0) {
    isNewSession2 = true;
  }
  current.referrer;
  var referring_domain = current.referring_domain, currentCampaign = __rest(current, ["referrer", "referring_domain"]);
  var _a = previous || {};
  _a.referrer;
  var prevReferringDomain = _a.referring_domain, previousCampaign = __rest(_a, ["referrer", "referring_domain"]);
  if (isExcludedReferrer(options.excludeReferrers, current.referring_domain)) {
    logger.debug("This is not a new campaign because ".concat(current.referring_domain, " is in the exclude referrer list."));
    return false;
  }
  if (!isNewSession2 && isDirectTraffic(current) && previous) {
    logger.debug("This is not a new campaign because this is a direct traffic in the same session.");
    return false;
  }
  var hasNewCampaign = JSON.stringify(currentCampaign) !== JSON.stringify(previousCampaign);
  var hasNewDomain = domainWithoutSubdomain(referring_domain || "") !== domainWithoutSubdomain(prevReferringDomain || "");
  var result = !previous || hasNewCampaign || hasNewDomain;
  if (!result) {
    logger.debug("This is not a new campaign because it's the same as the previous one.");
  } else {
    logger.debug("This is a new campaign. An $identify event will be sent.");
  }
  return result;
};
var isExcludedReferrer = function(excludeReferrers, referringDomain) {
  if (excludeReferrers === void 0) {
    excludeReferrers = [];
  }
  if (referringDomain === void 0) {
    referringDomain = "";
  }
  return excludeReferrers.some(function(value) {
    return value instanceof RegExp ? value.test(referringDomain) : value === referringDomain;
  });
};
var createCampaignEvent = function(campaign, options) {
  var campaignParameters = __assign$1(__assign$1({}, BASE_CAMPAIGN), campaign);
  var identifyEvent = Object.entries(campaignParameters).reduce(function(identify2, _a) {
    var _b;
    var _c = __read$1(_a, 2), key = _c[0], value = _c[1];
    identify2.setOnce("initial_".concat(key), (_b = value !== null && value !== void 0 ? value : options.initialEmptyValue) !== null && _b !== void 0 ? _b : "EMPTY");
    if (value) {
      return identify2.set(key, value);
    }
    return identify2.unset(key);
  }, new Identify());
  return createIdentifyEvent(identifyEvent);
};
var getDefaultExcludedReferrers = function(cookieDomain) {
  var domain = cookieDomain;
  if (domain) {
    if (domain.startsWith(".")) {
      domain = domain.substring(1);
    }
    return [new RegExp("".concat(domain.replace(".", "\\."), "$"))];
  }
  return [];
};
var CampaignParser = (
  /** @class */
  function() {
    function CampaignParser2() {
    }
    CampaignParser2.prototype.parse = function() {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          return [2, __assign$1(__assign$1(__assign$1(__assign$1({}, BASE_CAMPAIGN), this.getUtmParam()), this.getReferrer()), this.getClickIds())];
        });
      });
    };
    CampaignParser2.prototype.getUtmParam = function() {
      var params = getQueryParams$1();
      var utmCampaign = params[UTM_CAMPAIGN];
      var utmContent = params[UTM_CONTENT];
      var utmId = params[UTM_ID];
      var utmMedium = params[UTM_MEDIUM];
      var utmSource = params[UTM_SOURCE];
      var utmTerm = params[UTM_TERM];
      return {
        utm_campaign: utmCampaign,
        utm_content: utmContent,
        utm_id: utmId,
        utm_medium: utmMedium,
        utm_source: utmSource,
        utm_term: utmTerm
      };
    };
    CampaignParser2.prototype.getReferrer = function() {
      var _a, _b;
      var data = {
        referrer: void 0,
        referring_domain: void 0
      };
      try {
        data.referrer = document.referrer || void 0;
        data.referring_domain = (_b = (_a = data.referrer) === null || _a === void 0 ? void 0 : _a.split("/")[2]) !== null && _b !== void 0 ? _b : void 0;
      } catch (_c) {
      }
      return data;
    };
    CampaignParser2.prototype.getClickIds = function() {
      var _a;
      var params = getQueryParams$1();
      return _a = {}, _a[DCLID] = params[DCLID], _a[FBCLID] = params[FBCLID], _a[GBRAID] = params[GBRAID], _a[GCLID] = params[GCLID], _a[KO_CLICK_ID] = params[KO_CLICK_ID], _a[LI_FAT_ID] = params[LI_FAT_ID], _a[MSCLKID] = params[MSCLKID], _a[RDT_CID] = params[RDT_CID], _a[TTCLID] = params[TTCLID], _a[TWCLID] = params[TWCLID], _a[WBRAID] = params[WBRAID], _a;
    };
    return CampaignParser2;
  }()
);
var WebAttribution = (
  /** @class */
  function() {
    function WebAttribution2(options, config2) {
      var _a;
      this.shouldTrackNewCampaign = false;
      this.options = __assign$1({ initialEmptyValue: "EMPTY", resetSessionOnNewCampaign: false, excludeReferrers: getDefaultExcludedReferrers((_a = config2.cookieOptions) === null || _a === void 0 ? void 0 : _a.domain) }, options);
      this.storage = config2.cookieStorage;
      this.storageKey = getStorageKey(config2.apiKey, "MKTG");
      this.currentCampaign = BASE_CAMPAIGN;
      this.sessionTimeout = config2.sessionTimeout;
      this.lastEventTime = config2.lastEventTime;
      this.logger = config2.loggerProvider;
      config2.loggerProvider.log("Installing web attribution tracking.");
    }
    WebAttribution2.prototype.init = function() {
      return __awaiter(this, void 0, void 0, function() {
        var isEventInNewSession;
        var _a;
        return __generator(this, function(_b) {
          switch (_b.label) {
            case 0:
              return [4, this.fetchCampaign()];
            case 1:
              _a = __read$1.apply(void 0, [_b.sent(), 2]), this.currentCampaign = _a[0], this.previousCampaign = _a[1];
              isEventInNewSession = !this.lastEventTime ? true : isNewSession(this.sessionTimeout, this.lastEventTime);
              if (!isNewCampaign(this.currentCampaign, this.previousCampaign, this.options, this.logger, isEventInNewSession)) return [3, 3];
              this.shouldTrackNewCampaign = true;
              return [4, this.storage.set(this.storageKey, this.currentCampaign)];
            case 2:
              _b.sent();
              _b.label = 3;
            case 3:
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    WebAttribution2.prototype.fetchCampaign = function() {
      return __awaiter(this, void 0, void 0, function() {
        return __generator(this, function(_a) {
          switch (_a.label) {
            case 0:
              return [4, Promise.all([new CampaignParser().parse(), this.storage.get(this.storageKey)])];
            case 1:
              return [2, _a.sent()];
          }
        });
      });
    };
    WebAttribution2.prototype.generateCampaignEvent = function(event_id) {
      this.shouldTrackNewCampaign = false;
      var campaignEvent = createCampaignEvent(this.currentCampaign, this.options);
      if (event_id) {
        campaignEvent.event_id = event_id;
      }
      return campaignEvent;
    };
    WebAttribution2.prototype.shouldSetSessionIdOnNewCampaign = function() {
      return this.shouldTrackNewCampaign && !!this.options.resetSessionOnNewCampaign;
    };
    return WebAttribution2;
  }()
);
var AmplitudeBrowser = (
  /** @class */
  function(_super) {
    __extends(AmplitudeBrowser2, _super);
    function AmplitudeBrowser2() {
      return _super !== null && _super.apply(this, arguments) || this;
    }
    AmplitudeBrowser2.prototype.init = function(apiKey, userIdOrOptions, maybeOptions) {
      if (apiKey === void 0) {
        apiKey = "";
      }
      var userId;
      var options;
      if (arguments.length > 2) {
        userId = userIdOrOptions;
        options = maybeOptions;
      } else {
        if (typeof userIdOrOptions === "string") {
          userId = userIdOrOptions;
          options = void 0;
        } else {
          userId = userIdOrOptions === null || userIdOrOptions === void 0 ? void 0 : userIdOrOptions.userId;
          options = userIdOrOptions;
        }
      }
      return returnWrapper(this._init(__assign$1(__assign$1({}, options), { userId, apiKey })));
    };
    AmplitudeBrowser2.prototype._init = function(options) {
      var _a, _b, _c;
      return __awaiter(this, void 0, void 0, function() {
        var browserOptions, joinedConfigGenerator, attributionTrackingOptions, queryParams, querySessionId, connector;
        var _this = this;
        return __generator(this, function(_d) {
          switch (_d.label) {
            case 0:
              if (this.initializing) {
                return [
                  2
                  /*return*/
                ];
              }
              this.initializing = true;
              return [4, useBrowserConfig(options.apiKey, options, this)];
            case 1:
              browserOptions = _d.sent();
              if (!browserOptions.fetchRemoteConfig) return [3, 4];
              return [4, createBrowserJoinedConfigGenerator(browserOptions)];
            case 2:
              joinedConfigGenerator = _d.sent();
              return [4, joinedConfigGenerator.generateJoinedConfig()];
            case 3:
              browserOptions = _d.sent();
              _d.label = 4;
            case 4:
              return [4, _super.prototype._init.call(this, browserOptions)];
            case 5:
              _d.sent();
              this.logBrowserOptions(browserOptions);
              if (!isAttributionTrackingEnabled(this.config.defaultTracking)) return [3, 7];
              attributionTrackingOptions = getAttributionTrackingConfig(this.config);
              this.webAttribution = new WebAttribution(attributionTrackingOptions, this.config);
              return [4, this.webAttribution.init()];
            case 6:
              _d.sent();
              _d.label = 7;
            case 7:
              queryParams = getQueryParams$1();
              querySessionId = Number.isNaN(Number(queryParams.ampSessionId)) ? void 0 : Number(queryParams.ampSessionId);
              this.setSessionId((_c = (_b = (_a = options.sessionId) !== null && _a !== void 0 ? _a : querySessionId) !== null && _b !== void 0 ? _b : this.config.sessionId) !== null && _c !== void 0 ? _c : Date.now());
              connector = getAnalyticsConnector(options.instanceName);
              connector.identityStore.setIdentity({
                userId: this.config.userId,
                deviceId: this.config.deviceId
              });
              if (!(this.config.offline !== OfflineDisabled)) return [3, 9];
              return [4, this.add(networkConnectivityCheckerPlugin()).promise];
            case 8:
              _d.sent();
              _d.label = 9;
            case 9:
              return [4, this.add(new Destination()).promise];
            case 10:
              _d.sent();
              return [4, this.add(new Context()).promise];
            case 11:
              _d.sent();
              return [4, this.add(new IdentityEventSender()).promise];
            case 12:
              _d.sent();
              detNotify(this.config);
              if (!isFileDownloadTrackingEnabled(this.config.defaultTracking)) return [3, 14];
              this.config.loggerProvider.debug("Adding file download tracking plugin");
              return [4, this.add(fileDownloadTracking()).promise];
            case 13:
              _d.sent();
              _d.label = 14;
            case 14:
              if (!isFormInteractionTrackingEnabled(this.config.defaultTracking)) return [3, 16];
              this.config.loggerProvider.debug("Adding form interaction plugin");
              return [4, this.add(formInteractionTracking()).promise];
            case 15:
              _d.sent();
              _d.label = 16;
            case 16:
              if (!isPageViewTrackingEnabled(this.config.defaultTracking)) return [3, 18];
              this.config.loggerProvider.debug("Adding page view tracking plugin");
              return [4, this.add(pageViewTrackingPlugin(getPageViewTrackingConfig(this.config))).promise];
            case 17:
              _d.sent();
              _d.label = 18;
            case 18:
              if (!isElementInteractionsEnabled(this.config.autocapture)) return [3, 20];
              this.config.loggerProvider.debug("Adding user interactions plugin (autocapture plugin)");
              return [4, this.add(autocapturePlugin(getElementInteractionsConfig(this.config))).promise];
            case 19:
              _d.sent();
              _d.label = 20;
            case 20:
              if (!(isNetworkTrackingEnabled(this.config.autocapture) && !!this.config.networkTrackingOptions)) return [3, 22];
              this.config.loggerProvider.debug("Adding network tracking plugin");
              return [4, this.add(networkCapturePlugin(getNetworkTrackingConfig(this.config))).promise];
            case 21:
              _d.sent();
              _d.label = 22;
            case 22:
              this.initializing = false;
              return [4, this.runQueuedFunctions("dispatchQ")];
            case 23:
              _d.sent();
              connector.eventBridge.setEventReceiver(function(event) {
                void _this.track(event.eventType, event.eventProperties);
              });
              return [
                2
                /*return*/
              ];
          }
        });
      });
    };
    AmplitudeBrowser2.prototype.getUserId = function() {
      var _a;
      return (_a = this.config) === null || _a === void 0 ? void 0 : _a.userId;
    };
    AmplitudeBrowser2.prototype.setUserId = function(userId) {
      if (!this.config) {
        this.q.push(this.setUserId.bind(this, userId));
        return;
      }
      this.config.loggerProvider.debug("function setUserId: ", userId);
      if (userId !== this.config.userId || userId === void 0) {
        this.config.userId = userId;
        this.timeline.onIdentityChanged({ userId });
        setConnectorUserId(userId, this.config.instanceName);
      }
    };
    AmplitudeBrowser2.prototype.getDeviceId = function() {
      var _a;
      return (_a = this.config) === null || _a === void 0 ? void 0 : _a.deviceId;
    };
    AmplitudeBrowser2.prototype.setDeviceId = function(deviceId) {
      if (!this.config) {
        this.q.push(this.setDeviceId.bind(this, deviceId));
        return;
      }
      this.config.loggerProvider.debug("function setDeviceId: ", deviceId);
      if (deviceId !== this.config.deviceId) {
        this.config.deviceId = deviceId;
        this.timeline.onIdentityChanged({ deviceId });
        setConnectorDeviceId(deviceId, this.config.instanceName);
      }
    };
    AmplitudeBrowser2.prototype.reset = function() {
      this.setDeviceId(UUID());
      this.setUserId(void 0);
    };
    AmplitudeBrowser2.prototype.getSessionId = function() {
      var _a;
      return (_a = this.config) === null || _a === void 0 ? void 0 : _a.sessionId;
    };
    AmplitudeBrowser2.prototype.setSessionId = function(sessionId) {
      var _a;
      var promises = [];
      if (!this.config) {
        this.q.push(this.setSessionId.bind(this, sessionId));
        return returnWrapper(Promise.resolve());
      }
      if (sessionId === this.config.sessionId) {
        return returnWrapper(Promise.resolve());
      }
      this.config.loggerProvider.debug("function setSessionId: ", sessionId);
      var previousSessionId = this.getSessionId();
      if (previousSessionId !== sessionId) {
        this.timeline.onSessionIdChanged(sessionId);
      }
      var lastEventTime = this.config.lastEventTime;
      var lastEventId = (_a = this.config.lastEventId) !== null && _a !== void 0 ? _a : -1;
      this.config.sessionId = sessionId;
      this.config.lastEventTime = void 0;
      this.config.pageCounter = 0;
      if (isSessionTrackingEnabled(this.config.defaultTracking)) {
        if (previousSessionId && lastEventTime) {
          promises.push(this.track(DEFAULT_SESSION_END_EVENT, void 0, {
            device_id: this.previousSessionDeviceId,
            event_id: ++lastEventId,
            session_id: previousSessionId,
            time: lastEventTime + 1,
            user_id: this.previousSessionUserId
          }).promise);
        }
        this.config.lastEventTime = this.config.sessionId;
      }
      var isCampaignEventTracked = this.trackCampaignEventIfNeeded(++lastEventId, promises);
      if (isSessionTrackingEnabled(this.config.defaultTracking)) {
        promises.push(this.track(DEFAULT_SESSION_START_EVENT, void 0, {
          event_id: isCampaignEventTracked ? ++lastEventId : lastEventId,
          session_id: this.config.sessionId,
          time: this.config.lastEventTime
        }).promise);
      }
      this.previousSessionDeviceId = this.config.deviceId;
      this.previousSessionUserId = this.config.userId;
      return returnWrapper(Promise.all(promises));
    };
    AmplitudeBrowser2.prototype.extendSession = function() {
      if (!this.config) {
        this.q.push(this.extendSession.bind(this));
        return;
      }
      this.config.lastEventTime = Date.now();
    };
    AmplitudeBrowser2.prototype.setTransport = function(transport) {
      if (!this.config) {
        this.q.push(this.setTransport.bind(this, transport));
        return;
      }
      this.config.transportProvider = createTransport(transport);
    };
    AmplitudeBrowser2.prototype.identify = function(identify2, eventOptions) {
      if (isInstanceProxy(identify2)) {
        var queue = identify2._q;
        identify2._q = [];
        identify2 = convertProxyObjectToRealObject(new Identify(), queue);
      }
      if (eventOptions === null || eventOptions === void 0 ? void 0 : eventOptions.user_id) {
        this.setUserId(eventOptions.user_id);
      }
      if (eventOptions === null || eventOptions === void 0 ? void 0 : eventOptions.device_id) {
        this.setDeviceId(eventOptions.device_id);
      }
      return _super.prototype.identify.call(this, identify2, eventOptions);
    };
    AmplitudeBrowser2.prototype.groupIdentify = function(groupType, groupName, identify2, eventOptions) {
      if (isInstanceProxy(identify2)) {
        var queue = identify2._q;
        identify2._q = [];
        identify2 = convertProxyObjectToRealObject(new Identify(), queue);
      }
      return _super.prototype.groupIdentify.call(this, groupType, groupName, identify2, eventOptions);
    };
    AmplitudeBrowser2.prototype.revenue = function(revenue, eventOptions) {
      if (isInstanceProxy(revenue)) {
        var queue = revenue._q;
        revenue._q = [];
        revenue = convertProxyObjectToRealObject(new Revenue(), queue);
      }
      return _super.prototype.revenue.call(this, revenue, eventOptions);
    };
    AmplitudeBrowser2.prototype.trackCampaignEventIfNeeded = function(lastEventId, promises) {
      if (!this.webAttribution || !this.webAttribution.shouldTrackNewCampaign) {
        return false;
      }
      var campaignEvent = this.webAttribution.generateCampaignEvent(lastEventId);
      if (promises) {
        promises.push(this.track(campaignEvent).promise);
      } else {
        this.track(campaignEvent);
      }
      this.config.loggerProvider.log("Tracking attribution.");
      return true;
    };
    AmplitudeBrowser2.prototype.process = function(event) {
      return __awaiter(this, void 0, void 0, function() {
        var currentTime, isEventInNewSession, shouldSetSessionIdOnNewCampaign;
        return __generator(this, function(_a) {
          currentTime = Date.now();
          isEventInNewSession = isNewSession(this.config.sessionTimeout, this.config.lastEventTime);
          shouldSetSessionIdOnNewCampaign = this.webAttribution && this.webAttribution.shouldSetSessionIdOnNewCampaign();
          if (event.event_type !== DEFAULT_SESSION_START_EVENT && event.event_type !== DEFAULT_SESSION_END_EVENT && (!event.session_id || event.session_id === this.getSessionId())) {
            if (isEventInNewSession || shouldSetSessionIdOnNewCampaign) {
              this.setSessionId(currentTime);
              if (shouldSetSessionIdOnNewCampaign) {
                this.config.loggerProvider.log("Created a new session for new campaign.");
              }
            } else if (!isEventInNewSession) {
              this.trackCampaignEventIfNeeded();
            }
          }
          return [2, _super.prototype.process.call(this, event)];
        });
      });
    };
    AmplitudeBrowser2.prototype.logBrowserOptions = function(browserConfig) {
      try {
        var browserConfigCopy = __assign$1(__assign$1({}, browserConfig), { apiKey: browserConfig.apiKey.substring(0, 10) + "********" });
        this.config.loggerProvider.debug("Initialized Amplitude with BrowserConfig:", JSON.stringify(browserConfigCopy));
      } catch (e) {
        this.config.loggerProvider.error("Error logging browser config", e);
      }
    };
    return AmplitudeBrowser2;
  }(AmplitudeCore)
);
var createInstance = function() {
  var client2 = new AmplitudeBrowser();
  return {
    init: debugWrapper(client2.init.bind(client2), "init", getClientLogConfig(client2), getClientStates(client2, ["config"])),
    add: debugWrapper(client2.add.bind(client2), "add", getClientLogConfig(client2), getClientStates(client2, ["config.apiKey", "timeline.plugins"])),
    remove: debugWrapper(client2.remove.bind(client2), "remove", getClientLogConfig(client2), getClientStates(client2, ["config.apiKey", "timeline.plugins"])),
    track: debugWrapper(client2.track.bind(client2), "track", getClientLogConfig(client2), getClientStates(client2, ["config.apiKey", "timeline.queue.length"])),
    logEvent: debugWrapper(client2.logEvent.bind(client2), "logEvent", getClientLogConfig(client2), getClientStates(client2, ["config.apiKey", "timeline.queue.length"])),
    identify: debugWrapper(client2.identify.bind(client2), "identify", getClientLogConfig(client2), getClientStates(client2, ["config.apiKey", "timeline.queue.length"])),
    groupIdentify: debugWrapper(client2.groupIdentify.bind(client2), "groupIdentify", getClientLogConfig(client2), getClientStates(client2, ["config.apiKey", "timeline.queue.length"])),
    setGroup: debugWrapper(client2.setGroup.bind(client2), "setGroup", getClientLogConfig(client2), getClientStates(client2, ["config.apiKey", "timeline.queue.length"])),
    revenue: debugWrapper(client2.revenue.bind(client2), "revenue", getClientLogConfig(client2), getClientStates(client2, ["config.apiKey", "timeline.queue.length"])),
    flush: debugWrapper(client2.flush.bind(client2), "flush", getClientLogConfig(client2), getClientStates(client2, ["config.apiKey", "timeline.queue.length"])),
    getUserId: debugWrapper(client2.getUserId.bind(client2), "getUserId", getClientLogConfig(client2), getClientStates(client2, ["config", "config.userId"])),
    setUserId: debugWrapper(client2.setUserId.bind(client2), "setUserId", getClientLogConfig(client2), getClientStates(client2, ["config", "config.userId"])),
    getDeviceId: debugWrapper(client2.getDeviceId.bind(client2), "getDeviceId", getClientLogConfig(client2), getClientStates(client2, ["config", "config.deviceId"])),
    setDeviceId: debugWrapper(client2.setDeviceId.bind(client2), "setDeviceId", getClientLogConfig(client2), getClientStates(client2, ["config", "config.deviceId"])),
    reset: debugWrapper(client2.reset.bind(client2), "reset", getClientLogConfig(client2), getClientStates(client2, ["config", "config.userId", "config.deviceId"])),
    getSessionId: debugWrapper(client2.getSessionId.bind(client2), "getSessionId", getClientLogConfig(client2), getClientStates(client2, ["config"])),
    setSessionId: debugWrapper(client2.setSessionId.bind(client2), "setSessionId", getClientLogConfig(client2), getClientStates(client2, ["config"])),
    extendSession: debugWrapper(client2.extendSession.bind(client2), "extendSession", getClientLogConfig(client2), getClientStates(client2, ["config"])),
    setOptOut: debugWrapper(client2.setOptOut.bind(client2), "setOptOut", getClientLogConfig(client2), getClientStates(client2, ["config"])),
    setTransport: debugWrapper(client2.setTransport.bind(client2), "setTransport", getClientLogConfig(client2), getClientStates(client2, ["config"]))
  };
};
const client = createInstance();
var identify = client.identify, init = client.init, setUserId = client.setUserId, track = client.track;
class BasePlatformAdapter {
  constructor(config2) {
    __publicField(this, "name");
    __publicField(this, "config");
    this.name = config2.name;
    this.config = config2;
  }
}
const chatGptConfig = {
  name: "chatgpt",
  hostnames: ["chatgpt.com", "chat.openai.com"],
  endpoints: {
    USER_INFO: "/backend-api/me",
    CONVERSATIONS_LIST: "/backend-api/conversations",
    CHAT_COMPLETION: "/backend-api/conversation",
    SPECIFIC_CONVERSATION: /\/backend-api\/conversation\/([a-f0-9-]+)$/
  },
  domSelectors: {
    PROMPT_TEXTAREA: "#prompt-textarea",
    SUBMIT_BUTTON: 'form button[class*="submit"]'
  },
  // ChatGPT conversation ID detection patterns
  conversationIdPatterns: [
    { urlPath: /\/c\/([a-f0-9-]+)/ }
  ]
};
var ErrorCode = /* @__PURE__ */ ((ErrorCode2) => {
  ErrorCode2["NETWORK_ERROR"] = "network_error";
  ErrorCode2["TIMEOUT_ERROR"] = "timeout_error";
  ErrorCode2["API_ERROR"] = "api_error";
  ErrorCode2["VALIDATION_ERROR"] = "validation_error";
  ErrorCode2["NOT_FOUND_ERROR"] = "not_found_error";
  ErrorCode2["AUTH_ERROR"] = "auth_error";
  ErrorCode2["TOKEN_EXPIRED"] = "token_expired";
  ErrorCode2["PERMISSION_DENIED"] = "permission_denied";
  ErrorCode2["STORAGE_ERROR"] = "storage_error";
  ErrorCode2["EXTENSION_ERROR"] = "extension_error";
  ErrorCode2["INJECTION_ERROR"] = "injection_error";
  ErrorCode2["COMPONENT_ERROR"] = "component_error";
  ErrorCode2["UNKNOWN_ERROR"] = "unknown_error";
  return ErrorCode2;
})(ErrorCode || {});
class AppError extends Error {
  constructor(message, code = "unknown_error", originalError, metadata) {
    super(message);
    __publicField(this, "code");
    __publicField(this, "originalError");
    __publicField(this, "metadata");
    this.name = "AppError";
    this.code = code;
    this.originalError = originalError;
    this.metadata = metadata;
    Object.setPrototypeOf(this, AppError.prototype);
  }
  /**
   * Create error from an unknown error
   */
  static from(error, fallbackMessage = "An unexpected error occurred") {
    var _a, _b;
    if (error instanceof AppError) {
      return error;
    }
    if (error instanceof TypeError && error.message.includes("fetch")) {
      return new AppError(
        error.message || "Network request failed",
        "network_error",
        error
      );
    }
    if ((error == null ? void 0 : error.status) >= 400 || ((_a = error == null ? void 0 : error.response) == null ? void 0 : _a.status) >= 400) {
      return new AppError(
        error.message || "API request failed",
        "api_error",
        error,
        { status: error.status || ((_b = error.response) == null ? void 0 : _b.status) }
      );
    }
    return new AppError(
      (error == null ? void 0 : error.message) || fallbackMessage,
      "unknown_error",
      error
    );
  }
  /**
   * Convert to plain object for logging
   */
  toJSON() {
    return {
      name: this.name,
      message: this.message,
      code: this.code,
      stack: this.stack,
      metadata: this.metadata,
      originalError: this.originalError ? this.originalError instanceof Error ? { message: this.originalError.message, stack: this.originalError.stack } : this.originalError : void 0
    };
  }
}
const _ErrorReporter = class _ErrorReporter {
  constructor() {
    __publicField(this, "recentErrors", []);
    __publicField(this, "maxRecentErrors", 20);
    this.initializeEventListeners();
  }
  static getInstance() {
    if (!_ErrorReporter.instance) {
      _ErrorReporter.instance = new _ErrorReporter();
    }
    return _ErrorReporter.instance;
  }
  /**
   * Initialize event listeners for error tracking
   */
  initializeEventListeners() {
    onEvent(AppEvent.EXTENSION_ERROR, ({ message, stack }) => {
      this.captureError(new AppError(message, ErrorCode.EXTENSION_ERROR, { stack }));
    });
    if (typeof window !== "undefined") {
      window.addEventListener("error", (event) => {
        var _a;
        if ((_a = event.message) == null ? void 0 : _a.includes("ResizeObserver loop completed")) {
          return;
        }
        this.captureError(
          new AppError(
            event.message || "Unhandled error",
            ErrorCode.UNHANDLED_ERROR,
            { fileName: event.filename, lineNo: event.lineno, colNo: event.colno }
          )
        );
      });
      window.addEventListener("unhandledrejection", (event) => {
        var _a;
        const message = ((_a = event.reason) == null ? void 0 : _a.message) || "";
        if (message.includes("ResizeObserver loop completed")) {
          return;
        }
        this.captureError(
          new AppError(
            message || "Unhandled promise rejection",
            ErrorCode.UNHANDLED_REJECTION,
            event.reason
          )
        );
      });
    }
  }
  /**
   * Capture and report an error
   */
  captureError(error, metadata) {
    const appError = error instanceof AppError ? error : typeof error === "string" ? new AppError(error, ErrorCode.UNKNOWN_ERROR, void 0, metadata) : AppError.from(error);
    console.error("[ErrorReporter]", appError);
    this.recentErrors.push({
      error: appError,
      timestamp: Date.now()
    });
    if (this.recentErrors.length > this.maxRecentErrors) {
      this.recentErrors.shift();
    }
    if (!config$1.debug) {
      this.sendErrorToServer(appError);
    }
  }
  /**
   * Send error to server for logging
   */
  sendErrorToServer(error) {
    setTimeout(() => {
      console.log("[ErrorReporter] Error sent to server:", error.toJSON());
    }, 0);
  }
  /**
   * Get recent errors
   */
  getRecentErrors() {
    return [...this.recentErrors];
  }
  /**
   * Clear recent errors
   */
  clearRecentErrors() {
    this.recentErrors = [];
  }
};
__publicField(_ErrorReporter, "instance");
let ErrorReporter = _ErrorReporter;
const errorReporter = ErrorReporter.getInstance();
class ServiceManager {
  constructor() {
    __publicField(this, "services", /* @__PURE__ */ new Map());
    __publicField(this, "dependencies", /* @__PURE__ */ new Map());
    __publicField(this, "initialized", /* @__PURE__ */ new Set());
    __publicField(this, "isInitializing", false);
  }
  /**
   * Register a service with optional dependencies
   */
  registerService(name, service, dependencies = []) {
    if (this.services.has(name)) {
      debug(`Service '${name}' is already registered. Overwriting.`);
    }
    this.services.set(name, service);
    this.dependencies.set(name, dependencies);
  }
  /**
   * Get a registered service
   */
  getService(name) {
    return this.services.get(name);
  }
  /**
   * Get all registered services
   */
  getAllServices() {
    return Array.from(this.services.entries());
  }
  /**
   * Check if a service is registered
   */
  hasService(name) {
    return this.services.has(name);
  }
  /**
   * Check if a service is initialized
   */
  isServiceInitialized(name) {
    return this.initialized.has(name);
  }
  /**
   * Initialize all registered services with dependency resolution
   */
  async initializeAll() {
    if (this.isInitializing) {
      debug("Services are already being initialized");
      return false;
    }
    this.isInitializing = true;
    try {
      const initOrder = this.getInitializationOrder();
      debug("Initializing services in order:", initOrder);
      for (const serviceName of initOrder) {
        await this.initializeService(serviceName);
      }
      debug("All services initialized successfully");
      this.isInitializing = false;
      return true;
    } catch (error) {
      errorReporter.captureError(
        new AppError("Failed to initialize services", ErrorCode.EXTENSION_ERROR, error)
      );
      this.isInitializing = false;
      return false;
    }
  }
  /**
   * Initialize a specific service and its dependencies
   */
  async initializeService(serviceName) {
    if (this.initialized.has(serviceName)) {
      return;
    }
    const service = this.services.get(serviceName);
    if (!service) {
      debug(`Service '${serviceName}' not found, skipping initialization`);
      return;
    }
    const dependencies = this.dependencies.get(serviceName) || [];
    for (const dependency of dependencies) {
      await this.initializeService(dependency);
    }
    debug(`Initializing service: ${serviceName}`);
    try {
      await service.initialize();
      this.initialized.add(serviceName);
      debug(`Service initialized: ${serviceName}`);
    } catch (error) {
      debug(`Error initializing service '${serviceName}':`, error);
      throw new AppError(
        `Failed to initialize service '${serviceName}'`,
        ErrorCode.EXTENSION_ERROR,
        error
      );
    }
  }
  /**
   * Clean up all services in reverse initialization order
   */
  cleanupAll() {
    debug("Cleaning up all services");
    const cleanupOrder = [...this.getInitializationOrder()].reverse();
    for (const serviceName of cleanupOrder) {
      this.cleanupService(serviceName);
    }
    this.initialized.clear();
    debug("All services cleaned up");
  }
  /**
   * Clean up a specific service
   */
  cleanupService(serviceName) {
    if (!this.initialized.has(serviceName)) {
      return;
    }
    const service = this.services.get(serviceName);
    if (!service) {
      return;
    }
    debug(`Cleaning up service: ${serviceName}`);
    try {
      service.cleanup();
      this.initialized.delete(serviceName);
    } catch (error) {
      errorReporter.captureError(
        new AppError(`Error cleaning up service '${serviceName}'`, ErrorCode.EXTENSION_ERROR, error)
      );
    }
  }
  /**
   * Get order for initializing services based on dependencies
   */
  getInitializationOrder() {
    const result = [];
    const visited = /* @__PURE__ */ new Set();
    const temp = /* @__PURE__ */ new Set();
    const visit = (name) => {
      if (visited.has(name)) return;
      if (temp.has(name)) {
        throw new Error(`Circular dependency detected for service: ${name}`);
      }
      if (!this.services.has(name)) {
        debug(`Dependency '${name}' not found in registered services, skipping`);
        return;
      }
      temp.add(name);
      const dependencies = this.dependencies.get(name) || [];
      for (const dep of dependencies) {
        visit(dep);
      }
      temp.delete(name);
      visited.add(name);
      result.push(name);
    };
    for (const name of this.services.keys()) {
      visit(name);
    }
    return result;
  }
  /**
   * Clear all services and state
   * Primarily used for testing
   */
  clear() {
    this.services.clear();
    this.dependencies.clear();
    this.initialized.clear();
    this.isInitializing = false;
  }
}
const serviceManager = new ServiceManager();
const _ApiClient = class _ApiClient extends AbstractBaseService {
  constructor(baseUrl) {
    super();
    __publicField(this, "baseUrl");
    __publicField(this, "pendingRequests", /* @__PURE__ */ new Map());
    this.baseUrl = baseUrl || ENV.API_URL;
    console.log(`🔌 API Client initialized with base URL: ${this.baseUrl}`);
  }
  /**
   * Get the singleton instance
   */
  static getInstance(baseUrl) {
    if (!_ApiClient.instance) {
      _ApiClient.instance = new _ApiClient(baseUrl);
    } else if (baseUrl && baseUrl !== _ApiClient.instance.baseUrl) {
      console.log(`🔄 Updating API base URL from ${_ApiClient.instance.baseUrl} to ${baseUrl}`);
      _ApiClient.instance.setBaseUrl(baseUrl);
    }
    return _ApiClient.instance;
  }
  /**
   * Initialize the API client
   */
  async onInitialize() {
    debug("Initializing API client...");
    {
      debug(`Development mode: Using API URL ${this.baseUrl}`);
    }
  }
  /**
   * Clean up resources
   */
  onCleanup() {
    this.pendingRequests.clear();
    debug("API client cleaned up");
  }
  /**
   * Make an API request with authentication and deduplication
   */
  async request(endpoint, options = {}) {
    const requestKey = `${endpoint}-${JSON.stringify(options)}`;
    if (this.pendingRequests.has(requestKey)) {
      try {
        return await this.pendingRequests.get(requestKey);
      } catch (error) {
      }
    }
    const requestPromise = this._executeRequest(endpoint, options);
    this.pendingRequests.set(requestKey, requestPromise);
    try {
      const result = await requestPromise;
      this.pendingRequests.delete(requestKey);
      return result;
    } catch (error) {
      this.pendingRequests.delete(requestKey);
      throw error;
    }
  }
  /**
   * Execute the actual API request
   */
  async _executeRequest(endpoint, options = {}, retryCount = 0) {
    var _a, _b;
    try {
      const authService2 = serviceManager.getService("auth.state");
      let token = null;
      if (!authService2) {
        debug("Auth service not available");
        if (endpoint.startsWith("/public/") || options.allowAnonymous) {
          token = null;
        } else {
          throw new Error("Authentication service not available");
        }
      } else {
        try {
          const tokenService = serviceManager.getService("auth.token");
          if (tokenService) {
            const authTokenResponse = await tokenService.getAuthToken();
            if (authTokenResponse.success) {
              token = authTokenResponse.token;
            } else {
              debug("Failed to get auth token:", authTokenResponse.error);
              if (endpoint.startsWith("/public/") || options.allowAnonymous) {
                token = null;
              } else {
                throw new Error(authTokenResponse.error || "Failed to get auth token");
              }
            }
          } else {
            const legacyAuth = serviceManager.getService("auth");
            if (legacyAuth && typeof legacyAuth.getAuthToken === "function") {
              const authTokenResponse = await legacyAuth.getAuthToken();
              if (authTokenResponse.success) {
                token = authTokenResponse.token;
              } else {
                debug("Failed to get auth token with legacy service");
                if (endpoint.startsWith("/public/") || options.allowAnonymous) {
                  token = null;
                } else {
                  throw new Error(authTokenResponse.error || "Failed to get auth token");
                }
              }
            } else {
              if (endpoint.startsWith("/public/") || options.allowAnonymous) {
                token = null;
              } else {
                throw new Error("No authentication service available");
              }
            }
          }
        } catch (tokenError) {
          if (endpoint.startsWith("/public/") || options.allowAnonymous) {
            token = null;
          } else {
            throw tokenError;
          }
        }
      }
      const defaultOptions = {
        headers: {
          "Content-Type": "application/json",
          ...token ? { "Authorization": `Bearer ${token}` } : {}
        }
      };
      const fetchOptions = {
        ...defaultOptions,
        ...options,
        headers: {
          ...defaultOptions.headers,
          ...options.headers
        }
      };
      debug(`Requesting ${options.method || "GET"} ${endpoint}`);
      const normalizedEndpoint = endpoint.startsWith("/") ? endpoint : `/${endpoint}`;
      const response = await fetch(`${this.baseUrl}${normalizedEndpoint}`, fetchOptions);
      if (response.status === 403 || response.status === 401) {
        if (retryCount < 1) {
          try {
            const tokenService = serviceManager.getService("auth.token");
            if (tokenService && typeof tokenService.refreshToken === "function") {
              const refreshSuccess = await tokenService.refreshToken();
              if (refreshSuccess) {
                const authTokenResponse = await tokenService.getAuthToken();
                token = authTokenResponse.token;
                const newOptions = {
                  ...options,
                  headers: {
                    ...options.headers,
                    "Authorization": `Bearer ${token}`
                  }
                };
                return this._executeRequest(endpoint, newOptions, retryCount + 1);
              } else {
                throw new Error("Token refresh failed");
              }
            } else {
              const legacyAuth = serviceManager.getService("auth");
              if (legacyAuth && typeof legacyAuth.refreshToken === "function") {
                const refreshSuccess = await legacyAuth.refreshToken();
                if (refreshSuccess) {
                  const authTokenResponse = await legacyAuth.getAuthToken();
                  token = authTokenResponse.token;
                  const newOptions = {
                    ...options,
                    headers: {
                      ...options.headers,
                      "Authorization": `Bearer ${token}`
                    }
                  };
                  return this._executeRequest(endpoint, newOptions, retryCount + 1);
                } else {
                  throw new Error("Token refresh failed with legacy service");
                }
              } else {
                throw new Error("No authentication service available for token refresh");
              }
            }
          } catch (refreshError) {
            const error = refreshError instanceof Error ? refreshError.message : "Authentication failed after token refresh attempt";
            debug("Token refresh failed:", error);
            throw new Error(error);
          }
        } else {
          throw new Error("Authentication failed after retry");
        }
      }
      if (!response.ok) {
        const errorText = await response.text();
        let errorData;
        try {
          errorData = JSON.parse(errorText);
        } catch (e) {
          errorData = { detail: errorText };
        }
        const errorMessage = (errorData == null ? void 0 : errorData.detail) || `API error: ${response.status}`;
        debug(`API error: ${errorMessage}`);
        throw new Error(errorMessage);
      }
      try {
        const data = await response.json();
        return data;
      } catch (jsonError) {
        debug("Response was not JSON, returning success object");
        return { success: true, message: "Request successful but response was not JSON" };
      }
    } catch (error) {
      if (error instanceof Error && (((_a = error.message) == null ? void 0 : _a.includes("network")) || ((_b = error.message) == null ? void 0 : _b.includes("fetch"))) && retryCount < 2 && (!options.method || options.method === "GET")) {
        const delay2 = 1e3 * (retryCount + 1);
        debug(`Network error, retrying in ${delay2}ms (attempt ${retryCount + 1})`);
        await new Promise((resolve) => setTimeout(resolve, delay2));
        return this._executeRequest(endpoint, options, retryCount + 1);
      }
      errorReporter.captureError(
        new AppError(`API request to ${endpoint} failed`, ErrorCode.API_ERROR, error)
      );
      throw error;
    }
  }
  /**
   * Set base URL
   */
  setBaseUrl(url) {
    this.baseUrl = url;
    debug(`API base URL set to: ${url}`);
  }
  /**
   * Get base URL
   */
  getBaseUrl() {
    return this.baseUrl;
  }
};
__publicField(_ApiClient, "instance");
let ApiClient = _ApiClient;
const apiClient = ApiClient.getInstance();
class MessageApi {
  /**
   * Save a batch of messages in one operation
   */
  async saveMessageBatch(messages) {
    console.log("saveMessageBatch", messages);
    return apiClient.request("/save/batch/message", {
      method: "POST",
      body: JSON.stringify({
        messages
      })
    });
  }
  /**
   * Save a single message
   */
  async saveMessage(message) {
    return apiClient.request("/save/message", {
      method: "POST",
      body: JSON.stringify(message)
    });
  }
  /**
   * Save a batch of chats
   */
  async saveChatBatch(chats) {
    return apiClient.request("/save/batch/chat", {
      method: "POST",
      body: JSON.stringify({
        chats
      })
    });
  }
  /**
   * Save a single chat
   */
  async saveChat(chat) {
    return apiClient.request("/save/chat", {
      method: "POST",
      body: JSON.stringify({
        chat_provider_id: chat.chat_provider_id,
        title: chat.title,
        provider_name: chat.provider_name || "ChatGPT"
      })
    });
  }
  /**
   * Save a batch of chats and messages
   */
  async saveBatch(batchData) {
    return apiClient.request("/save/batch", {
      method: "POST",
      body: JSON.stringify(batchData)
    });
  }
}
const messageApi = new MessageApi();
const claudeConfig = {
  name: "claude",
  hostnames: ["claude.ai"],
  endpoints: {
    USER_INFO: "/api/user",
    CONVERSATIONS_LIST: /\/api\/organizations\/[a-f0-9-]+\/chat_conversations/,
    CHAT_COMPLETION: /\/api\/organizations\/[a-f0-9-]+\/chat_conversations\/[a-f0-9-]+\/completion/,
    SPECIFIC_CONVERSATION: /\/api\/organizations\/[a-f0-9-]+\/chat_conversations\/([a-f0-9-]+)/
  },
  domSelectors: {
    PROMPT_TEXTAREA: '[aria-label="Write your prompt to Claude"]',
    SUBMIT_BUTTON: 'button[class*="send"]'
  },
  // ChatGPT conversation ID detection patterns
  conversationIdPatterns: [
    { urlPath: /\/chat\/([a-f0-9-]+)/ }
  ]
};
const mistralConfig = {
  name: "mistral",
  hostnames: ["chat.mistral.ai"],
  endpoints: {
    USER_INFO: "/api/trpc/user.session",
    CONVERSATIONS_LIST: "/api/trpc/chat.list",
    CHAT_COMPLETION: "/api/chat",
    SPECIFIC_CONVERSATION: /\/api\/chat/
  },
  domSelectors: {
    PROMPT_TEXTAREA: 'textarea[name="message.text"]',
    SUBMIT_BUTTON: 'form button[type="submit"]'
  },
  conversationIdPatterns: [
    { urlPath: /\/chat\/([a-f0-9-]+)/ }
  ]
};
const copilotConfig = {
  name: "copilot",
  hostnames: ["copilot.microsoft.com"],
  endpoints: {
    USER_INFO: "/c/api/user",
    CONVERSATIONS_LIST: "/c/api/conversations",
    CHAT_COMPLETION: "/c/api/conversations",
    SPECIFIC_CONVERSATION: /\/c\/api\/conversations\/([a-zA-Z0-9-]+)\/history/
  },
  domSelectors: {
    PROMPT_TEXTAREA: "#userInput",
    SUBMIT_BUTTON: 'form button[type="submit"]'
  },
  conversationIdPatterns: [
    { urlPath: /\/c\/api\/conversations\/([a-zA-Z0-9-]+)/ }
  ]
};
const platformConfigs = [
  chatGptConfig,
  claudeConfig,
  mistralConfig,
  copilotConfig
];
function getConfigByHostname(hostname) {
  return platformConfigs.find(
    (config2) => config2.hostnames.some((h) => hostname.includes(h))
  ) || null;
}
function getConfigByName(name) {
  return platformConfigs.find((config2) => config2.name === name) || null;
}
const _ChatService = class _ChatService extends AbstractBaseService {
  constructor() {
    super();
    __publicField(this, "currentConversationId", null);
    __publicField(this, "currentPlatform", null);
    __publicField(this, "urlObserver", null);
    /**
     * Check URL for conversation ID using platform-specific patterns from config
     */
    __publicField(this, "checkUrlForConversationId", () => {
      try {
        const platformName = this.currentPlatform || detectPlatform();
        const config2 = getConfigByName(platformName);
        if (!config2) {
          debug(`No configuration found for platform: ${platformName}`);
          return;
        }
        let foundConversationId = null;
        for (const pattern of config2.conversationIdPatterns) {
          if (pattern.urlPath) {
            const match = window.location.pathname.match(pattern.urlPath);
            if (match && match[1]) {
              foundConversationId = match[1];
              break;
            }
          }
          if (pattern.queryParam) {
            const urlParams = new URLSearchParams(window.location.search);
            const paramValue = urlParams.get(pattern.queryParam);
            if (paramValue) {
              foundConversationId = paramValue;
              break;
            }
          }
        }
        if (foundConversationId && foundConversationId !== this.currentConversationId) {
          debug(`Detected conversation ID from URL: ${foundConversationId} (platform: ${platformName})`);
          this.setCurrentConversationId(foundConversationId);
        }
      } catch (error) {
        errorReporter.captureError(
          new AppError("Error checking URL for conversation ID", ErrorCode.EXTENSION_ERROR, error)
        );
      }
    });
  }
  static getInstance() {
    if (!_ChatService.instance) {
      _ChatService.instance = new _ChatService();
    }
    return _ChatService.instance;
  }
  async onInitialize() {
    debug("Initializing ChatService");
    this.currentPlatform = detectPlatform();
    debug(`Detected platform: ${this.currentPlatform}`);
    window.addEventListener("popstate", this.checkUrlForConversationId);
    window.addEventListener("hashchange", this.checkUrlForConversationId);
    this.observeUrlChanges();
    this.checkUrlForConversationId();
    document.addEventListener("jaydai:conversation-list", handleConversationList);
    document.addEventListener("jaydai:specific-conversation", handleSpecificConversation);
    document.addEventListener("jaydai:chat-completion", handleChatCompletion);
    document.addEventListener("jaydai:assistant-response", handleAssistantResponse);
  }
  onCleanup() {
    window.removeEventListener("popstate", this.checkUrlForConversationId);
    window.removeEventListener("hashchange", this.checkUrlForConversationId);
    if (this.urlObserver) {
      this.urlObserver.disconnect();
      this.urlObserver = null;
    }
    document.removeEventListener("jaydai:conversation-list", handleConversationList);
    document.removeEventListener("jaydai:specific-conversation", handleSpecificConversation);
    document.removeEventListener("jaydai:chat-completion", handleChatCompletion);
    document.removeEventListener("jaydai:assistant-response", handleAssistantResponse);
    debug("ChatService cleaned up");
  }
  observeUrlChanges() {
    try {
      let lastUrl = window.location.href;
      this.urlObserver = new MutationObserver(() => {
        const currentUrl = window.location.href;
        if (currentUrl !== lastUrl) {
          lastUrl = currentUrl;
          this.checkUrlForConversationId();
        }
      });
      this.urlObserver.observe(document.body, {
        childList: true,
        subtree: true
      });
    } catch (error) {
      debug("Error setting up URL observer:", error);
    }
  }
  /**
   * Get current conversation ID
   */
  getCurrentConversationId() {
    return this.currentConversationId;
  }
  /**
   * Set current conversation ID
   */
  setCurrentConversationId(conversationId) {
    if (this.currentConversationId === conversationId) return;
    this.currentConversationId = conversationId;
    emitEvent(AppEvent.CHAT_CONVERSATION_CHANGED, { conversationId });
    document.dispatchEvent(new CustomEvent("jaydai:conversation-changed", {
      detail: { conversationId }
    }));
  }
  /**
   * Manually set conversation ID from external source
   * This is useful when we know the ID from an API response
   */
  setConversationIdFromResponse(conversationId) {
    if (!conversationId || conversationId === "") return;
    debug(`Setting conversation ID from API response: ${conversationId}`);
    this.setCurrentConversationId(conversationId);
  }
};
__publicField(_ChatService, "instance");
let ChatService = _ChatService;
const chatService = ChatService.getInstance();
class ChatGptAdapter extends BasePlatformAdapter {
  constructor() {
    super(chatGptConfig);
  }
  /**
   * Extract user message from request body
   */
  extractUserMessage(requestBody, url) {
    var _a, _b;
    try {
      const message = (_a = requestBody.messages) == null ? void 0 : _a.find(
        (m) => {
          var _a2;
          return ((_a2 = m.author) == null ? void 0 : _a2.role) === "user" || m.role === "user";
        }
      );
      if (!message) return null;
      let content = "";
      if (typeof message.content === "object" && ((_b = message.content) == null ? void 0 : _b.parts)) {
        content = message.content.parts.join("\n");
      } else if (typeof message.content === "string") {
        content = message.content;
      }
      const conversationId = requestBody.conversation_id || "";
      return {
        messageId: message.id || `user-${Date.now()}`,
        conversationId,
        content,
        role: "user",
        model: requestBody.model || "unknown",
        timestamp: message.create_time ? message.create_time * 1e3 : Date.now(),
        parent_message_provider_id: requestBody.parent_message_id
      };
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error extracting user message", ErrorCode.PARSING_ERROR, error)
      );
      return null;
    }
  }
  /**
   * Extract assistant message from response data
   */
  extractAssistantMessage(data) {
    try {
      return {
        messageId: data.messageId,
        conversationId: data.conversationId || "",
        content: data.content,
        role: "assistant",
        model: data.model || "unknown",
        timestamp: data.createTime ? data.createTime * 1e3 : Date.now(),
        thinkingTime: data.thinkingTime,
        parent_message_provider_id: data.parentMessageId
      };
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error extracting assistant message", ErrorCode.PARSING_ERROR, error)
      );
      return null;
    }
  }
  /**
   * Extract conversation data
   */
  extractConversation(data) {
    try {
      if (!(data == null ? void 0 : data.conversation_id)) return null;
      return {
        chat_provider_id: data.conversation_id,
        title: data.title || "Conversation",
        provider_name: "ChatGPT"
      };
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error extracting conversation", ErrorCode.PARSING_ERROR, error)
      );
      return null;
    }
  }
  /**
   * Extract messages from conversation data
   */
  extractMessagesFromConversation(conversation) {
    try {
      const messages = [];
      if (conversation.mapping) {
        Object.entries(conversation.mapping).forEach(([messageId, node]) => {
          var _a, _b, _c, _d;
          if (messageId === "client-created-root") return;
          if ((_b = (_a = node.message) == null ? void 0 : _a.author) == null ? void 0 : _b.role) {
            const role = node.message.author.role;
            if (role === "user" || role === "assistant") {
              let content = "";
              const contentType = (_c = node.message.content) == null ? void 0 : _c.content_type;
              if (contentType === "text") {
                content = Array.isArray(node.message.content.parts) ? node.message.content.parts.join("\n") : node.message.content.parts || "";
              }
              messages.push({
                messageId,
                conversationId: conversation.conversation_id,
                content,
                role,
                model: ((_d = node.message.metadata) == null ? void 0 : _d.model_slug) || "unknown",
                timestamp: node.message.create_time ? node.message.create_time * 1e3 : Date.now(),
                parent_message_provider_id: node.parent
              });
            }
          }
        });
      }
      return messages.sort((a, b) => a.timestamp - b.timestamp);
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error extracting messages from conversation", ErrorCode.PARSING_ERROR, error)
      );
      return [];
    }
  }
  /**
   * Handle conversation list event
   */
  async handleConversationList(responseData) {
    try {
      if (!(responseData == null ? void 0 : responseData.items) || !Array.isArray(responseData.items)) {
        return Promise.resolve();
      }
      const processedChats = responseData.items.map((chat) => ({
        chat_provider_id: chat.id,
        title: chat.title || "Unnamed Conversation",
        provider_name: "ChatGPT"
      })).filter(
        (chat) => chat.chat_provider_id && chat.chat_provider_id.trim() !== ""
      );
      if (processedChats.length > 0) {
        await messageApi.saveChatBatch(processedChats);
      }
      return Promise.resolve();
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error handling ChatGPT conversation list", ErrorCode.API_ERROR, error)
      );
      return Promise.resolve();
    }
  }
  /**
   * Handle specific conversation event
   */
  async handleSpecificConversation(responseBody) {
    try {
      if (!(responseBody == null ? void 0 : responseBody.conversation_id)) return Promise.resolve();
      const conversation = this.extractConversation(responseBody);
      const messages = this.extractMessagesFromConversation(responseBody);
      if (conversation && messages.length > 0) {
        await messageApi.saveChat(conversation);
        await messageApi.saveMessageBatch(messages.map((msg) => ({
          message_provider_id: msg.messageId,
          chat_provider_id: msg.conversationId,
          content: msg.content,
          role: msg.role,
          model: msg.model || "unknown",
          created_at: msg.timestamp,
          parent_message_provider_id: msg.parent_message_provider_id
        })));
        chatService.setCurrentConversationId(conversation.chat_provider_id);
        document.dispatchEvent(new CustomEvent("jaydai:conversation-loaded", {
          detail: { conversation, messages }
        }));
      }
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error handling specific conversation", ErrorCode.PARSING_ERROR, error)
      );
    }
    return Promise.resolve();
  }
  /**
   * Handle chat completion event
   */
  handleChatCompletion(event) {
    var _a;
    try {
      const { requestBody } = event.detail;
      if (!((_a = requestBody == null ? void 0 : requestBody.messages) == null ? void 0 : _a.length)) return;
      const message = this.extractUserMessage(requestBody);
      if (message) {
        document.dispatchEvent(new CustomEvent("jaydai:message-extracted", {
          detail: { message, platform: this.name }
        }));
      }
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error handling chat completion", ErrorCode.PARSING_ERROR, error)
      );
    }
  }
  /**
   * Handle assistant response event
   */
  handleAssistantResponse(event) {
    try {
      const data = event.detail;
      if (!data.messageId || !data.content) return;
      if (data.isComplete) {
        const message = this.extractAssistantMessage(data);
        if (message) {
          document.dispatchEvent(new CustomEvent("jaydai:message-extracted", {
            detail: { message, platform: this.name }
          }));
        }
      }
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error handling assistant response", ErrorCode.PARSING_ERROR, error)
      );
    }
  }
  /**
   * Insert content into ChatGPT textarea
   */
  insertPrompt(content) {
    if (!content) {
      console.error("No content to insert into ChatGPT");
      return false;
    }
    try {
      const textarea = document.querySelector(this.config.domSelectors.PROMPT_TEXTAREA);
      if (!textarea) {
        console.error("Could not find ChatGPT textarea element");
        return false;
      }
      const normalizedContent = content.replace(/\r\n/g, "\n");
      try {
        textarea.focus();
        if (textarea instanceof HTMLTextAreaElement) {
          textarea.value = normalizedContent;
          textarea.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
          textarea.selectionStart = textarea.selectionEnd = normalizedContent.length;
          return true;
        }
        if (textarea instanceof HTMLElement && textarea.isContentEditable) {
          const escapeHTML = (str) => {
            return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
          };
          const paragraphs = normalizedContent.split("\n");
          const paragraphsHTML = paragraphs.map(
            (p) => `<p>${escapeHTML(p) || "<br>"}</p>`
          ).join("");
          textarea.innerHTML = paragraphsHTML;
          textarea.dispatchEvent(new Event("input", { bubbles: true }));
          return true;
        }
      } catch (e) {
        console.warn("Primary method failed for ChatGPT:", e);
      }
      try {
        textarea.focus();
        document.execCommand("insertText", false, normalizedContent);
        return true;
      } catch (e) {
        console.warn("Fallback method failed for ChatGPT:", e);
      }
      console.error("All insertion methods failed for ChatGPT");
      return false;
    } catch (error) {
      console.error("Error inserting content into ChatGPT:", error);
      return false;
    }
  }
  /**
   * Check if platform supports streaming
   */
  supportsStreaming() {
    return true;
  }
  /**
   * Get model from UI element on the page
   */
  getModelFromUI() {
    try {
      const modelElement = document.querySelector('[aria-label="Model selector"]') || document.querySelector('[data-testid="model-selector"]');
      if (modelElement) {
        const modelText = modelElement.textContent || "";
        const modelMatch = modelText.match(/(GPT-\d+(\.\d+)?)/i);
        if (modelMatch && modelMatch[1]) {
          return modelMatch[1].toLowerCase();
        }
      }
      return "unknown";
    } catch (error) {
      return "unknown";
    }
  }
  /**
   * Process streaming response
   */
  async processStreamingResponse(response, requestBody) {
    if (!response || !response.body) {
      console.error("Invalid response object for streaming");
      return;
    }
    const clonedResponse = response.clone();
    const reader = clonedResponse.body.getReader();
    const decoder = new TextDecoder();
    let buffer2 = "";
    let assistantData = {
      messageId: null,
      conversationId: null,
      model: null,
      content: "",
      isComplete: false,
      createTime: null,
      parentMessageId: null
    };
    let thinkingSteps = [];
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer2 += decoder.decode(value, { stream: true });
        let eventEndIndex;
        while ((eventEndIndex = buffer2.indexOf("\n\n")) !== -1) {
          const eventString = buffer2.substring(0, eventEndIndex + 2);
          buffer2 = buffer2.substring(eventEndIndex + 2);
          const eventMatch = eventString.match(/^event: ([^\n]+)/);
          const dataMatch = eventString.match(/data: (.+)$/m);
          if (!dataMatch) continue;
          const eventType = eventMatch ? eventMatch[1] : "unknown";
          if (dataMatch[1] === "[DONE]") {
            if (assistantData.messageId && assistantData.content.length > 0) {
              assistantData.isComplete = true;
              this.dispatchAssistantResponse(assistantData);
            }
            continue;
          }
          try {
            const data = JSON.parse(dataMatch[1]);
            if (data.type === "message_stream_complete") {
              if (assistantData.messageId) {
                assistantData.isComplete = true;
                this.dispatchAssistantResponse(assistantData);
              }
              continue;
            }
            const result = this.processStreamData(data, assistantData, thinkingSteps);
            assistantData = result.assistantData;
            thinkingSteps = result.thinkingSteps;
            if (assistantData.messageId && assistantData.content.length > 0 && assistantData.content.length % 500 === 0) {
              this.dispatchAssistantResponse({
                ...assistantData,
                isComplete: false
              });
            }
          } catch (error) {
            console.error("Error parsing stream data:", error);
          }
        }
      }
      if (assistantData.messageId && assistantData.content.length > 0 && !assistantData.isComplete) {
        assistantData.isComplete = true;
        this.dispatchAssistantResponse(assistantData);
      }
    } catch (error) {
      console.error("Error processing stream:", error);
      if (assistantData.messageId && assistantData.content.length > 0) {
        assistantData.isComplete = true;
        this.dispatchAssistantResponse(assistantData);
      }
    }
  }
  /**
   * Helper method to dispatch assistant response events
   */
  dispatchAssistantResponse(assistantData) {
    document.dispatchEvent(new CustomEvent("jaydai:assistant-response", {
      detail: {
        ...assistantData,
        platform: this.name
      }
    }));
  }
  /**
   * Process individual stream data chunks
   */
  processStreamData(data, assistantData, thinkingSteps) {
    var _a, _b, _c, _d, _e, _f, _g;
    if (!assistantData) {
      assistantData = {
        messageId: null,
        conversationId: null,
        model: null,
        content: "",
        isComplete: false,
        currentThinkingStep: null,
        createTime: null,
        parentMessageId: null
      };
    }
    if (!thinkingSteps) {
      thinkingSteps = [];
    }
    if (data.type === "message_stream_complete") {
      assistantData.isComplete = true;
      assistantData.conversationId = data.conversation_id || assistantData.conversationId;
      return { assistantData, thinkingSteps };
    }
    if ((_a = data.v) == null ? void 0 : _a.message) {
      assistantData.messageId = data.v.message.id;
      assistantData.conversationId = data.v.conversation_id;
      assistantData.model = ((_b = data.v.message.metadata) == null ? void 0 : _b.model_slug) || null;
      if (data.v.message.create_time) {
        assistantData.createTime = data.v.message.create_time;
      }
      if ((_c = data.v.message.metadata) == null ? void 0 : _c.parent_id) {
        assistantData.parentMessageId = data.v.message.metadata.parent_id;
      }
      const role = (_d = data.v.message.author) == null ? void 0 : _d.role;
      const newStep = {
        id: data.v.message.id,
        role,
        content: "",
        createTime: data.v.message.create_time,
        parentMessageId: (_e = data.v.message.metadata) == null ? void 0 : _e.parent_id,
        initialText: ((_f = data.v.message.metadata) == null ? void 0 : _f.initial_text) || "",
        finishedText: ((_g = data.v.message.metadata) == null ? void 0 : _g.finished_text) || ""
      };
      thinkingSteps.push(newStep);
      assistantData.currentThinkingStep = thinkingSteps.length - 1;
      if (role === "assistant") {
        assistantData.content = "";
      }
      return { assistantData, thinkingSteps };
    }
    if (data.o === "append" && data.p === "/message/content/parts/0" && data.v) {
      if (assistantData.currentThinkingStep !== null && assistantData.currentThinkingStep < thinkingSteps.length) {
        thinkingSteps[assistantData.currentThinkingStep].content += data.v;
        if (thinkingSteps[assistantData.currentThinkingStep].role === "assistant") {
          assistantData.content += data.v;
        }
      }
      return { assistantData, thinkingSteps };
    }
    if (typeof data.v === "string" && !data.o) {
      if (assistantData.currentThinkingStep !== null && assistantData.currentThinkingStep < thinkingSteps.length) {
        thinkingSteps[assistantData.currentThinkingStep].content += data.v;
        if (thinkingSteps[assistantData.currentThinkingStep].role === "assistant") {
          assistantData.content += data.v;
        }
      }
      return { assistantData, thinkingSteps };
    }
    if (data.o === "patch" && Array.isArray(data.v)) {
      for (const patch of data.v) {
        if (patch.p === "/message/metadata/finished_text" && assistantData.currentThinkingStep !== null) {
          thinkingSteps[assistantData.currentThinkingStep].finishedText = patch.v;
        }
        if (patch.p === "/message/content/parts/0" && patch.o === "append" && patch.v) {
          if (assistantData.currentThinkingStep !== null && assistantData.currentThinkingStep < thinkingSteps.length) {
            thinkingSteps[assistantData.currentThinkingStep].content += patch.v;
            if (thinkingSteps[assistantData.currentThinkingStep].role === "assistant") {
              assistantData.content += patch.v;
            }
          }
        }
      }
      if (assistantData.content === "" && thinkingSteps.length > 0) {
        assistantData.content = thinkingSteps[thinkingSteps.length - 1].content;
      }
      return { assistantData, thinkingSteps };
    }
    return { assistantData, thinkingSteps };
  }
}
const chatGptAdapter = new ChatGptAdapter();
class ClaudeAdapter extends BasePlatformAdapter {
  constructor() {
    super(claudeConfig);
  }
  /**
   * Get the current Claude model from the UI
   */
  getModelFromUI() {
    var _a;
    try {
      const modelSelector = document.querySelector('[data-testid="model-selector-dropdown"]');
      if (modelSelector) {
        const modelText = ((_a = modelSelector.textContent) == null ? void 0 : _a.trim()) || "";
        if (modelText.includes("Claude")) {
          const modelMatch = modelText.match(/Claude\s+([\d\.]+\s+\w+)/i);
          if (modelMatch && modelMatch[1]) {
            return `claude-${modelMatch[1].toLowerCase().replace(/\s+/g, "-")}`;
          }
        }
        if (modelText) {
          return modelText.toLowerCase().replace(/\s+/g, "-");
        }
      }
      return "claude";
    } catch (error) {
      console.warn("Failed to detect Claude model from UI:", error);
      return "claude";
    }
  }
  /**
   * Extract user message from request body
   */
  extractUserMessage(requestBody, url) {
    try {
      const content = requestBody.prompt || "";
      const parentMessageProviderId = requestBody.parent_message_uuid || null;
      let conversationId = requestBody.conversation_id || "";
      if (!conversationId && url) {
        const match = url.match(/\/chat_conversations\/([a-f0-9-]+)/);
        if (match && match[1]) {
          conversationId = match[1];
        }
      }
      const model = this.getModelFromUI() || requestBody.model || "claude";
      return {
        messageId: `user-${Date.now()}`,
        // Claude doesn't provide message ID in request
        conversationId,
        content,
        role: "user",
        model,
        timestamp: Date.now(),
        parent_message_provider_id: parentMessageProviderId
      };
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error extracting user message from Claude", ErrorCode.PARSING_ERROR, error)
      );
      return null;
    }
  }
  /**
   * Extract assistant message from response data
   */
  extractAssistantMessage(data) {
    try {
      const model = this.getModelFromUI() || data.model || "claude";
      return {
        messageId: data.messageId || data.uuid || `claude-${Date.now()}`,
        conversationId: data.conversationId || data.chat_id || "",
        content: data.content || data.text || "",
        role: "assistant",
        model,
        timestamp: data.createTime ? data.createTime * 1e3 : Date.now(),
        thinkingTime: data.thinkingTime,
        parent_message_provider_id: data.parentMessageId || data.parent_message_uuid
      };
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error extracting assistant message from Claude", ErrorCode.PARSING_ERROR, error)
      );
      return null;
    }
  }
  /**
   * Extract conversation from response data
   */
  extractConversation(data) {
    try {
      if (!(data == null ? void 0 : data.uuid)) return null;
      return {
        chat_provider_id: data.uuid,
        title: data.name || "Conversation",
        provider_name: "Claude"
      };
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error extracting conversation from Claude", ErrorCode.PARSING_ERROR, error)
      );
      return null;
    }
  }
  /**
   * Extract messages from conversation data
   */
  extractMessagesFromConversation(responseBody) {
    try {
      const messages = [];
      const defaultModel = this.getModelFromUI() || responseBody.model || "claude";
      if (responseBody.chat_messages && Array.isArray(responseBody.chat_messages)) {
        responseBody.chat_messages.forEach((message) => {
          if (!message) return;
          const role = message.sender === "human" ? "user" : message.sender;
          if (role === "user" || role === "assistant") {
            let content = "";
            if (message.content && Array.isArray(message.content)) {
              content = message.content.filter((part) => part.type === "text").map((part) => part.text || "").join("\n");
            } else if (message.text) {
              content = message.text;
            }
            messages.push({
              messageId: message.uuid,
              // Use message UUID
              conversationId: responseBody.uuid,
              // Conversation UUID
              content,
              role,
              model: defaultModel,
              // Use model from UI or response
              timestamp: new Date(message.created_at).getTime(),
              // Convert ISO timestamp to milliseconds
              parent_message_provider_id: message.parent_message_uuid
              // Parent message reference
            });
          }
        });
      }
      return messages.sort((a, b) => {
        var _a, _b;
        const indexA = ((_a = responseBody.chat_messages.find(
          (m) => m.uuid === a.messageId
        )) == null ? void 0 : _a.index) || 0;
        const indexB = ((_b = responseBody.chat_messages.find(
          (m) => m.uuid === b.messageId
        )) == null ? void 0 : _b.index) || 0;
        return indexA - indexB;
      });
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error extracting messages from Claude conversation", ErrorCode.PARSING_ERROR, error)
      );
      return [];
    }
  }
  /**
   * Handle conversation list event
   */
  async handleConversationList(conversationItems) {
    try {
      if (!Array.isArray(conversationItems)) {
        return Promise.resolve();
      }
      const processedChats = conversationItems.map((chat) => ({
        chat_provider_id: chat.uuid,
        title: chat.name || "Unnamed Conversation",
        provider_name: "Claude"
      })).filter(
        (chat) => chat.chat_provider_id && chat.chat_provider_id.trim() !== ""
      );
      if (processedChats.length > 0) {
        await messageApi.saveChatBatch(processedChats);
      }
      return Promise.resolve();
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error handling Claude conversation list", ErrorCode.API_ERROR, error)
      );
      return Promise.resolve();
    }
  }
  /**
   * Handle specific conversation event
   */
  async handleSpecificConversation(responseBody) {
    try {
      if (!(responseBody == null ? void 0 : responseBody.uuid)) {
        console.warn("Missing conversation UUID in Claude response");
        return Promise.resolve();
      }
      const conversation = this.extractConversation(responseBody);
      const messages = this.extractMessagesFromConversation(responseBody);
      if (conversation && messages.length > 0) {
        await messageApi.saveChat(conversation);
        await messageApi.saveMessageBatch(messages.map((msg) => ({
          message_provider_id: msg.messageId,
          chat_provider_id: msg.conversationId,
          content: msg.content,
          role: msg.role,
          model: msg.model || "unknown",
          created_at: msg.timestamp,
          parent_message_provider_id: msg.parent_message_provider_id
        })));
        chatService.setCurrentConversationId(conversation.chat_provider_id);
        document.dispatchEvent(new CustomEvent("jaydai:conversation-loaded", {
          detail: { conversation, messages }
        }));
      }
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error handling Claude specific conversation", ErrorCode.PARSING_ERROR, error)
      );
    }
    return Promise.resolve();
  }
  /**
   * Handle chat completion event
   */
  handleChatCompletion(event) {
    try {
      const { requestBody, url } = event.detail;
      const message = this.extractUserMessage(requestBody, url);
      if (message) {
        document.dispatchEvent(new CustomEvent("jaydai:message-extracted", {
          detail: { message, platform: this.name }
        }));
      }
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error handling Claude chat completion", ErrorCode.PARSING_ERROR, error)
      );
    }
  }
  /**
   * Handle assistant response event
   */
  handleAssistantResponse(event) {
    try {
      const data = event.detail;
      if (!data.messageId || !data.content) return;
      if (data.isComplete) {
        const message = this.extractAssistantMessage(data);
        if (message) {
          document.dispatchEvent(new CustomEvent("jaydai:message-extracted", {
            detail: { message, platform: this.name }
          }));
        }
      }
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error handling Claude assistant response", ErrorCode.PARSING_ERROR, error)
      );
    }
  }
  /**
   * Insert content into Claude's input area
   */
  insertPrompt(content) {
    if (!content) {
      console.error("No content to insert into Claude");
      return false;
    }
    try {
      const inputArea = document.querySelector(this.config.domSelectors.PROMPT_TEXTAREA);
      if (!inputArea) {
        console.error("Could not find Claude input area");
        return false;
      }
      const contentEditableDiv = inputArea.querySelector('[contenteditable="true"]') || inputArea;
      if (!contentEditableDiv) {
        console.error("Could not find contentEditable element in Claude input area");
        return false;
      }
      const normalizedContent = content.replace(/\r\n/g, "\n");
      try {
        contentEditableDiv.focus();
        const paragraphs = normalizedContent.split("\n");
        const htmlContent = paragraphs.map((paragraph) => {
          const escapedParagraph = paragraph.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;");
          return paragraph ? `<p>${escapedParagraph}</p>` : "<p><br></p>";
        }).join("");
        contentEditableDiv.innerHTML = htmlContent;
        contentEditableDiv.dispatchEvent(new Event("input", { bubbles: true }));
        const selection = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(contentEditableDiv);
        range.collapse(false);
        selection == null ? void 0 : selection.removeAllRanges();
        selection == null ? void 0 : selection.addRange(range);
        return true;
      } catch (error) {
        console.warn("Method 1 (innerHTML) failed for Claude:", error);
      }
      try {
        contentEditableDiv.focus();
        contentEditableDiv.innerHTML = "";
        document.execCommand("insertText", false, normalizedContent);
        return true;
      } catch (error) {
        console.warn("Method 2 (execCommand) failed for Claude:", error);
      }
      try {
        contentEditableDiv.focus();
        return navigator.clipboard.writeText(normalizedContent).then(() => {
          document.execCommand("paste");
          console.log("Content pasted via Clipboard API");
          return true;
        }).catch((err) => {
          console.warn("Clipboard API failed for Claude:", err);
          contentEditableDiv.textContent = normalizedContent;
          contentEditableDiv.dispatchEvent(new Event("input", { bubbles: true }));
          return true;
        });
      } catch (error) {
        console.error("All insertion methods failed for Claude:", error);
        return false;
      }
    } catch (error) {
      console.error("Error inserting content into Claude:", error);
      return false;
    }
  }
  /**
   * Check if platform supports streaming
   */
  supportsStreaming() {
    return false;
  }
  /**
   * Process streaming response - not applicable for Claude
   */
  async processStreamingResponse(response, requestBody) {
    console.log("Claude streaming not processed - conversation will be loaded separately");
    return Promise.resolve();
  }
}
const claudeAdapter = new ClaudeAdapter();
class MistralAdapter extends BasePlatformAdapter {
  constructor() {
    super(mistralConfig);
  }
  extractUserMessage(requestBody) {
    try {
      const content = requestBody.messageInput || "";
      return {
        messageId: requestBody.messageId || `user-${Date.now()}`,
        conversationId: requestBody.chatId || "",
        content,
        role: "user",
        model: requestBody.model || "mistral",
        timestamp: Date.now(),
        parent_message_provider_id: requestBody.parentMessageId
      };
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error extracting user message from Mistral", ErrorCode.PARSING_ERROR, error)
      );
      return null;
    }
  }
  extractAssistantMessage(data) {
    try {
      return {
        messageId: data.messageId || `mistral-${Date.now()}`,
        conversationId: data.chatId || "",
        content: data.content || "",
        role: "assistant",
        model: data.model || "mistral",
        timestamp: Date.now(),
        thinkingTime: data.thinkingTime,
        parent_message_provider_id: data.parentMessageId
      };
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error extracting assistant message from Mistral", ErrorCode.PARSING_ERROR, error)
      );
      return null;
    }
  }
  extractConversation(data) {
    try {
      if (!(data == null ? void 0 : data.chatId)) return null;
      return {
        chat_provider_id: data.chatId,
        title: data.title || "Conversation",
        provider_name: "Mistral"
      };
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error extracting conversation from Mistral", ErrorCode.PARSING_ERROR, error)
      );
      return null;
    }
  }
  extractMessagesFromConversation(_data) {
    return [];
  }
  async handleConversationList(_data) {
    return Promise.resolve();
  }
  async handleSpecificConversation(_data) {
    return Promise.resolve();
  }
  handleChatCompletion(event) {
    try {
      const { requestBody } = event.detail;
      const message = this.extractUserMessage(requestBody);
      if (message) {
        document.dispatchEvent(
          new CustomEvent("jaydai:message-extracted", { detail: { message, platform: this.name } })
        );
      }
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error handling chat completion", ErrorCode.PARSING_ERROR, error)
      );
    }
  }
  handleAssistantResponse(event) {
    try {
      const data = event.detail;
      if (!data) return;
      if (data.isComplete) {
        const message = this.extractAssistantMessage(data);
        if (message) {
          document.dispatchEvent(
            new CustomEvent("jaydai:message-extracted", { detail: { message, platform: this.name } })
          );
        }
      }
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error handling assistant response", ErrorCode.PARSING_ERROR, error)
      );
    }
  }
  insertPrompt(content) {
    if (!content) return false;
    try {
      const textarea = document.querySelector(this.config.domSelectors.PROMPT_TEXTAREA);
      if (!textarea) return false;
      textarea.value = content;
      textarea.dispatchEvent(new Event("input", { bubbles: true }));
      textarea.focus();
      textarea.selectionStart = textarea.selectionEnd = content.length;
      return true;
    } catch (error) {
      console.error("Error inserting prompt in Mistral:", error);
      return false;
    }
  }
  supportsStreaming() {
    return true;
  }
  async processStreamingResponse(response, requestBody) {
    if (!response.body) return;
    const reader = response.clone().body.getReader();
    const decoder = new TextDecoder();
    let buffer2 = "";
    let messageId = "";
    let content = "";
    const conversationId = requestBody.chatId || "";
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer2 += decoder.decode(value, { stream: true });
        let index;
        while ((index = buffer2.indexOf("\n")) !== -1) {
          const line = buffer2.slice(0, index).trim();
          buffer2 = buffer2.slice(index + 1);
          if (!line) continue;
          if (line.startsWith("data:")) {
            const dataStr = line.slice(5).trim();
            if (dataStr === "[DONE]") {
              if (messageId && content) {
                document.dispatchEvent(
                  new CustomEvent("jaydai:assistant-response", {
                    detail: {
                      messageId,
                      conversationId,
                      content,
                      role: "assistant",
                      model: "mistral",
                      isComplete: true,
                      platform: this.name
                    }
                  })
                );
              }
              continue;
            }
            try {
              const data = JSON.parse(dataStr);
              if (data.messageId) messageId = data.messageId;
              if (data.token) content += data.token;
              if (data.content) content += data.content;
            } catch (_) {
              content += dataStr;
            }
          }
        }
      }
      if (messageId && content) {
        document.dispatchEvent(
          new CustomEvent("jaydai:assistant-response", {
            detail: {
              messageId,
              conversationId,
              content,
              role: "assistant",
              model: "mistral",
              isComplete: true,
              platform: this.name
            }
          })
        );
      }
    } catch (error) {
      console.error("Error processing Mistral stream:", error);
    }
  }
}
const mistralAdapter = new MistralAdapter();
class CopilotAdapter extends BasePlatformAdapter {
  constructor() {
    super(copilotConfig);
  }
  extractUserMessage(_data) {
    return null;
  }
  extractAssistantMessage(_data) {
    return null;
  }
  extractConversation(data) {
    var _a;
    if (!(data == null ? void 0 : data.results)) return null;
    return { chat_provider_id: chatService.getCurrentConversationId() || "", title: ((_a = data.results[0]) == null ? void 0 : _a.title) || "Conversation", provider_name: "Copilot" };
  }
  extractMessagesFromConversation(data) {
    if (!(data == null ? void 0 : data.results)) return [];
    return data.results.map((m) => {
      var _a;
      return {
        messageId: m.id,
        conversationId: chatService.getCurrentConversationId() || "",
        content: Array.isArray(m.content) ? m.content.map((c) => c.text).join("\n") : ((_a = m.content) == null ? void 0 : _a.text) || "",
        role: m.author === "human" ? "user" : "assistant",
        model: "copilot",
        timestamp: new Date(m.createdAt).getTime(),
        parent_message_provider_id: null
      };
    });
  }
  async handleConversationList(responseBody) {
    if (!(responseBody == null ? void 0 : responseBody.results)) return Promise.resolve();
    const chats = responseBody.results.filter((c) => c.type === "chat").map((c) => ({ chat_provider_id: c.id, title: c.title || "Conversation", provider_name: "Copilot" }));
    if (chats.length) await messageApi.saveChatBatch(chats);
    return Promise.resolve();
  }
  async handleSpecificConversation(responseBody) {
    const conversation = this.extractConversation(responseBody);
    const messages = this.extractMessagesFromConversation(responseBody);
    if (conversation) await messageApi.saveChat(conversation);
    if (messages.length) {
      await messageApi.saveMessageBatch(messages.map((m) => ({
        message_provider_id: m.messageId,
        chat_provider_id: m.conversationId,
        content: m.content,
        role: m.role,
        model: m.model,
        created_at: m.timestamp,
        parent_message_provider_id: m.parent_message_provider_id
      })));
    }
    if (conversation) {
      chatService.setCurrentConversationId(conversation.chat_provider_id);
      document.dispatchEvent(new CustomEvent("jaydai:conversation-loaded", { detail: { conversation, messages } }));
    }
    return Promise.resolve();
  }
  handleChatCompletion(_event) {
  }
  handleAssistantResponse(_event) {
  }
  insertPrompt(content) {
    const textarea = document.querySelector(this.config.domSelectors.PROMPT_TEXTAREA);
    if (!textarea || !content) return false;
    textarea.value = content;
    textarea.dispatchEvent(new Event("input", { bubbles: true }));
    textarea.focus();
    textarea.selectionStart = textarea.selectionEnd = content.length;
    return true;
  }
  supportsStreaming() {
    return false;
  }
  async processStreamingResponse(_response, _body) {
    return Promise.resolve();
  }
}
const copilotAdapter = new CopilotAdapter();
const adapters = [
  chatGptAdapter,
  claudeAdapter,
  mistralAdapter,
  copilotAdapter
];
function getAdapterByName(name) {
  return adapters.find((adapter) => adapter.name === name) || null;
}
function getAdapterByHostname(hostname) {
  return adapters.find(
    (adapter) => adapter.config.hostnames.some((h) => hostname.includes(h))
  ) || null;
}
function detectPlatform() {
  const hostname = window.location.hostname;
  const adapter = getAdapterByHostname(hostname);
  return adapter ? adapter.name : "unknown";
}
function handleConversationList(event) {
  const platform = event.detail.platform;
  const responseBody = event.detail.responseBody;
  const adapter = getAdapterByName(platform);
  if (adapter) {
    return adapter.handleConversationList(responseBody);
  }
  return Promise.resolve();
}
function handleSpecificConversation(event) {
  const platform = event.detail.platform;
  const responseBody = event.detail.responseBody;
  const adapter = getAdapterByName(platform);
  if (adapter) {
    return adapter.handleSpecificConversation(responseBody);
  }
  return Promise.resolve();
}
function handleChatCompletion(event) {
  const platform = event.detail.platform;
  const adapter = getAdapterByName(platform);
  if (adapter) {
    adapter.handleChatCompletion(event);
  }
}
function handleAssistantResponse(event) {
  const platform = event.detail.platform;
  const adapter = getAdapterByName(platform);
  if (adapter) {
    adapter.handleAssistantResponse(event);
  }
}
const initAmplitude = (userId, autoCapture = true) => {
  init("857a9c3b48322cbc7802683533e50155", {
    // Enable autocapture for automatic event tracking
    autocapture: {
      elementInteractions: autoCapture
    }
  });
  if (userId) {
    setUserId(userId);
  }
};
const setAmplitudeUserId = (userId) => {
  if (userId) {
    setUserId(userId);
  }
};
const trackEvent = (eventName, eventProperties = {}) => {
  const platform = detectPlatform();
  track(eventName, { ...eventProperties, "ai_platform": platform });
};
const EVENTS = {
  // Extension lifecycle events
  EXTENSION_INSTALLED: "Extension Installed",
  EXTENSION_OPENED: "Extension Opened",
  BUTTON_INJECTED: "Button Injected",
  BUTTON_CLICKED: "Button Clicked",
  MAIN_BUTTON_CLICKED: "Main Button Clicked",
  // Authentication events
  SIGNIN_STARTED: "Sign In Started",
  SIGNIN_COMPLETED: "Sign In Completed",
  SIGNIN_FAILED: "Sign In Failed",
  SIGNUP_STARTED: "Sign Up Started",
  SIGNUP_COMPLETED: "Sign Up Completed",
  SIGNUP_FAILED: "Sign Up Failed",
  GOOGLE_AUTH_STARTED: "Google Auth Started",
  GOOGLE_AUTH_COMPLETED: "Google Auth Completed",
  GOOGLE_AUTH_FAILED: "Google Auth Failed",
  SIGNOUT: "Sign Out",
  // Menu events
  MENU_ITEM_CLICKED: "Menu Item Clicked",
  // Template events
  TEMPLATE_USE: "Template Used",
  TEMPLATE_USE_ERROR: "Template Use Error",
  // Onboarding events
  ONBOARDING_STARTED: "Onboarding Started",
  ONBOARDING_STEP_VIEWED: "Onboarding Step Viewed",
  ONBOARDING_STEP_COMPLETED: "Onboarding Step Completed",
  ONBOARDING_COMPLETED: "Onboarding Completed",
  ONBOARDING_SKIPPED: "Onboarding Skipped",
  ONBOARDING_ERROR: "Onboarding Error",
  ONBOARDING_GOTO_CHATGPT: "Onboarding Go To ChatGPT",
  // Template events
  TEMPLATE_VIEWED: "Template Viewed",
  TEMPLATE_SELECTED: "Template Selected",
  TEMPLATE_MODIFIED: "Template Modified",
  TEMPLATE_APPLIED: "Template Applied",
  TEMPLATE_APPLIED_ERROR: "Template Apply Error",
  TEMPLATE_USED: "Template Used",
  TEMPLATE_USED_ERROR: "Template Use Error",
  TEMPLATE_FOLDER_OPENED: "Template Folder Opened",
  TEMPLATE_SEARCH: "Template Search",
  TEMPLATE_CREATE: "Template Created",
  TEMPLATE_CREATE_ERROR: "Template Create Error",
  TEMPLATE_DELETE: "Template Deleted",
  TEMPLATE_DELETE_FOLDER: "Template Folder Deleted",
  TEMPLATE_EDIT: "Template Edited",
  TEMPLATE_BROWSE_OFFICIAL: "Template Browse Official",
  TEMPLATE_BROWSE_ORGANIZATION: "Template Browse Organization",
  TEMPLATE_REFRESH: "Template Refresh",
  TEMPLATE_FOLDER_CREATED: "Template Folder Created",
  TEMPLATE_EDIT_DIALOG_OPENED: "Template Edit Dialog Opened",
  PLACEHOLDER_EDITOR_OPENED: "Placeholder Editor Opened",
  // Settings events
  SETTINGS_OPENED: "Settings Opened",
  SETTINGS_CHANGED: "Settings Changed",
  // Network interceptor events
  NETWORK_INTERCEPTOR_STARTED: "Network Interceptor Started",
  NETWORK_INTERCEPTOR_CAPTURED: "Network Interceptor Captured",
  NETWORK_INTERCEPTOR_ERROR: "Network Interceptor Error",
  // Usage statistics events
  USAGE_STATISTICS_VIEWED: "Usage Statistics Viewed",
  CONVERSATION_CAPTURED: "Conversation Captured",
  CONVERSATION_ANALYZED: "Conversation Analyzed"
};
const setUserProperties = (properties) => {
  const identify$1 = new Identify();
  Object.entries(properties).forEach(([key, value]) => {
    identify$1.set(key, value);
  });
  identify(identify$1);
};
const incrementUserProperty = (property, value = 1) => {
  const identify$1 = new Identify();
  identify$1.add(property, value);
  identify(identify$1);
};
var AUTOFOCUS_ON_MOUNT = "focusScope.autoFocusOnMount";
var AUTOFOCUS_ON_UNMOUNT = "focusScope.autoFocusOnUnmount";
var EVENT_OPTIONS$1 = { bubbles: false, cancelable: true };
var FOCUS_SCOPE_NAME = "FocusScope";
var FocusScope = reactExports.forwardRef((props, forwardedRef) => {
  const {
    loop = false,
    trapped = false,
    onMountAutoFocus: onMountAutoFocusProp,
    onUnmountAutoFocus: onUnmountAutoFocusProp,
    ...scopeProps
  } = props;
  const [container, setContainer] = reactExports.useState(null);
  const onMountAutoFocus = useCallbackRef$1(onMountAutoFocusProp);
  const onUnmountAutoFocus = useCallbackRef$1(onUnmountAutoFocusProp);
  const lastFocusedElementRef = reactExports.useRef(null);
  const composedRefs = useComposedRefs(forwardedRef, (node) => setContainer(node));
  const focusScope = reactExports.useRef({
    paused: false,
    pause() {
      this.paused = true;
    },
    resume() {
      this.paused = false;
    }
  }).current;
  reactExports.useEffect(() => {
    if (trapped) {
      let handleFocusIn2 = function(event) {
        if (focusScope.paused || !container) return;
        const target = event.target;
        if (container.contains(target)) {
          lastFocusedElementRef.current = target;
        } else {
          focus(lastFocusedElementRef.current, { select: true });
        }
      }, handleFocusOut2 = function(event) {
        if (focusScope.paused || !container) return;
        const relatedTarget = event.relatedTarget;
        if (relatedTarget === null) return;
        if (!container.contains(relatedTarget)) {
          focus(lastFocusedElementRef.current, { select: true });
        }
      }, handleMutations2 = function(mutations) {
        const focusedElement = document.activeElement;
        if (focusedElement !== document.body) return;
        for (const mutation of mutations) {
          if (mutation.removedNodes.length > 0) focus(container);
        }
      };
      document.addEventListener("focusin", handleFocusIn2);
      document.addEventListener("focusout", handleFocusOut2);
      const mutationObserver = new MutationObserver(handleMutations2);
      if (container) mutationObserver.observe(container, { childList: true, subtree: true });
      return () => {
        document.removeEventListener("focusin", handleFocusIn2);
        document.removeEventListener("focusout", handleFocusOut2);
        mutationObserver.disconnect();
      };
    }
  }, [trapped, container, focusScope.paused]);
  reactExports.useEffect(() => {
    if (container) {
      focusScopesStack.add(focusScope);
      const previouslyFocusedElement = document.activeElement;
      const hasFocusedCandidate = container.contains(previouslyFocusedElement);
      if (!hasFocusedCandidate) {
        const mountEvent = new CustomEvent(AUTOFOCUS_ON_MOUNT, EVENT_OPTIONS$1);
        container.addEventListener(AUTOFOCUS_ON_MOUNT, onMountAutoFocus);
        container.dispatchEvent(mountEvent);
        if (!mountEvent.defaultPrevented) {
          focusFirst$1(removeLinks(getTabbableCandidates(container)), { select: true });
          if (document.activeElement === previouslyFocusedElement) {
            focus(container);
          }
        }
      }
      return () => {
        container.removeEventListener(AUTOFOCUS_ON_MOUNT, onMountAutoFocus);
        setTimeout(() => {
          const unmountEvent = new CustomEvent(AUTOFOCUS_ON_UNMOUNT, EVENT_OPTIONS$1);
          container.addEventListener(AUTOFOCUS_ON_UNMOUNT, onUnmountAutoFocus);
          container.dispatchEvent(unmountEvent);
          if (!unmountEvent.defaultPrevented) {
            focus(previouslyFocusedElement ?? document.body, { select: true });
          }
          container.removeEventListener(AUTOFOCUS_ON_UNMOUNT, onUnmountAutoFocus);
          focusScopesStack.remove(focusScope);
        }, 0);
      };
    }
  }, [container, onMountAutoFocus, onUnmountAutoFocus, focusScope]);
  const handleKeyDown = reactExports.useCallback(
    (event) => {
      if (!loop && !trapped) return;
      if (focusScope.paused) return;
      const isTabKey = event.key === "Tab" && !event.altKey && !event.ctrlKey && !event.metaKey;
      const focusedElement = document.activeElement;
      if (isTabKey && focusedElement) {
        const container2 = event.currentTarget;
        const [first, last2] = getTabbableEdges(container2);
        const hasTabbableElementsInside = first && last2;
        if (!hasTabbableElementsInside) {
          if (focusedElement === container2) event.preventDefault();
        } else {
          if (!event.shiftKey && focusedElement === last2) {
            event.preventDefault();
            if (loop) focus(first, { select: true });
          } else if (event.shiftKey && focusedElement === first) {
            event.preventDefault();
            if (loop) focus(last2, { select: true });
          }
        }
      }
    },
    [loop, trapped, focusScope.paused]
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Primitive.div, { tabIndex: -1, ...scopeProps, ref: composedRefs, onKeyDown: handleKeyDown });
});
FocusScope.displayName = FOCUS_SCOPE_NAME;
function focusFirst$1(candidates, { select = false } = {}) {
  const previouslyFocusedElement = document.activeElement;
  for (const candidate of candidates) {
    focus(candidate, { select });
    if (document.activeElement !== previouslyFocusedElement) return;
  }
}
function getTabbableEdges(container) {
  const candidates = getTabbableCandidates(container);
  const first = findVisible(candidates, container);
  const last2 = findVisible(candidates.reverse(), container);
  return [first, last2];
}
function getTabbableCandidates(container) {
  const nodes = [];
  const walker = document.createTreeWalker(container, NodeFilter.SHOW_ELEMENT, {
    acceptNode: (node) => {
      const isHiddenInput = node.tagName === "INPUT" && node.type === "hidden";
      if (node.disabled || node.hidden || isHiddenInput) return NodeFilter.FILTER_SKIP;
      return node.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
    }
  });
  while (walker.nextNode()) nodes.push(walker.currentNode);
  return nodes;
}
function findVisible(elements, container) {
  for (const element of elements) {
    if (!isHidden(element, { upTo: container })) return element;
  }
}
function isHidden(node, { upTo }) {
  if (getComputedStyle(node).visibility === "hidden") return true;
  while (node) {
    if (upTo !== void 0 && node === upTo) return false;
    if (getComputedStyle(node).display === "none") return true;
    node = node.parentElement;
  }
  return false;
}
function isSelectableInput(element) {
  return element instanceof HTMLInputElement && "select" in element;
}
function focus(element, { select = false } = {}) {
  if (element && element.focus) {
    const previouslyFocusedElement = document.activeElement;
    element.focus({ preventScroll: true });
    if (element !== previouslyFocusedElement && isSelectableInput(element) && select)
      element.select();
  }
}
var focusScopesStack = createFocusScopesStack();
function createFocusScopesStack() {
  let stack = [];
  return {
    add(focusScope) {
      const activeFocusScope = stack[0];
      if (focusScope !== activeFocusScope) {
        activeFocusScope == null ? void 0 : activeFocusScope.pause();
      }
      stack = arrayRemove(stack, focusScope);
      stack.unshift(focusScope);
    },
    remove(focusScope) {
      var _a;
      stack = arrayRemove(stack, focusScope);
      (_a = stack[0]) == null ? void 0 : _a.resume();
    }
  };
}
function arrayRemove(array, item) {
  const updatedArray = [...array];
  const index = updatedArray.indexOf(item);
  if (index !== -1) {
    updatedArray.splice(index, 1);
  }
  return updatedArray;
}
function removeLinks(items) {
  return items.filter((item) => item.tagName !== "A");
}
var count = 0;
function useFocusGuards() {
  reactExports.useEffect(() => {
    const edgeGuards = document.querySelectorAll("[data-radix-focus-guard]");
    document.body.insertAdjacentElement("afterbegin", edgeGuards[0] ?? createFocusGuard());
    document.body.insertAdjacentElement("beforeend", edgeGuards[1] ?? createFocusGuard());
    count++;
    return () => {
      if (count === 1) {
        document.querySelectorAll("[data-radix-focus-guard]").forEach((node) => node.remove());
      }
      count--;
    };
  }, []);
}
function createFocusGuard() {
  const element = document.createElement("span");
  element.setAttribute("data-radix-focus-guard", "");
  element.tabIndex = 0;
  element.style.outline = "none";
  element.style.opacity = "0";
  element.style.position = "fixed";
  element.style.pointerEvents = "none";
  return element;
}
var zeroRightClassName = "right-scroll-bar-position";
var fullWidthClassName = "width-before-scroll-bar";
var noScrollbarsClassName = "with-scroll-bars-hidden";
var removedBarSizeVariable = "--removed-body-scroll-bar-size";
function assignRef(ref, value) {
  if (typeof ref === "function") {
    ref(value);
  } else if (ref) {
    ref.current = value;
  }
  return ref;
}
function useCallbackRef(initialValue, callback) {
  var ref = reactExports.useState(function() {
    return {
      // value
      value: initialValue,
      // last callback
      callback,
      // "memoized" public interface
      facade: {
        get current() {
          return ref.value;
        },
        set current(value) {
          var last2 = ref.value;
          if (last2 !== value) {
            ref.value = value;
            ref.callback(value, last2);
          }
        }
      }
    };
  })[0];
  ref.callback = callback;
  return ref.facade;
}
var useIsomorphicLayoutEffect = typeof window !== "undefined" ? reactExports.useLayoutEffect : reactExports.useEffect;
var currentValues = /* @__PURE__ */ new WeakMap();
function useMergeRefs(refs, defaultValue) {
  var callbackRef = useCallbackRef(null, function(newValue) {
    return refs.forEach(function(ref) {
      return assignRef(ref, newValue);
    });
  });
  useIsomorphicLayoutEffect(function() {
    var oldValue = currentValues.get(callbackRef);
    if (oldValue) {
      var prevRefs_1 = new Set(oldValue);
      var nextRefs_1 = new Set(refs);
      var current_1 = callbackRef.current;
      prevRefs_1.forEach(function(ref) {
        if (!nextRefs_1.has(ref)) {
          assignRef(ref, null);
        }
      });
      nextRefs_1.forEach(function(ref) {
        if (!prevRefs_1.has(ref)) {
          assignRef(ref, current_1);
        }
      });
    }
    currentValues.set(callbackRef, refs);
  }, [refs]);
  return callbackRef;
}
function ItoI(a) {
  return a;
}
function innerCreateMedium(defaults, middleware) {
  if (middleware === void 0) {
    middleware = ItoI;
  }
  var buffer2 = [];
  var assigned = false;
  var medium = {
    read: function() {
      if (assigned) {
        throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
      }
      if (buffer2.length) {
        return buffer2[buffer2.length - 1];
      }
      return defaults;
    },
    useMedium: function(data) {
      var item = middleware(data, assigned);
      buffer2.push(item);
      return function() {
        buffer2 = buffer2.filter(function(x) {
          return x !== item;
        });
      };
    },
    assignSyncMedium: function(cb) {
      assigned = true;
      while (buffer2.length) {
        var cbs = buffer2;
        buffer2 = [];
        cbs.forEach(cb);
      }
      buffer2 = {
        push: function(x) {
          return cb(x);
        },
        filter: function() {
          return buffer2;
        }
      };
    },
    assignMedium: function(cb) {
      assigned = true;
      var pendingQueue = [];
      if (buffer2.length) {
        var cbs = buffer2;
        buffer2 = [];
        cbs.forEach(cb);
        pendingQueue = buffer2;
      }
      var executeQueue = function() {
        var cbs2 = pendingQueue;
        pendingQueue = [];
        cbs2.forEach(cb);
      };
      var cycle = function() {
        return Promise.resolve().then(executeQueue);
      };
      cycle();
      buffer2 = {
        push: function(x) {
          pendingQueue.push(x);
          cycle();
        },
        filter: function(filter2) {
          pendingQueue = pendingQueue.filter(filter2);
          return buffer2;
        }
      };
    }
  };
  return medium;
}
function createSidecarMedium(options) {
  if (options === void 0) {
    options = {};
  }
  var medium = innerCreateMedium(null);
  medium.options = __assign$1({ async: true, ssr: false }, options);
  return medium;
}
var SideCar$1 = function(_a) {
  var sideCar = _a.sideCar, rest = __rest(_a, ["sideCar"]);
  if (!sideCar) {
    throw new Error("Sidecar: please provide `sideCar` property to import the right car");
  }
  var Target2 = sideCar.read();
  if (!Target2) {
    throw new Error("Sidecar medium not found");
  }
  return reactExports.createElement(Target2, __assign$1({}, rest));
};
SideCar$1.isSideCarExport = true;
function exportSidecar(medium, exported) {
  medium.useMedium(exported);
  return SideCar$1;
}
var effectCar = createSidecarMedium();
var nothing = function() {
  return;
};
var RemoveScroll = reactExports.forwardRef(function(props, parentRef) {
  var ref = reactExports.useRef(null);
  var _a = reactExports.useState({
    onScrollCapture: nothing,
    onWheelCapture: nothing,
    onTouchMoveCapture: nothing
  }), callbacks = _a[0], setCallbacks = _a[1];
  var forwardProps = props.forwardProps, children = props.children, className = props.className, removeScrollBar = props.removeScrollBar, enabled = props.enabled, shards = props.shards, sideCar = props.sideCar, noRelative = props.noRelative, noIsolation = props.noIsolation, inert = props.inert, allowPinchZoom = props.allowPinchZoom, _b = props.as, Container = _b === void 0 ? "div" : _b, gapMode = props.gapMode, rest = __rest(props, ["forwardProps", "children", "className", "removeScrollBar", "enabled", "shards", "sideCar", "noRelative", "noIsolation", "inert", "allowPinchZoom", "as", "gapMode"]);
  var SideCar2 = sideCar;
  var containerRef = useMergeRefs([ref, parentRef]);
  var containerProps = __assign$1(__assign$1({}, rest), callbacks);
  return reactExports.createElement(
    reactExports.Fragment,
    null,
    enabled && reactExports.createElement(SideCar2, { sideCar: effectCar, removeScrollBar, shards, noRelative, noIsolation, inert, setCallbacks, allowPinchZoom: !!allowPinchZoom, lockRef: ref, gapMode }),
    forwardProps ? reactExports.cloneElement(reactExports.Children.only(children), __assign$1(__assign$1({}, containerProps), { ref: containerRef })) : reactExports.createElement(Container, __assign$1({}, containerProps, { className, ref: containerRef }), children)
  );
});
RemoveScroll.defaultProps = {
  enabled: true,
  removeScrollBar: true,
  inert: false
};
RemoveScroll.classNames = {
  fullWidth: fullWidthClassName,
  zeroRight: zeroRightClassName
};
var getNonce = function() {
  if (typeof __webpack_nonce__ !== "undefined") {
    return __webpack_nonce__;
  }
  return void 0;
};
function makeStyleTag() {
  if (!document)
    return null;
  var tag = document.createElement("style");
  tag.type = "text/css";
  var nonce = getNonce();
  if (nonce) {
    tag.setAttribute("nonce", nonce);
  }
  return tag;
}
function injectStyles(tag, css) {
  if (tag.styleSheet) {
    tag.styleSheet.cssText = css;
  } else {
    tag.appendChild(document.createTextNode(css));
  }
}
function insertStyleTag(tag) {
  var head = document.head || document.getElementsByTagName("head")[0];
  head.appendChild(tag);
}
var stylesheetSingleton = function() {
  var counter = 0;
  var stylesheet = null;
  return {
    add: function(style) {
      if (counter == 0) {
        if (stylesheet = makeStyleTag()) {
          injectStyles(stylesheet, style);
          insertStyleTag(stylesheet);
        }
      }
      counter++;
    },
    remove: function() {
      counter--;
      if (!counter && stylesheet) {
        stylesheet.parentNode && stylesheet.parentNode.removeChild(stylesheet);
        stylesheet = null;
      }
    }
  };
};
var styleHookSingleton = function() {
  var sheet = stylesheetSingleton();
  return function(styles, isDynamic) {
    reactExports.useEffect(function() {
      sheet.add(styles);
      return function() {
        sheet.remove();
      };
    }, [styles && isDynamic]);
  };
};
var styleSingleton = function() {
  var useStyle = styleHookSingleton();
  var Sheet = function(_a) {
    var styles = _a.styles, dynamic = _a.dynamic;
    useStyle(styles, dynamic);
    return null;
  };
  return Sheet;
};
var zeroGap = {
  left: 0,
  top: 0,
  right: 0,
  gap: 0
};
var parse = function(x) {
  return parseInt(x || "", 10) || 0;
};
var getOffset = function(gapMode) {
  var cs = window.getComputedStyle(document.body);
  var left = cs[gapMode === "padding" ? "paddingLeft" : "marginLeft"];
  var top = cs[gapMode === "padding" ? "paddingTop" : "marginTop"];
  var right = cs[gapMode === "padding" ? "paddingRight" : "marginRight"];
  return [parse(left), parse(top), parse(right)];
};
var getGapWidth = function(gapMode) {
  if (gapMode === void 0) {
    gapMode = "margin";
  }
  if (typeof window === "undefined") {
    return zeroGap;
  }
  var offsets = getOffset(gapMode);
  var documentWidth = document.documentElement.clientWidth;
  var windowWidth = window.innerWidth;
  return {
    left: offsets[0],
    top: offsets[1],
    right: offsets[2],
    gap: Math.max(0, windowWidth - documentWidth + offsets[2] - offsets[0])
  };
};
var Style = styleSingleton();
var lockAttribute = "data-scroll-locked";
var getStyles = function(_a, allowRelative, gapMode, important) {
  var left = _a.left, top = _a.top, right = _a.right, gap = _a.gap;
  if (gapMode === void 0) {
    gapMode = "margin";
  }
  return "\n  .".concat(noScrollbarsClassName, " {\n   overflow: hidden ").concat(important, ";\n   padding-right: ").concat(gap, "px ").concat(important, ";\n  }\n  body[").concat(lockAttribute, "] {\n    overflow: hidden ").concat(important, ";\n    overscroll-behavior: contain;\n    ").concat([
    allowRelative && "position: relative ".concat(important, ";"),
    gapMode === "margin" && "\n    padding-left: ".concat(left, "px;\n    padding-top: ").concat(top, "px;\n    padding-right: ").concat(right, "px;\n    margin-left:0;\n    margin-top:0;\n    margin-right: ").concat(gap, "px ").concat(important, ";\n    "),
    gapMode === "padding" && "padding-right: ".concat(gap, "px ").concat(important, ";")
  ].filter(Boolean).join(""), "\n  }\n  \n  .").concat(zeroRightClassName, " {\n    right: ").concat(gap, "px ").concat(important, ";\n  }\n  \n  .").concat(fullWidthClassName, " {\n    margin-right: ").concat(gap, "px ").concat(important, ";\n  }\n  \n  .").concat(zeroRightClassName, " .").concat(zeroRightClassName, " {\n    right: 0 ").concat(important, ";\n  }\n  \n  .").concat(fullWidthClassName, " .").concat(fullWidthClassName, " {\n    margin-right: 0 ").concat(important, ";\n  }\n  \n  body[").concat(lockAttribute, "] {\n    ").concat(removedBarSizeVariable, ": ").concat(gap, "px;\n  }\n");
};
var getCurrentUseCounter = function() {
  var counter = parseInt(document.body.getAttribute(lockAttribute) || "0", 10);
  return isFinite(counter) ? counter : 0;
};
var useLockAttribute = function() {
  reactExports.useEffect(function() {
    document.body.setAttribute(lockAttribute, (getCurrentUseCounter() + 1).toString());
    return function() {
      var newCounter = getCurrentUseCounter() - 1;
      if (newCounter <= 0) {
        document.body.removeAttribute(lockAttribute);
      } else {
        document.body.setAttribute(lockAttribute, newCounter.toString());
      }
    };
  }, []);
};
var RemoveScrollBar = function(_a) {
  var noRelative = _a.noRelative, noImportant = _a.noImportant, _b = _a.gapMode, gapMode = _b === void 0 ? "margin" : _b;
  useLockAttribute();
  var gap = reactExports.useMemo(function() {
    return getGapWidth(gapMode);
  }, [gapMode]);
  return reactExports.createElement(Style, { styles: getStyles(gap, !noRelative, gapMode, !noImportant ? "!important" : "") });
};
var passiveSupported = false;
if (typeof window !== "undefined") {
  try {
    var options = Object.defineProperty({}, "passive", {
      get: function() {
        passiveSupported = true;
        return true;
      }
    });
    window.addEventListener("test", options, options);
    window.removeEventListener("test", options, options);
  } catch (err) {
    passiveSupported = false;
  }
}
var nonPassive = passiveSupported ? { passive: false } : false;
var alwaysContainsScroll = function(node) {
  return node.tagName === "TEXTAREA";
};
var elementCanBeScrolled = function(node, overflow) {
  if (!(node instanceof Element)) {
    return false;
  }
  var styles = window.getComputedStyle(node);
  return (
    // not-not-scrollable
    styles[overflow] !== "hidden" && // contains scroll inside self
    !(styles.overflowY === styles.overflowX && !alwaysContainsScroll(node) && styles[overflow] === "visible")
  );
};
var elementCouldBeVScrolled = function(node) {
  return elementCanBeScrolled(node, "overflowY");
};
var elementCouldBeHScrolled = function(node) {
  return elementCanBeScrolled(node, "overflowX");
};
var locationCouldBeScrolled = function(axis, node) {
  var ownerDocument = node.ownerDocument;
  var current = node;
  do {
    if (typeof ShadowRoot !== "undefined" && current instanceof ShadowRoot) {
      current = current.host;
    }
    var isScrollable = elementCouldBeScrolled(axis, current);
    if (isScrollable) {
      var _a = getScrollVariables(axis, current), scrollHeight = _a[1], clientHeight = _a[2];
      if (scrollHeight > clientHeight) {
        return true;
      }
    }
    current = current.parentNode;
  } while (current && current !== ownerDocument.body);
  return false;
};
var getVScrollVariables = function(_a) {
  var scrollTop = _a.scrollTop, scrollHeight = _a.scrollHeight, clientHeight = _a.clientHeight;
  return [
    scrollTop,
    scrollHeight,
    clientHeight
  ];
};
var getHScrollVariables = function(_a) {
  var scrollLeft = _a.scrollLeft, scrollWidth = _a.scrollWidth, clientWidth = _a.clientWidth;
  return [
    scrollLeft,
    scrollWidth,
    clientWidth
  ];
};
var elementCouldBeScrolled = function(axis, node) {
  return axis === "v" ? elementCouldBeVScrolled(node) : elementCouldBeHScrolled(node);
};
var getScrollVariables = function(axis, node) {
  return axis === "v" ? getVScrollVariables(node) : getHScrollVariables(node);
};
var getDirectionFactor = function(axis, direction) {
  return axis === "h" && direction === "rtl" ? -1 : 1;
};
var handleScroll = function(axis, endTarget, event, sourceDelta, noOverscroll) {
  var directionFactor = getDirectionFactor(axis, window.getComputedStyle(endTarget).direction);
  var delta = directionFactor * sourceDelta;
  var target = event.target;
  var targetInLock = endTarget.contains(target);
  var shouldCancelScroll = false;
  var isDeltaPositive = delta > 0;
  var availableScroll = 0;
  var availableScrollTop = 0;
  do {
    var _a = getScrollVariables(axis, target), position = _a[0], scroll_1 = _a[1], capacity = _a[2];
    var elementScroll = scroll_1 - capacity - directionFactor * position;
    if (position || elementScroll) {
      if (elementCouldBeScrolled(axis, target)) {
        availableScroll += elementScroll;
        availableScrollTop += position;
      }
    }
    target = target.parentNode.host || target.parentNode;
  } while (
    // portaled content
    !targetInLock && target !== document.body || // self content
    targetInLock && (endTarget.contains(target) || endTarget === target)
  );
  if (isDeltaPositive && (Math.abs(availableScroll) < 1 || false)) {
    shouldCancelScroll = true;
  } else if (!isDeltaPositive && (Math.abs(availableScrollTop) < 1 || false)) {
    shouldCancelScroll = true;
  }
  return shouldCancelScroll;
};
var getTouchXY = function(event) {
  return "changedTouches" in event ? [event.changedTouches[0].clientX, event.changedTouches[0].clientY] : [0, 0];
};
var getDeltaXY = function(event) {
  return [event.deltaX, event.deltaY];
};
var extractRef = function(ref) {
  return ref && "current" in ref ? ref.current : ref;
};
var deltaCompare = function(x, y) {
  return x[0] === y[0] && x[1] === y[1];
};
var generateStyle = function(id) {
  return "\n  .block-interactivity-".concat(id, " {pointer-events: none;}\n  .allow-interactivity-").concat(id, " {pointer-events: all;}\n");
};
var idCounter = 0;
var lockStack = [];
function RemoveScrollSideCar(props) {
  var shouldPreventQueue = reactExports.useRef([]);
  var touchStartRef = reactExports.useRef([0, 0]);
  var activeAxis = reactExports.useRef();
  var id = reactExports.useState(idCounter++)[0];
  var Style2 = reactExports.useState(styleSingleton)[0];
  var lastProps = reactExports.useRef(props);
  reactExports.useEffect(function() {
    lastProps.current = props;
  }, [props]);
  reactExports.useEffect(function() {
    if (props.inert) {
      document.body.classList.add("block-interactivity-".concat(id));
      var allow_1 = __spreadArray([props.lockRef.current], (props.shards || []).map(extractRef), true).filter(Boolean);
      allow_1.forEach(function(el) {
        return el.classList.add("allow-interactivity-".concat(id));
      });
      return function() {
        document.body.classList.remove("block-interactivity-".concat(id));
        allow_1.forEach(function(el) {
          return el.classList.remove("allow-interactivity-".concat(id));
        });
      };
    }
    return;
  }, [props.inert, props.lockRef.current, props.shards]);
  var shouldCancelEvent = reactExports.useCallback(function(event, parent) {
    if ("touches" in event && event.touches.length === 2 || event.type === "wheel" && event.ctrlKey) {
      return !lastProps.current.allowPinchZoom;
    }
    var touch = getTouchXY(event);
    var touchStart = touchStartRef.current;
    var deltaX = "deltaX" in event ? event.deltaX : touchStart[0] - touch[0];
    var deltaY = "deltaY" in event ? event.deltaY : touchStart[1] - touch[1];
    var currentAxis;
    var target = event.target;
    var moveDirection = Math.abs(deltaX) > Math.abs(deltaY) ? "h" : "v";
    if ("touches" in event && moveDirection === "h" && target.type === "range") {
      return false;
    }
    var canBeScrolledInMainDirection = locationCouldBeScrolled(moveDirection, target);
    if (!canBeScrolledInMainDirection) {
      return true;
    }
    if (canBeScrolledInMainDirection) {
      currentAxis = moveDirection;
    } else {
      currentAxis = moveDirection === "v" ? "h" : "v";
      canBeScrolledInMainDirection = locationCouldBeScrolled(moveDirection, target);
    }
    if (!canBeScrolledInMainDirection) {
      return false;
    }
    if (!activeAxis.current && "changedTouches" in event && (deltaX || deltaY)) {
      activeAxis.current = currentAxis;
    }
    if (!currentAxis) {
      return true;
    }
    var cancelingAxis = activeAxis.current || currentAxis;
    return handleScroll(cancelingAxis, parent, event, cancelingAxis === "h" ? deltaX : deltaY);
  }, []);
  var shouldPrevent = reactExports.useCallback(function(_event) {
    var event = _event;
    if (!lockStack.length || lockStack[lockStack.length - 1] !== Style2) {
      return;
    }
    var delta = "deltaY" in event ? getDeltaXY(event) : getTouchXY(event);
    var sourceEvent = shouldPreventQueue.current.filter(function(e) {
      return e.name === event.type && (e.target === event.target || event.target === e.shadowParent) && deltaCompare(e.delta, delta);
    })[0];
    if (sourceEvent && sourceEvent.should) {
      if (event.cancelable) {
        event.preventDefault();
      }
      return;
    }
    if (!sourceEvent) {
      var shardNodes = (lastProps.current.shards || []).map(extractRef).filter(Boolean).filter(function(node) {
        return node.contains(event.target);
      });
      var shouldStop = shardNodes.length > 0 ? shouldCancelEvent(event, shardNodes[0]) : !lastProps.current.noIsolation;
      if (shouldStop) {
        if (event.cancelable) {
          event.preventDefault();
        }
      }
    }
  }, []);
  var shouldCancel = reactExports.useCallback(function(name, delta, target, should) {
    var event = { name, delta, target, should, shadowParent: getOutermostShadowParent(target) };
    shouldPreventQueue.current.push(event);
    setTimeout(function() {
      shouldPreventQueue.current = shouldPreventQueue.current.filter(function(e) {
        return e !== event;
      });
    }, 1);
  }, []);
  var scrollTouchStart = reactExports.useCallback(function(event) {
    touchStartRef.current = getTouchXY(event);
    activeAxis.current = void 0;
  }, []);
  var scrollWheel = reactExports.useCallback(function(event) {
    shouldCancel(event.type, getDeltaXY(event), event.target, shouldCancelEvent(event, props.lockRef.current));
  }, []);
  var scrollTouchMove = reactExports.useCallback(function(event) {
    shouldCancel(event.type, getTouchXY(event), event.target, shouldCancelEvent(event, props.lockRef.current));
  }, []);
  reactExports.useEffect(function() {
    lockStack.push(Style2);
    props.setCallbacks({
      onScrollCapture: scrollWheel,
      onWheelCapture: scrollWheel,
      onTouchMoveCapture: scrollTouchMove
    });
    document.addEventListener("wheel", shouldPrevent, nonPassive);
    document.addEventListener("touchmove", shouldPrevent, nonPassive);
    document.addEventListener("touchstart", scrollTouchStart, nonPassive);
    return function() {
      lockStack = lockStack.filter(function(inst) {
        return inst !== Style2;
      });
      document.removeEventListener("wheel", shouldPrevent, nonPassive);
      document.removeEventListener("touchmove", shouldPrevent, nonPassive);
      document.removeEventListener("touchstart", scrollTouchStart, nonPassive);
    };
  }, []);
  var removeScrollBar = props.removeScrollBar, inert = props.inert;
  return reactExports.createElement(
    reactExports.Fragment,
    null,
    inert ? reactExports.createElement(Style2, { styles: generateStyle(id) }) : null,
    removeScrollBar ? reactExports.createElement(RemoveScrollBar, { noRelative: props.noRelative, gapMode: props.gapMode }) : null
  );
}
function getOutermostShadowParent(node) {
  var shadowParent = null;
  while (node !== null) {
    if (node instanceof ShadowRoot) {
      shadowParent = node.host;
      node = node.host;
    }
    node = node.parentNode;
  }
  return shadowParent;
}
const SideCar = exportSidecar(effectCar, RemoveScrollSideCar);
var ReactRemoveScroll = reactExports.forwardRef(function(props, ref) {
  return reactExports.createElement(RemoveScroll, __assign$1({}, props, { ref, sideCar: SideCar }));
});
ReactRemoveScroll.classNames = RemoveScroll.classNames;
var getDefaultParent = function(originalTarget) {
  if (typeof document === "undefined") {
    return null;
  }
  var sampleTarget = Array.isArray(originalTarget) ? originalTarget[0] : originalTarget;
  return sampleTarget.ownerDocument.body;
};
var counterMap = /* @__PURE__ */ new WeakMap();
var uncontrolledNodes = /* @__PURE__ */ new WeakMap();
var markerMap = {};
var lockCount = 0;
var unwrapHost = function(node) {
  return node && (node.host || unwrapHost(node.parentNode));
};
var correctTargets = function(parent, targets) {
  return targets.map(function(target) {
    if (parent.contains(target)) {
      return target;
    }
    var correctedTarget = unwrapHost(target);
    if (correctedTarget && parent.contains(correctedTarget)) {
      return correctedTarget;
    }
    console.error("aria-hidden", target, "in not contained inside", parent, ". Doing nothing");
    return null;
  }).filter(function(x) {
    return Boolean(x);
  });
};
var applyAttributeToOthers = function(originalTarget, parentNode, markerName, controlAttribute) {
  var targets = correctTargets(parentNode, Array.isArray(originalTarget) ? originalTarget : [originalTarget]);
  if (!markerMap[markerName]) {
    markerMap[markerName] = /* @__PURE__ */ new WeakMap();
  }
  var markerCounter = markerMap[markerName];
  var hiddenNodes = [];
  var elementsToKeep = /* @__PURE__ */ new Set();
  var elementsToStop = new Set(targets);
  var keep = function(el) {
    if (!el || elementsToKeep.has(el)) {
      return;
    }
    elementsToKeep.add(el);
    keep(el.parentNode);
  };
  targets.forEach(keep);
  var deep = function(parent) {
    if (!parent || elementsToStop.has(parent)) {
      return;
    }
    Array.prototype.forEach.call(parent.children, function(node) {
      if (elementsToKeep.has(node)) {
        deep(node);
      } else {
        try {
          var attr = node.getAttribute(controlAttribute);
          var alreadyHidden = attr !== null && attr !== "false";
          var counterValue = (counterMap.get(node) || 0) + 1;
          var markerValue = (markerCounter.get(node) || 0) + 1;
          counterMap.set(node, counterValue);
          markerCounter.set(node, markerValue);
          hiddenNodes.push(node);
          if (counterValue === 1 && alreadyHidden) {
            uncontrolledNodes.set(node, true);
          }
          if (markerValue === 1) {
            node.setAttribute(markerName, "true");
          }
          if (!alreadyHidden) {
            node.setAttribute(controlAttribute, "true");
          }
        } catch (e) {
          console.error("aria-hidden: cannot operate on ", node, e);
        }
      }
    });
  };
  deep(parentNode);
  elementsToKeep.clear();
  lockCount++;
  return function() {
    hiddenNodes.forEach(function(node) {
      var counterValue = counterMap.get(node) - 1;
      var markerValue = markerCounter.get(node) - 1;
      counterMap.set(node, counterValue);
      markerCounter.set(node, markerValue);
      if (!counterValue) {
        if (!uncontrolledNodes.has(node)) {
          node.removeAttribute(controlAttribute);
        }
        uncontrolledNodes.delete(node);
      }
      if (!markerValue) {
        node.removeAttribute(markerName);
      }
    });
    lockCount--;
    if (!lockCount) {
      counterMap = /* @__PURE__ */ new WeakMap();
      counterMap = /* @__PURE__ */ new WeakMap();
      uncontrolledNodes = /* @__PURE__ */ new WeakMap();
      markerMap = {};
    }
  };
};
var hideOthers = function(originalTarget, parentNode, markerName) {
  if (markerName === void 0) {
    markerName = "data-aria-hidden";
  }
  var targets = Array.from(Array.isArray(originalTarget) ? originalTarget : [originalTarget]);
  var activeParentNode = getDefaultParent(originalTarget);
  if (!activeParentNode) {
    return function() {
      return null;
    };
  }
  targets.push.apply(targets, Array.from(activeParentNode.querySelectorAll("[aria-live], script")));
  return applyAttributeToOthers(targets, activeParentNode, markerName, "aria-hidden");
};
function useThemeDetector() {
  const [isDarkMode, setIsDarkMode] = reactExports.useState(() => {
    return detectDarkMode();
  });
  function detectDarkMode() {
    if (typeof document === "undefined") return false;
    const dataMode = document.documentElement.getAttribute("data-mode");
    if (dataMode === "dark") {
      return true;
    }
    if (dataMode === "light") {
      return false;
    }
    const htmlStyles = window.getComputedStyle(document.documentElement);
    const colorScheme = htmlStyles.getPropertyValue("color-scheme");
    if (colorScheme.includes("dark")) {
      return true;
    }
    if (document.documentElement.classList.contains("dark")) {
      return true;
    }
    const dataTheme = document.documentElement.getAttribute("data-theme");
    if (dataTheme === "dark" || dataTheme === "night" || dataTheme === "black") {
      return true;
    }
    if (document.body.classList.contains("dark") || document.body.classList.contains("dark-mode") || document.body.classList.contains("dark-theme") || document.body.getAttribute("data-theme") === "dark") {
      return true;
    }
    const bodyStyles = window.getComputedStyle(document.body);
    const themeColor = bodyStyles.getPropertyValue("--theme") || bodyStyles.getPropertyValue("--theme-mode") || bodyStyles.getPropertyValue("--color-scheme");
    if (themeColor.includes("dark")) {
      return true;
    }
    return false;
  }
  reactExports.useEffect(() => {
    if (typeof document === "undefined") return;
    const updateThemeState = () => {
      setIsDarkMode(detectDarkMode());
    };
    const documentObserver = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.attributeName === "class" || mutation.attributeName === "data-theme" || mutation.attributeName === "data-mode" || mutation.attributeName === "style") {
          updateThemeState();
          break;
        }
      }
    });
    documentObserver.observe(document.documentElement, { attributes: true });
    documentObserver.observe(document.body, { attributes: true });
    window.addEventListener("resize", updateThemeState);
    document.addEventListener("visibilitychange", updateThemeState);
    updateThemeState();
    return () => {
      documentObserver.disconnect();
      window.removeEventListener("resize", updateThemeState);
      document.removeEventListener("visibilitychange", updateThemeState);
    };
  }, []);
  return isDarkMode;
}
function getCurrentTheme() {
  if (typeof document === "undefined") return "light";
  const dataMode = document.documentElement.getAttribute("data-mode");
  if (dataMode === "dark") {
    return "dark";
  }
  if (dataMode === "light") {
    return "light";
  }
  const htmlStyles = window.getComputedStyle(document.documentElement);
  const colorScheme = htmlStyles.getPropertyValue("color-scheme");
  if (colorScheme.includes("dark")) {
    return "dark";
  }
  if (document.documentElement.classList.contains("dark")) {
    return "dark";
  }
  const dataTheme = document.documentElement.getAttribute("data-theme");
  if (dataTheme === "dark" || dataTheme === "night" || dataTheme === "black") {
    return "dark";
  }
  if (document.body.classList.contains("dark") || document.body.classList.contains("dark-mode") || document.body.classList.contains("dark-theme") || document.body.getAttribute("data-theme") === "dark") {
    return "dark";
  }
  const bodyStyles = window.getComputedStyle(document.body);
  const themeColor = bodyStyles.getPropertyValue("--theme") || bodyStyles.getPropertyValue("--theme-mode") || bodyStyles.getPropertyValue("--color-scheme");
  if (themeColor.includes("dark")) {
    return "dark";
  }
  return "light";
}
function setupMinimalFocusProtection(shadowRoot) {
  const monitorFocus = () => {
    var _a, _b;
    const activeElement = document.activeElement;
    const isParentPageInput = activeElement && !shadowRoot.contains(activeElement) && (activeElement.matches('input, textarea, [contenteditable="true"]') || ((_a = activeElement.id) == null ? void 0 : _a.includes("prompt")) || ((_b = activeElement.className) == null ? void 0 : _b.includes("prompt")));
    if (isParentPageInput) {
      const openDialogs = shadowRoot.querySelectorAll('[role="dialog"]');
      if (openDialogs.length > 0) {
        const firstDialog = openDialogs[0];
        const focusableInDialog = firstDialog.querySelector("input, textarea, button");
        if (focusableInDialog) {
          focusableInDialog.focus();
        }
      }
    }
  };
  const focusMonitorInterval = setInterval(monitorFocus, 200);
  return () => {
    clearInterval(focusMonitorInterval);
  };
}
class ComponentInjector {
  constructor() {
    __publicField(this, "roots", /* @__PURE__ */ new Map());
    __publicField(this, "containers", /* @__PURE__ */ new Map());
    __publicField(this, "shadowContainers", /* @__PURE__ */ new Map());
    __publicField(this, "styleElements", /* @__PURE__ */ new Map());
    __publicField(this, "themeObservers", /* @__PURE__ */ new Map());
    __publicField(this, "focusInterceptors", /* @__PURE__ */ new Map());
  }
  // Store cleanup functions
  /**
   * Get or create a shadow DOM element in the page
   * @param containerId - The ID for the container element
   * @param position - Optional position configuration
   * @param preventAutoTheme - Whether to disable automatic theme detection
   * @returns The shadow root element
   */
  getOrCreateShadowRoot(containerId, position, preventAutoTheme = false) {
    let container = document.getElementById(containerId);
    if (!container) {
      container = document.createElement("div");
      container.id = containerId;
      if (position) {
        container.style.position = position.type;
        if (position.zIndex) container.style.zIndex = position.zIndex;
        if (position.top) container.style.top = position.top;
        if (position.right) container.style.right = position.right;
        if (position.bottom) container.style.bottom = position.bottom;
        if (position.left) container.style.left = position.left;
      }
      document.body.appendChild(container);
    }
    this.containers.set(containerId, container);
    let shadowRoot = this.shadowContainers.get(containerId);
    if (!shadowRoot) {
      shadowRoot = container.attachShadow({ mode: "open" });
      this.shadowContainers.set(containerId, shadowRoot);
      const styleEl = document.createElement("style");
      styleEl.textContent = `
        :host {
          all: initial;
          display: contents;
        }
        
        /* Basic styling for better appearance */
        * {
          box-sizing: border-box;
        }
        
        /* Focus styles for accessibility */
        *:focus {
          outline: 2px solid var(--primary, #3b82f6);
          outline-offset: 2px;
        }
      `;
      shadowRoot.appendChild(styleEl);
      this.injectStylesheet(shadowRoot, chrome.runtime.getURL("assets/content.css"));
      if (!preventAutoTheme) {
        this.syncThemeWithHost(container);
        this.observeThemeChanges(containerId, container);
      }
      const focusCleanup = setupMinimalFocusProtection(shadowRoot);
      this.focusInterceptors.set(containerId, focusCleanup);
    }
    return shadowRoot;
  }
  /**
   * Sync the theme of the shadow root with the host document
   * @param container - The shadow host element
   */
  syncThemeWithHost(container) {
    const theme = getCurrentTheme();
    if (theme === "dark") {
      container.classList.add("dark");
      container.setAttribute("data-theme", "dark");
    } else {
      container.classList.remove("dark");
      container.setAttribute("data-theme", "light");
    }
  }
  /**
   * Set up a mutation observer to watch for theme changes in the host document
   * @param id - The component ID
   * @param container - The shadow host element
   */
  observeThemeChanges(id, container) {
    const existingObserver = this.themeObservers.get(id);
    if (existingObserver) {
      existingObserver.disconnect();
    }
    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        if (mutation.attributeName === "class" || mutation.attributeName === "data-theme" || mutation.attributeName === "data-mode" || mutation.attributeName === "style") {
          this.syncThemeWithHost(container);
          break;
        }
      }
    });
    observer.observe(document.documentElement, { attributes: true });
    observer.observe(document.body, { attributes: true });
    this.themeObservers.set(id, observer);
  }
  /**
   * Inject a stylesheet into a shadow root
   * @param shadowRoot - The shadow root to inject the stylesheet into
   * @param cssUrl - The URL of the CSS file
   */
  injectStylesheet(shadowRoot, cssUrl) {
    const linkEl = document.createElement("link");
    linkEl.rel = "stylesheet";
    linkEl.href = cssUrl;
    shadowRoot.appendChild(linkEl);
    const loadingEl = document.createElement("div");
    loadingEl.className = "loading-shadow-dom";
    loadingEl.textContent = "Loading extension UI...";
    shadowRoot.appendChild(loadingEl);
    linkEl.onload = () => {
      shadowRoot.contains(loadingEl) && shadowRoot.removeChild(loadingEl);
    };
    linkEl.onerror = () => {
      console.error("Failed to load CSS:", cssUrl);
      loadingEl.textContent = "Error loading UI styles";
    };
  }
  /**
   * Inject a React component into the page
   * @param Component - The React component to inject
   * @param props - Props to pass to the component
   * @param options - Injection options
   */
  inject(Component, props, options) {
    const { id, position, useShadowDom = true, preventAutoTheme = false } = options;
    try {
      this.remove(id);
      if (useShadowDom) {
        const shadowRoot = this.getOrCreateShadowRoot(id, position, preventAutoTheme);
        const reactContainer = document.createElement("div");
        reactContainer.id = `${id}-react-container`;
        shadowRoot.appendChild(reactContainer);
        const root = client$1.createRoot(reactContainer);
        root.render(React.createElement(Component, props));
        this.roots.set(id, root);
      } else {
        let container = document.getElementById(id);
        if (!container) {
          container = document.createElement("div");
          container.id = id;
          if (position) {
            container.style.position = position.type;
            if (position.zIndex) container.style.zIndex = position.zIndex;
            if (position.top) container.style.top = position.top;
            if (position.right) container.style.right = position.right;
            if (position.bottom) container.style.bottom = position.bottom;
            if (position.left) container.style.left = position.left;
          }
          document.body.appendChild(container);
        }
        this.containers.set(id, container);
        const root = client$1.createRoot(container);
        root.render(React.createElement(Component, props));
        this.roots.set(id, root);
      }
      console.log(`Component "${id}" injected successfully with enhanced focus management`);
    } catch (error) {
      console.error(`Error injecting component "${id}":`, error);
    }
  }
  /**
   * Remove an injected component
   * @param id - The ID of the component to remove
   */
  remove(id) {
    try {
      const observer = this.themeObservers.get(id);
      if (observer) {
        observer.disconnect();
        this.themeObservers.delete(id);
      }
      const focusCleanup = this.focusInterceptors.get(id);
      if (focusCleanup) {
        focusCleanup();
        this.focusInterceptors.delete(id);
      }
      const root = this.roots.get(id);
      if (root) {
        root.unmount();
        this.roots.delete(id);
      }
      const container = this.containers.get(id);
      if (container && container.parentNode) {
        container.parentNode.removeChild(container);
        this.containers.delete(id);
      }
      this.shadowContainers.delete(id);
      console.log(`Component "${id}" removed successfully`);
    } catch (error) {
      console.error(`Error removing component "${id}":`, error);
    }
  }
  /**
   * Remove all injected components
   */
  removeAll() {
    const ids = [...this.roots.keys()];
    ids.forEach((id) => this.remove(id));
    console.log("All components removed successfully");
  }
  /**
   * Get access to the shadow root for a component
   * @param id - The component ID
   * @returns The shadow root or null if not found
   */
  getShadowRoot(id) {
    return this.shadowContainers.get(id) || null;
  }
  /**
   * Add CSS to a specific shadow DOM
   * @param id - The component ID
   * @param css - The CSS content
   */
  addStyleToShadow(id, css) {
    const shadowRoot = this.shadowContainers.get(id);
    if (!shadowRoot) {
      console.error(`Shadow root for "${id}" not found`);
      return;
    }
    const styleElement = document.createElement("style");
    styleElement.textContent = css;
    shadowRoot.appendChild(styleElement);
    this.styleElements.set(`${id}-style`, styleElement);
  }
  /**
   * Manually update the theme for all shadow hosts
   * Useful for when the theme changes programmatically
   */
  updateAllThemes() {
    const containers = Array.from(this.containers.values());
    containers.forEach((container) => {
      this.syncThemeWithHost(container);
    });
  }
}
const componentInjector = new ComponentInjector();
function useShadowRoot() {
  const [shadowRoot, setShadowRoot] = React.useState(null);
  React.useEffect(() => {
    const findShadowRoot = () => {
      var _a;
      const mainRoot = document.getElementById("jaydai-root");
      if (mainRoot == null ? void 0 : mainRoot.shadowRoot) {
        return mainRoot.shadowRoot;
      }
      const alternateIds = ["jaydai-main-component", "jaydai-shadow-container"];
      for (const id of alternateIds) {
        const el = document.getElementById(id);
        if (el == null ? void 0 : el.shadowRoot) {
          return el.shadowRoot;
        }
      }
      if (((_a = document.head) == null ? void 0 : _a.getRootNode()) instanceof ShadowRoot) {
        return document.head.getRootNode();
      }
      const shadowRoots = Array.from(componentInjector["shadowContainers"].values());
      if (shadowRoots.length > 0) {
        return shadowRoots[0];
      }
      const allElements = document.querySelectorAll("*");
      for (const el of allElements) {
        if (el.shadowRoot) {
          return el.shadowRoot;
        }
      }
      return null;
    };
    const root = findShadowRoot();
    if (root) {
      setShadowRoot(root);
    } else {
      const retryTimeout = setTimeout(() => {
        const retryRoot = findShadowRoot();
        if (retryRoot) {
          setShadowRoot(retryRoot);
        } else {
          console.error("Shadow root not found after retry, dialogs may not work correctly");
        }
      }, 500);
      return () => clearTimeout(retryTimeout);
    }
  }, []);
  return shadowRoot;
}
function createCollection(name) {
  const PROVIDER_NAME = name + "CollectionProvider";
  const [createCollectionContext, createCollectionScope2] = createContextScope(PROVIDER_NAME);
  const [CollectionProviderImpl, useCollectionContext] = createCollectionContext(
    PROVIDER_NAME,
    { collectionRef: { current: null }, itemMap: /* @__PURE__ */ new Map() }
  );
  const CollectionProvider = (props) => {
    const { scope, children } = props;
    const ref = React.useRef(null);
    const itemMap = React.useRef(/* @__PURE__ */ new Map()).current;
    return /* @__PURE__ */ jsxRuntimeExports.jsx(CollectionProviderImpl, { scope, itemMap, collectionRef: ref, children });
  };
  CollectionProvider.displayName = PROVIDER_NAME;
  const COLLECTION_SLOT_NAME = name + "CollectionSlot";
  const CollectionSlotImpl = createSlot(COLLECTION_SLOT_NAME);
  const CollectionSlot = React.forwardRef(
    (props, forwardedRef) => {
      const { scope, children } = props;
      const context = useCollectionContext(COLLECTION_SLOT_NAME, scope);
      const composedRefs = useComposedRefs(forwardedRef, context.collectionRef);
      return /* @__PURE__ */ jsxRuntimeExports.jsx(CollectionSlotImpl, { ref: composedRefs, children });
    }
  );
  CollectionSlot.displayName = COLLECTION_SLOT_NAME;
  const ITEM_SLOT_NAME = name + "CollectionItemSlot";
  const ITEM_DATA_ATTR = "data-radix-collection-item";
  const CollectionItemSlotImpl = createSlot(ITEM_SLOT_NAME);
  const CollectionItemSlot = React.forwardRef(
    (props, forwardedRef) => {
      const { scope, children, ...itemData } = props;
      const ref = React.useRef(null);
      const composedRefs = useComposedRefs(forwardedRef, ref);
      const context = useCollectionContext(ITEM_SLOT_NAME, scope);
      React.useEffect(() => {
        context.itemMap.set(ref, { ref, ...itemData });
        return () => void context.itemMap.delete(ref);
      });
      return /* @__PURE__ */ jsxRuntimeExports.jsx(CollectionItemSlotImpl, { ...{ [ITEM_DATA_ATTR]: "" }, ref: composedRefs, children });
    }
  );
  CollectionItemSlot.displayName = ITEM_SLOT_NAME;
  function useCollection2(scope) {
    const context = useCollectionContext(name + "CollectionConsumer", scope);
    const getItems = React.useCallback(() => {
      const collectionNode = context.collectionRef.current;
      if (!collectionNode) return [];
      const orderedNodes = Array.from(collectionNode.querySelectorAll(`[${ITEM_DATA_ATTR}]`));
      const items = Array.from(context.itemMap.values());
      const orderedItems = items.sort(
        (a, b) => orderedNodes.indexOf(a.ref.current) - orderedNodes.indexOf(b.ref.current)
      );
      return orderedItems;
    }, [context.collectionRef, context.itemMap]);
    return getItems;
  }
  return [
    { Provider: CollectionProvider, Slot: CollectionSlot, ItemSlot: CollectionItemSlot },
    useCollection2,
    createCollectionScope2
  ];
}
var DirectionContext = reactExports.createContext(void 0);
function useDirection(localDir) {
  const globalDir = reactExports.useContext(DirectionContext);
  return localDir || globalDir || "ltr";
}
var ENTRY_FOCUS = "rovingFocusGroup.onEntryFocus";
var EVENT_OPTIONS = { bubbles: false, cancelable: true };
var GROUP_NAME$1 = "RovingFocusGroup";
var [Collection$1, useCollection$1, createCollectionScope$1] = createCollection(GROUP_NAME$1);
var [createRovingFocusGroupContext, createRovingFocusGroupScope] = createContextScope(
  GROUP_NAME$1,
  [createCollectionScope$1]
);
var [RovingFocusProvider, useRovingFocusContext] = createRovingFocusGroupContext(GROUP_NAME$1);
var RovingFocusGroup = reactExports.forwardRef(
  (props, forwardedRef) => {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Collection$1.Provider, { scope: props.__scopeRovingFocusGroup, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Collection$1.Slot, { scope: props.__scopeRovingFocusGroup, children: /* @__PURE__ */ jsxRuntimeExports.jsx(RovingFocusGroupImpl, { ...props, ref: forwardedRef }) }) });
  }
);
RovingFocusGroup.displayName = GROUP_NAME$1;
var RovingFocusGroupImpl = reactExports.forwardRef((props, forwardedRef) => {
  const {
    __scopeRovingFocusGroup,
    orientation,
    loop = false,
    dir,
    currentTabStopId: currentTabStopIdProp,
    defaultCurrentTabStopId,
    onCurrentTabStopIdChange,
    onEntryFocus,
    preventScrollOnEntryFocus = false,
    ...groupProps
  } = props;
  const ref = reactExports.useRef(null);
  const composedRefs = useComposedRefs(forwardedRef, ref);
  const direction = useDirection(dir);
  const [currentTabStopId, setCurrentTabStopId] = useControllableState({
    prop: currentTabStopIdProp,
    defaultProp: defaultCurrentTabStopId ?? null,
    onChange: onCurrentTabStopIdChange,
    caller: GROUP_NAME$1
  });
  const [isTabbingBackOut, setIsTabbingBackOut] = reactExports.useState(false);
  const handleEntryFocus = useCallbackRef$1(onEntryFocus);
  const getItems = useCollection$1(__scopeRovingFocusGroup);
  const isClickFocusRef = reactExports.useRef(false);
  const [focusableItemsCount, setFocusableItemsCount] = reactExports.useState(0);
  reactExports.useEffect(() => {
    const node = ref.current;
    if (node) {
      node.addEventListener(ENTRY_FOCUS, handleEntryFocus);
      return () => node.removeEventListener(ENTRY_FOCUS, handleEntryFocus);
    }
  }, [handleEntryFocus]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    RovingFocusProvider,
    {
      scope: __scopeRovingFocusGroup,
      orientation,
      dir: direction,
      loop,
      currentTabStopId,
      onItemFocus: reactExports.useCallback(
        (tabStopId) => setCurrentTabStopId(tabStopId),
        [setCurrentTabStopId]
      ),
      onItemShiftTab: reactExports.useCallback(() => setIsTabbingBackOut(true), []),
      onFocusableItemAdd: reactExports.useCallback(
        () => setFocusableItemsCount((prevCount) => prevCount + 1),
        []
      ),
      onFocusableItemRemove: reactExports.useCallback(
        () => setFocusableItemsCount((prevCount) => prevCount - 1),
        []
      ),
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        Primitive.div,
        {
          tabIndex: isTabbingBackOut || focusableItemsCount === 0 ? -1 : 0,
          "data-orientation": orientation,
          ...groupProps,
          ref: composedRefs,
          style: { outline: "none", ...props.style },
          onMouseDown: composeEventHandlers(props.onMouseDown, () => {
            isClickFocusRef.current = true;
          }),
          onFocus: composeEventHandlers(props.onFocus, (event) => {
            const isKeyboardFocus = !isClickFocusRef.current;
            if (event.target === event.currentTarget && isKeyboardFocus && !isTabbingBackOut) {
              const entryFocusEvent = new CustomEvent(ENTRY_FOCUS, EVENT_OPTIONS);
              event.currentTarget.dispatchEvent(entryFocusEvent);
              if (!entryFocusEvent.defaultPrevented) {
                const items = getItems().filter((item) => item.focusable);
                const activeItem = items.find((item) => item.active);
                const currentItem = items.find((item) => item.id === currentTabStopId);
                const candidateItems = [activeItem, currentItem, ...items].filter(
                  Boolean
                );
                const candidateNodes = candidateItems.map((item) => item.ref.current);
                focusFirst(candidateNodes, preventScrollOnEntryFocus);
              }
            }
            isClickFocusRef.current = false;
          }),
          onBlur: composeEventHandlers(props.onBlur, () => setIsTabbingBackOut(false))
        }
      )
    }
  );
});
var ITEM_NAME$1 = "RovingFocusGroupItem";
var RovingFocusGroupItem = reactExports.forwardRef(
  (props, forwardedRef) => {
    const {
      __scopeRovingFocusGroup,
      focusable = true,
      active = false,
      tabStopId,
      children,
      ...itemProps
    } = props;
    const autoId = useId();
    const id = tabStopId || autoId;
    const context = useRovingFocusContext(ITEM_NAME$1, __scopeRovingFocusGroup);
    const isCurrentTabStop = context.currentTabStopId === id;
    const getItems = useCollection$1(__scopeRovingFocusGroup);
    const { onFocusableItemAdd, onFocusableItemRemove, currentTabStopId } = context;
    reactExports.useEffect(() => {
      if (focusable) {
        onFocusableItemAdd();
        return () => onFocusableItemRemove();
      }
    }, [focusable, onFocusableItemAdd, onFocusableItemRemove]);
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Collection$1.ItemSlot,
      {
        scope: __scopeRovingFocusGroup,
        id,
        focusable,
        active,
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          Primitive.span,
          {
            tabIndex: isCurrentTabStop ? 0 : -1,
            "data-orientation": context.orientation,
            ...itemProps,
            ref: forwardedRef,
            onMouseDown: composeEventHandlers(props.onMouseDown, (event) => {
              if (!focusable) event.preventDefault();
              else context.onItemFocus(id);
            }),
            onFocus: composeEventHandlers(props.onFocus, () => context.onItemFocus(id)),
            onKeyDown: composeEventHandlers(props.onKeyDown, (event) => {
              if (event.key === "Tab" && event.shiftKey) {
                context.onItemShiftTab();
                return;
              }
              if (event.target !== event.currentTarget) return;
              const focusIntent = getFocusIntent(event, context.orientation, context.dir);
              if (focusIntent !== void 0) {
                if (event.metaKey || event.ctrlKey || event.altKey || event.shiftKey) return;
                event.preventDefault();
                const items = getItems().filter((item) => item.focusable);
                let candidateNodes = items.map((item) => item.ref.current);
                if (focusIntent === "last") candidateNodes.reverse();
                else if (focusIntent === "prev" || focusIntent === "next") {
                  if (focusIntent === "prev") candidateNodes.reverse();
                  const currentIndex = candidateNodes.indexOf(event.currentTarget);
                  candidateNodes = context.loop ? wrapArray$1(candidateNodes, currentIndex + 1) : candidateNodes.slice(currentIndex + 1);
                }
                setTimeout(() => focusFirst(candidateNodes));
              }
            }),
            children: typeof children === "function" ? children({ isCurrentTabStop, hasTabStop: currentTabStopId != null }) : children
          }
        )
      }
    );
  }
);
RovingFocusGroupItem.displayName = ITEM_NAME$1;
var MAP_KEY_TO_FOCUS_INTENT = {
  ArrowLeft: "prev",
  ArrowUp: "prev",
  ArrowRight: "next",
  ArrowDown: "next",
  PageUp: "first",
  Home: "first",
  PageDown: "last",
  End: "last"
};
function getDirectionAwareKey(key, dir) {
  if (dir !== "rtl") return key;
  return key === "ArrowLeft" ? "ArrowRight" : key === "ArrowRight" ? "ArrowLeft" : key;
}
function getFocusIntent(event, orientation, dir) {
  const key = getDirectionAwareKey(event.key, dir);
  if (orientation === "vertical" && ["ArrowLeft", "ArrowRight"].includes(key)) return void 0;
  if (orientation === "horizontal" && ["ArrowUp", "ArrowDown"].includes(key)) return void 0;
  return MAP_KEY_TO_FOCUS_INTENT[key];
}
function focusFirst(candidates, preventScroll = false) {
  const PREVIOUSLY_FOCUSED_ELEMENT = document.activeElement;
  for (const candidate of candidates) {
    if (candidate === PREVIOUSLY_FOCUSED_ELEMENT) return;
    candidate.focus({ preventScroll });
    if (document.activeElement !== PREVIOUSLY_FOCUSED_ELEMENT) return;
  }
}
function wrapArray$1(array, startIndex) {
  return array.map((_, index) => array[(startIndex + index) % array.length]);
}
var Root = RovingFocusGroup;
var Item$1 = RovingFocusGroupItem;
var TABS_NAME = "Tabs";
var [createTabsContext, createTabsScope] = createContextScope(TABS_NAME, [
  createRovingFocusGroupScope
]);
var useRovingFocusGroupScope = createRovingFocusGroupScope();
var [TabsProvider, useTabsContext] = createTabsContext(TABS_NAME);
var Tabs$1 = reactExports.forwardRef(
  (props, forwardedRef) => {
    const {
      __scopeTabs,
      value: valueProp,
      onValueChange,
      defaultValue,
      orientation = "horizontal",
      dir,
      activationMode = "automatic",
      ...tabsProps
    } = props;
    const direction = useDirection(dir);
    const [value, setValue] = useControllableState({
      prop: valueProp,
      onChange: onValueChange,
      defaultProp: defaultValue ?? "",
      caller: TABS_NAME
    });
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      TabsProvider,
      {
        scope: __scopeTabs,
        baseId: useId(),
        value,
        onValueChange: setValue,
        orientation,
        dir: direction,
        activationMode,
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          Primitive.div,
          {
            dir: direction,
            "data-orientation": orientation,
            ...tabsProps,
            ref: forwardedRef
          }
        )
      }
    );
  }
);
Tabs$1.displayName = TABS_NAME;
var TAB_LIST_NAME = "TabsList";
var TabsList$1 = reactExports.forwardRef(
  (props, forwardedRef) => {
    const { __scopeTabs, loop = true, ...listProps } = props;
    const context = useTabsContext(TAB_LIST_NAME, __scopeTabs);
    const rovingFocusGroupScope = useRovingFocusGroupScope(__scopeTabs);
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Root,
      {
        asChild: true,
        ...rovingFocusGroupScope,
        orientation: context.orientation,
        dir: context.dir,
        loop,
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          Primitive.div,
          {
            role: "tablist",
            "aria-orientation": context.orientation,
            ...listProps,
            ref: forwardedRef
          }
        )
      }
    );
  }
);
TabsList$1.displayName = TAB_LIST_NAME;
var TRIGGER_NAME$1 = "TabsTrigger";
var TabsTrigger$1 = reactExports.forwardRef(
  (props, forwardedRef) => {
    const { __scopeTabs, value, disabled = false, ...triggerProps } = props;
    const context = useTabsContext(TRIGGER_NAME$1, __scopeTabs);
    const rovingFocusGroupScope = useRovingFocusGroupScope(__scopeTabs);
    const triggerId = makeTriggerId(context.baseId, value);
    const contentId = makeContentId(context.baseId, value);
    const isSelected = value === context.value;
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Item$1,
      {
        asChild: true,
        ...rovingFocusGroupScope,
        focusable: !disabled,
        active: isSelected,
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          Primitive.button,
          {
            type: "button",
            role: "tab",
            "aria-selected": isSelected,
            "aria-controls": contentId,
            "data-state": isSelected ? "active" : "inactive",
            "data-disabled": disabled ? "" : void 0,
            disabled,
            id: triggerId,
            ...triggerProps,
            ref: forwardedRef,
            onMouseDown: composeEventHandlers(props.onMouseDown, (event) => {
              if (!disabled && event.button === 0 && event.ctrlKey === false) {
                context.onValueChange(value);
              } else {
                event.preventDefault();
              }
            }),
            onKeyDown: composeEventHandlers(props.onKeyDown, (event) => {
              if ([" ", "Enter"].includes(event.key)) context.onValueChange(value);
            }),
            onFocus: composeEventHandlers(props.onFocus, () => {
              const isAutomaticActivation = context.activationMode !== "manual";
              if (!isSelected && !disabled && isAutomaticActivation) {
                context.onValueChange(value);
              }
            })
          }
        )
      }
    );
  }
);
TabsTrigger$1.displayName = TRIGGER_NAME$1;
var CONTENT_NAME$1 = "TabsContent";
var TabsContent$1 = reactExports.forwardRef(
  (props, forwardedRef) => {
    const { __scopeTabs, value, forceMount, children, ...contentProps } = props;
    const context = useTabsContext(CONTENT_NAME$1, __scopeTabs);
    const triggerId = makeTriggerId(context.baseId, value);
    const contentId = makeContentId(context.baseId, value);
    const isSelected = value === context.value;
    const isMountAnimationPreventedRef = reactExports.useRef(isSelected);
    reactExports.useEffect(() => {
      const rAF = requestAnimationFrame(() => isMountAnimationPreventedRef.current = false);
      return () => cancelAnimationFrame(rAF);
    }, []);
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Presence, { present: forceMount || isSelected, children: ({ present }) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      Primitive.div,
      {
        "data-state": isSelected ? "active" : "inactive",
        "data-orientation": context.orientation,
        role: "tabpanel",
        "aria-labelledby": triggerId,
        hidden: !present,
        id: contentId,
        tabIndex: 0,
        ...contentProps,
        ref: forwardedRef,
        style: {
          ...props.style,
          animationDuration: isMountAnimationPreventedRef.current ? "0s" : void 0
        },
        children: present && children
      }
    ) });
  }
);
TabsContent$1.displayName = CONTENT_NAME$1;
function makeTriggerId(baseId, value) {
  return `${baseId}-trigger-${value}`;
}
function makeContentId(baseId, value) {
  return `${baseId}-content-${value}`;
}
var Root2$1 = Tabs$1;
var List = TabsList$1;
var Trigger$1 = TabsTrigger$1;
var Content = TabsContent$1;
const Tabs = Root2$1;
const TabsList = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  List,
  {
    ref,
    className: cn(
      "jd-inline-flex jd-items-center jd-justify-center jd-rounded-md jd-bg-muted jd-p-1 jd-text-muted-foreground",
      className
    ),
    ...props
  }
));
TabsList.displayName = List.displayName;
const TabsTrigger = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Trigger$1,
  {
    ref,
    className: cn(
      "jd-inline-flex jd-items-center jd-justify-center jd-whitespace-nowrap jd-rounded-sm jd-px-3 jd-py-1.5 jd-text-sm jd-font-medium jd-ring-offset-background jd-transition-all focus-visible:jd-outline-none focus-visible:jd-ring-2 focus-visible:jd-ring-ring focus-visible:jd-ring-offset-2 disabled:jd-pointer-events-none disabled:jd-opacity-50 data-[state=active]:jd-bg-background data-[state=active]:jd-text-foreground data-[state=active]:jd-shadow-sm",
      className
    ),
    ...props
  }
));
TabsTrigger.displayName = Trigger$1.displayName;
const TabsContent = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Content,
  {
    ref,
    className: cn(
      "jd-mt-2 jd-ring-offset-background focus-visible:jd-outline-none focus-visible:jd-ring-2 focus-visible:jd-ring-ring focus-visible:jd-ring-offset-2",
      className
    ),
    ...props
  }
));
TabsContent.displayName = Content.displayName;
class UserApi {
  /**
   * Save user metadata
   */
  async saveUserMetadata(userData) {
    console.log("saveUserMetadata", userData);
    return apiClient.request("/save/user_metadata", {
      method: "POST",
      body: JSON.stringify(userData)
    });
  }
  /**
   * Get user metadata
   */
  async getUserMetadata() {
    return apiClient.request("/user/metadata");
  }
  /**
   * Get user stats
   */
  async getUserStats() {
    return apiClient.request("/stats/user");
  }
  /**
   * Get weekly conversation statistics
   */
  async getWeeklyConversationStats() {
    return apiClient.request("/stats/conversations/weekly");
  }
  /**
   * Get message distribution statistics
   */
  async getMessageDistribution() {
    return apiClient.request("/stats/messages/distribution");
  }
  /**
   * Get user onboarding status
   */
  async getUserOnboardingStatus() {
    return apiClient.request("/user/onboarding/status");
  }
}
const userApi = new UserApi();
const AuthForm = ({
  initialMode = "signin",
  isSessionExpired = false,
  onSuccess,
  onClose
}) => {
  const [activeTab, setActiveTab] = reactExports.useState(initialMode);
  const [email, setEmail] = reactExports.useState("");
  const [password, setPassword] = reactExports.useState("");
  const [name, setName] = reactExports.useState("");
  const [isLoading, setIsLoading] = reactExports.useState(false);
  const [message, setMessage] = reactExports.useState(
    isSessionExpired ? { text: getMessage("sessionExpired", void 0, "Session expired"), type: "info" } : null
  );
  reactExports.useEffect(() => {
    setActiveTab(initialMode);
  }, [initialMode]);
  reactExports.useEffect(() => {
    if (isSessionExpired) {
      setMessage({
        text: getMessage("sessionExpired", void 0, "Session expired"),
        type: "info"
      });
    }
  }, [isSessionExpired]);
  reactExports.useEffect(() => {
    const unsubscribe = authService.subscribe((state) => {
      if (state.error) {
        setMessage({
          text: state.error,
          type: "error"
        });
      } else if (state.user && state.isAuthenticated) {
        if (onSuccess) {
          onSuccess();
        }
      }
    });
    return () => {
      unsubscribe();
      authService.clearError();
    };
  }, [onSuccess]);
  const resetForm = () => {
    setEmail("");
    setPassword("");
    setName("");
    setMessage(null);
    authService.clearError();
  };
  const handleTabChange = (value) => {
    setActiveTab(value);
    resetForm();
  };
  const validateSignInInputs = () => {
    if (!email.trim()) {
      setMessage({
        text: getMessage("enterEmail", void 0, "Please enter your email"),
        type: "error"
      });
      return false;
    }
    if (!password) {
      setMessage({
        text: getMessage("enterPassword", void 0, "Please enter your password"),
        type: "error"
      });
      return false;
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.trim())) {
      setMessage({
        text: getMessage("invalidEmail", void 0, "Invalid email address"),
        type: "error"
      });
      return false;
    }
    return true;
  };
  const validateSignUpInputs = () => {
    if (!validateSignInInputs()) {
      return false;
    }
    if (password.length < 8) {
      setMessage({
        text: getMessage("passwordTooShort", void 0, "Password must be at least 8 characters"),
        type: "error"
      });
      return false;
    }
    return true;
  };
  const checkOnboardingStatus = async (userId) => {
    try {
      const status = await userApi.getUserOnboardingStatus();
      return !status.hasCompleted;
    } catch (error) {
      console.error("Error checking onboarding status:", error);
      return false;
    }
  };
  const handleEmailSignIn = async () => {
    if (!validateSignInInputs()) {
      return;
    }
    setIsLoading(true);
    setMessage(null);
    try {
      const success = await authService.signInWithEmail(email.trim(), password);
      if (success) {
        const state = authService.getAuthState();
        const needsOnboarding = state.user ? await checkOnboardingStatus(state.user.id) : false;
        toast.success(
          getMessage("signInSuccessful", void 0, "Sign-in successful"),
          {
            description: needsOnboarding ? getMessage("completeOnboarding", void 0, "Please complete the onboarding process") : getMessage("youCanNowAccess", void 0, "You can now access your conversations")
          }
        );
        if (!needsOnboarding) {
          window.open("https://chat.openai.com", "_blank");
        }
        if (onClose) {
          onClose();
        }
      }
    } catch (error) {
      setMessage({
        text: getMessage("invalidCredentials", void 0, "Invalid email or password"),
        type: "error"
      });
      console.error("Auth form error:", error);
    } finally {
      setIsLoading(false);
    }
  };
  const handleSignUp = async () => {
    if (!validateSignUpInputs()) {
      return;
    }
    setIsLoading(true);
    setMessage(null);
    try {
      const success = await authService.signUp(email.trim(), password, name.trim());
      if (success) {
        toast.success(
          getMessage("signUpSuccessful", void 0, "Sign-up successful"),
          {
            description: getMessage("completeOnboarding", void 0, "Please complete the onboarding process")
          }
        );
        await handleEmailSignIn();
      }
    } catch (error) {
      setMessage({
        text: error instanceof Error ? error.message : String(error),
        type: "error"
      });
      console.error("Auth form error:", error);
    } finally {
      setIsLoading(false);
    }
  };
  const handleGoogleSignIn = async () => {
    setIsLoading(true);
    setMessage(null);
    try {
      const success = await authService.signInWithGoogle();
      if (success) {
        const state = authService.getAuthState();
        const needsOnboarding = state.user ? await checkOnboardingStatus(state.user.id) : false;
        toast.success(
          getMessage("signInSuccessful", void 0, "Sign-in successful"),
          {
            description: needsOnboarding ? getMessage("completeOnboarding", void 0, "Please complete the onboarding process") : getMessage("youCanNowAccess", void 0, "You can now access your conversations")
          }
        );
        if (!needsOnboarding) {
          window.open("https://chat.openai.com", "_blank");
        }
        if (onClose) {
          onClose();
        }
      }
    } catch (error) {
      setMessage({
        text: error instanceof Error ? error.message : String(error),
        type: "error"
      });
      console.error("Google sign-in error:", error);
    } finally {
      setIsLoading(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-4 py-2 bg-background bg-opacity-100", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    Tabs,
    {
      defaultValue: activeTab,
      value: activeTab,
      onValueChange: handleTabChange,
      className: "jd-w-full",
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsList, { className: "jd-grid jd-w-full jd-grid-cols-2 jd-mb-6 jd-bg-gray-800", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            TabsTrigger,
            {
              value: "signin",
              className: "jd-font-heading jd-text-sm data-[state=active]:jd-bg-blue-600 data-[state=active]:jd-text-white",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(LogIn, { className: "jd-h-4 jd-w-4 jd-mr-2" }),
                getMessage("signIn", void 0, "Sign In")
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            TabsTrigger,
            {
              value: "signup",
              className: "jd-font-heading jd-text-sm data-[state=active]:jd-bg-blue-600 data-[state=active]:jd-text-white",
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "jd-h-4 jd-w-4 jd-mr-2" }),
                getMessage("signUp", void 0, "Sign Up")
              ]
            }
          )
        ] }),
        message && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: `jd-p-3 jd-rounded-md jd-mb-4 jd-flex jd-items-start jd-gap-2 ${message.type === "error" ? "jd-bg-red-900/30 jd-text-red-300 jd-border jd-border-red-700/50" : message.type === "success" ? "jd-bg-green-900/30 jd-text-green-300 jd-border jd-border-green-700/50" : "jd-bg-blue-900/30 jd-text-blue-300 jd-border jd-border-blue-700/50"}`,
            children: [
              message.type === "error" ? /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "jd-h-5 jd-w-5 jd-shrink-0" }) : message.type === "success" ? /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheckBig, { className: "jd-h-5 jd-w-5 jd-shrink-0" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "jd-h-5 jd-w-5 jd-shrink-0" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "jd-text-sm ", children: message.text })
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsContent, { value: "signin", className: "space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-space-y-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-space-y-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label$1, { htmlFor: "email-signin", className: "jd-text-gray-300 ", children: getMessage("email", void 0, "Email") }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-relative", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                Input,
                {
                  id: "email-signin",
                  type: "email",
                  placeholder: "you@example.com",
                  value: email,
                  onChange: (e) => setEmail(e.target.value),
                  className: "jd-pl-2 jd-bg-gray-800 jd-border-gray-700 jd-text-white focus:jd-border-blue-500 focus:jd-ring-blue-500 jd-text-sm"
                }
              ) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-space-y-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label$1, { htmlFor: "password-signin", className: "jd-text-gray-300 ", children: getMessage("password", void 0, "Password") }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-relative", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                Input,
                {
                  id: "password-signin",
                  type: "password",
                  placeholder: "••••••••",
                  value: password,
                  onChange: (e) => setPassword(e.target.value),
                  className: "jd-pl-2 jd-bg-gray-800 jd-border-gray-700 jd-text-white  focus:jd-border-blue-500 focus:jd-ring-blue-500 jd-text-sm"
                }
              ) })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Button,
            {
              onClick: handleEmailSignIn,
              className: "jd-w-full jd-font-heading jd-bg-blue-600 hover:jd-bg-blue-700",
              disabled: isLoading,
              children: isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "jd-flex jd-items-center", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { className: "jd-animate-spin jd-ml-1 jd-mr-3 jd-h-4 jd-w-4 jd-text-white", xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("circle", { className: "jd-opacity-25", cx: "12", cy: "12", r: "10", stroke: "currentColor", strokeWidth: "4" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("path", { className: "jd-opacity-75 jd-fill-current jd-text-white", d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" })
                ] }),
                getMessage("signingIn", void 0, "Signing in...")
              ] }) : getMessage("signIn", void 0, "Sign In")
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-relative jd-my-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-absolute jd-inset-0 jd-flex jd-items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-w-full jd-border-t jd-border-gray-700" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-relative jd-flex jd-justify-center jd-jd-text-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "jd-px-2 jd-bg-gray-900 jd-text-gray-400 ", children: getMessage("or", void 0, "Or continue with") }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-grid jd-gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
            Button,
            {
              variant: "outline",
              onClick: handleGoogleSignIn,
              className: "jd-w-full jd-font-heading jd-border-gray-700 jd-text-white hover:jd-bg-gray-800",
              disabled: isLoading,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "img",
                  {
                    src: "https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg",
                    alt: "Google",
                    className: "jd-h-5 jd-w-5 jd-mr-2"
                  }
                ),
                getMessage("signInWith", ["Google"]) || "Sign in with Google"
              ]
            }
          ) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TabsContent, { value: "signup", className: "space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-space-y-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-space-y-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label$1, { htmlFor: "name-signup", className: "jd-text-gray-300 ", children: getMessage("name", void 0, "Name") }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-relative", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                Input,
                {
                  id: "name-signup",
                  type: "text",
                  placeholder: "John Doe",
                  value: name,
                  onChange: (e) => setName(e.target.value),
                  className: "jd-pl-2 jd-bg-gray-800 jd-border-gray-700 jd-text-white  focus:jd-border-blue-500 focus:jd-ring-blue-500 jd-text-sm"
                }
              ) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-space-y-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label$1, { htmlFor: "email-signup", className: "jd-text-gray-300 ", children: getMessage("email", void 0, "Email") }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-relative", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                Input,
                {
                  id: "email-signup",
                  type: "email",
                  placeholder: "you@example.com",
                  value: email,
                  onChange: (e) => setEmail(e.target.value),
                  className: "jd-pl-2 jd-bg-gray-800 jd-border-gray-700 jd-text-white  focus:jd-border-blue-500 focus:jd-ring-blue-500 jd-text-sm"
                }
              ) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-space-y-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Label$1, { htmlFor: "password-signup", className: "jd-text-gray-300 ", children: getMessage("password", void 0, "Password") }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-relative", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                Input,
                {
                  id: "password-signup",
                  type: "password",
                  placeholder: "••••••••",
                  value: password,
                  onChange: (e) => setPassword(e.target.value),
                  className: "jd-pl-2 jd-bg-gray-800 jd-border-gray-700 jd-text-white  focus:jd-border-blue-500 focus:jd-ring-blue-500 jd-text-sm"
                }
              ) })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Button,
            {
              onClick: handleSignUp,
              className: "jd-w-full jd-font-heading jd-bg-blue-600 hover:jd-bg-blue-700",
              disabled: isLoading,
              children: isLoading ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "jd-flex jd-items-center", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { className: "jd-animate-spin jd-ml-1 jd-mr-3 jd-h-4 jd-w-4 jd-text-white", xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("circle", { className: "jd-opacity-25", cx: "12", cy: "12", r: "10", stroke: "currentColor", strokeWidth: "4" }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("path", { className: "jd-opacity-75 jd-fill-current jd-text-white", d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" })
                ] }),
                getMessage("signingUp", void 0, "Creating account...")
              ] }) : getMessage("signUp", void 0, "Sign Up")
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-relative jd-my-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-absolute jd-inset-0 jd-flex jd-items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-w-full jd-border-t jd-border-gray-700" }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-relative jd-flex jd-justify-center jd-jd-text-sm", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "jd-px-2 jd-bg-gray-900 jd-text-gray-400 ", children: getMessage("or", void 0, "Or sign up with") }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-grid jd-gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
            Button,
            {
              variant: "outline",
              onClick: handleGoogleSignIn,
              className: "jd-w-full jd-font-heading jd-border-gray-700 jd-text-white hover:jd-bg-gray-800",
              disabled: isLoading,
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: "https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg", alt: "Google", className: "jd-h-5 jd-w-5 jd-mr-2" }),
                getMessage("signUpWith", ["Google"]) || "Sign up with Google"
              ]
            }
          ) })
        ] })
      ]
    }
  ) });
};
function clamp(value, [min, max]) {
  return Math.min(max, Math.max(min, value));
}
function usePrevious(value) {
  const ref = reactExports.useRef({ value, previous: value });
  return reactExports.useMemo(() => {
    if (ref.current.value !== value) {
      ref.current.previous = ref.current.value;
      ref.current.value = value;
    }
    return ref.current.previous;
  }, [value]);
}
var OPEN_KEYS = [" ", "Enter", "ArrowUp", "ArrowDown"];
var SELECTION_KEYS = [" ", "Enter"];
var SELECT_NAME = "Select";
var [Collection, useCollection, createCollectionScope] = createCollection(SELECT_NAME);
var [createSelectContext, createSelectScope] = createContextScope(SELECT_NAME, [
  createCollectionScope,
  createPopperScope
]);
var usePopperScope = createPopperScope();
var [SelectProvider, useSelectContext] = createSelectContext(SELECT_NAME);
var [SelectNativeOptionsProvider, useSelectNativeOptionsContext] = createSelectContext(SELECT_NAME);
var Select$1 = (props) => {
  const {
    __scopeSelect,
    children,
    open: openProp,
    defaultOpen,
    onOpenChange,
    value: valueProp,
    defaultValue,
    onValueChange,
    dir,
    name,
    autoComplete,
    disabled,
    required,
    form
  } = props;
  const popperScope = usePopperScope(__scopeSelect);
  const [trigger, setTrigger] = reactExports.useState(null);
  const [valueNode, setValueNode] = reactExports.useState(null);
  const [valueNodeHasChildren, setValueNodeHasChildren] = reactExports.useState(false);
  const direction = useDirection(dir);
  const [open, setOpen] = useControllableState({
    prop: openProp,
    defaultProp: defaultOpen ?? false,
    onChange: onOpenChange,
    caller: SELECT_NAME
  });
  const [value, setValue] = useControllableState({
    prop: valueProp,
    defaultProp: defaultValue,
    onChange: onValueChange,
    caller: SELECT_NAME
  });
  const triggerPointerDownPosRef = reactExports.useRef(null);
  const isFormControl = trigger ? form || !!trigger.closest("form") : true;
  const [nativeOptionsSet, setNativeOptionsSet] = reactExports.useState(/* @__PURE__ */ new Set());
  const nativeSelectKey = Array.from(nativeOptionsSet).map((option) => option.props.value).join(";");
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Root2$2, { ...popperScope, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    SelectProvider,
    {
      required,
      scope: __scopeSelect,
      trigger,
      onTriggerChange: setTrigger,
      valueNode,
      onValueNodeChange: setValueNode,
      valueNodeHasChildren,
      onValueNodeHasChildrenChange: setValueNodeHasChildren,
      contentId: useId(),
      value,
      onValueChange: setValue,
      open,
      onOpenChange: setOpen,
      dir: direction,
      triggerPointerDownPosRef,
      disabled,
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Collection.Provider, { scope: __scopeSelect, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          SelectNativeOptionsProvider,
          {
            scope: props.__scopeSelect,
            onNativeOptionAdd: reactExports.useCallback((option) => {
              setNativeOptionsSet((prev) => new Set(prev).add(option));
            }, []),
            onNativeOptionRemove: reactExports.useCallback((option) => {
              setNativeOptionsSet((prev) => {
                const optionsSet = new Set(prev);
                optionsSet.delete(option);
                return optionsSet;
              });
            }, []),
            children
          }
        ) }),
        isFormControl ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
          SelectBubbleInput,
          {
            "aria-hidden": true,
            required,
            tabIndex: -1,
            name,
            autoComplete,
            value,
            onChange: (event) => setValue(event.target.value),
            disabled,
            form,
            children: [
              value === void 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "" }) : null,
              Array.from(nativeOptionsSet)
            ]
          },
          nativeSelectKey
        ) : null
      ]
    }
  ) });
};
Select$1.displayName = SELECT_NAME;
var TRIGGER_NAME = "SelectTrigger";
var SelectTrigger$1 = reactExports.forwardRef(
  (props, forwardedRef) => {
    const { __scopeSelect, disabled = false, ...triggerProps } = props;
    const popperScope = usePopperScope(__scopeSelect);
    const context = useSelectContext(TRIGGER_NAME, __scopeSelect);
    const isDisabled = context.disabled || disabled;
    const composedRefs = useComposedRefs(forwardedRef, context.onTriggerChange);
    const getItems = useCollection(__scopeSelect);
    const pointerTypeRef = reactExports.useRef("touch");
    const [searchRef, handleTypeaheadSearch, resetTypeahead] = useTypeaheadSearch((search) => {
      const enabledItems = getItems().filter((item) => !item.disabled);
      const currentItem = enabledItems.find((item) => item.value === context.value);
      const nextItem = findNextItem(enabledItems, search, currentItem);
      if (nextItem !== void 0) {
        context.onValueChange(nextItem.value);
      }
    });
    const handleOpen = (pointerEvent) => {
      if (!isDisabled) {
        context.onOpenChange(true);
        resetTypeahead();
      }
      if (pointerEvent) {
        context.triggerPointerDownPosRef.current = {
          x: Math.round(pointerEvent.pageX),
          y: Math.round(pointerEvent.pageY)
        };
      }
    };
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Anchor, { asChild: true, ...popperScope, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      Primitive.button,
      {
        type: "button",
        role: "combobox",
        "aria-controls": context.contentId,
        "aria-expanded": context.open,
        "aria-required": context.required,
        "aria-autocomplete": "none",
        dir: context.dir,
        "data-state": context.open ? "open" : "closed",
        disabled: isDisabled,
        "data-disabled": isDisabled ? "" : void 0,
        "data-placeholder": shouldShowPlaceholder(context.value) ? "" : void 0,
        ...triggerProps,
        ref: composedRefs,
        onClick: composeEventHandlers(triggerProps.onClick, (event) => {
          event.currentTarget.focus();
          if (pointerTypeRef.current !== "mouse") {
            handleOpen(event);
          }
        }),
        onPointerDown: composeEventHandlers(triggerProps.onPointerDown, (event) => {
          pointerTypeRef.current = event.pointerType;
          const target = event.target;
          if (target.hasPointerCapture(event.pointerId)) {
            target.releasePointerCapture(event.pointerId);
          }
          if (event.button === 0 && event.ctrlKey === false && event.pointerType === "mouse") {
            handleOpen(event);
            event.preventDefault();
          }
        }),
        onKeyDown: composeEventHandlers(triggerProps.onKeyDown, (event) => {
          const isTypingAhead = searchRef.current !== "";
          const isModifierKey = event.ctrlKey || event.altKey || event.metaKey;
          if (!isModifierKey && event.key.length === 1) handleTypeaheadSearch(event.key);
          if (isTypingAhead && event.key === " ") return;
          if (OPEN_KEYS.includes(event.key)) {
            handleOpen();
            event.preventDefault();
          }
        })
      }
    ) });
  }
);
SelectTrigger$1.displayName = TRIGGER_NAME;
var VALUE_NAME = "SelectValue";
var SelectValue$1 = reactExports.forwardRef(
  (props, forwardedRef) => {
    const { __scopeSelect, className, style, children, placeholder = "", ...valueProps } = props;
    const context = useSelectContext(VALUE_NAME, __scopeSelect);
    const { onValueNodeHasChildrenChange } = context;
    const hasChildren = children !== void 0;
    const composedRefs = useComposedRefs(forwardedRef, context.onValueNodeChange);
    useLayoutEffect2(() => {
      onValueNodeHasChildrenChange(hasChildren);
    }, [onValueNodeHasChildrenChange, hasChildren]);
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Primitive.span,
      {
        ...valueProps,
        ref: composedRefs,
        style: { pointerEvents: "none" },
        children: shouldShowPlaceholder(context.value) ? /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children: placeholder }) : children
      }
    );
  }
);
SelectValue$1.displayName = VALUE_NAME;
var ICON_NAME = "SelectIcon";
var SelectIcon = reactExports.forwardRef(
  (props, forwardedRef) => {
    const { __scopeSelect, children, ...iconProps } = props;
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Primitive.span, { "aria-hidden": true, ...iconProps, ref: forwardedRef, children: children || "▼" });
  }
);
SelectIcon.displayName = ICON_NAME;
var PORTAL_NAME = "SelectPortal";
var SelectPortal$1 = (props) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(Portal$1, { asChild: true, ...props });
};
SelectPortal$1.displayName = PORTAL_NAME;
var CONTENT_NAME = "SelectContent";
var SelectContent$1 = reactExports.forwardRef(
  (props, forwardedRef) => {
    const context = useSelectContext(CONTENT_NAME, props.__scopeSelect);
    const [fragment, setFragment] = reactExports.useState();
    useLayoutEffect2(() => {
      setFragment(new DocumentFragment());
    }, []);
    if (!context.open) {
      const frag = fragment;
      return frag ? reactDomExports.createPortal(
        /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContentProvider, { scope: props.__scopeSelect, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Collection.Slot, { scope: props.__scopeSelect, children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: props.children }) }) }),
        frag
      ) : null;
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsx(SelectContentImpl, { ...props, ref: forwardedRef });
  }
);
SelectContent$1.displayName = CONTENT_NAME;
var CONTENT_MARGIN = 10;
var [SelectContentProvider, useSelectContentContext] = createSelectContext(CONTENT_NAME);
var CONTENT_IMPL_NAME = "SelectContentImpl";
var Slot = createSlot("SelectContent.RemoveScroll");
var SelectContentImpl = reactExports.forwardRef(
  (props, forwardedRef) => {
    const {
      __scopeSelect,
      position = "item-aligned",
      onCloseAutoFocus,
      onEscapeKeyDown,
      onPointerDownOutside,
      //
      // PopperContent props
      side,
      sideOffset,
      align,
      alignOffset,
      arrowPadding,
      collisionBoundary,
      collisionPadding,
      sticky,
      hideWhenDetached,
      avoidCollisions,
      //
      ...contentProps
    } = props;
    const context = useSelectContext(CONTENT_NAME, __scopeSelect);
    const [content, setContent] = reactExports.useState(null);
    const [viewport, setViewport] = reactExports.useState(null);
    const composedRefs = useComposedRefs(forwardedRef, (node) => setContent(node));
    const [selectedItem, setSelectedItem] = reactExports.useState(null);
    const [selectedItemText, setSelectedItemText] = reactExports.useState(
      null
    );
    const getItems = useCollection(__scopeSelect);
    const [isPositioned, setIsPositioned] = reactExports.useState(false);
    const firstValidItemFoundRef = reactExports.useRef(false);
    reactExports.useEffect(() => {
      if (content) return hideOthers(content);
    }, [content]);
    useFocusGuards();
    const focusFirst2 = reactExports.useCallback(
      (candidates) => {
        const [firstItem, ...restItems] = getItems().map((item) => item.ref.current);
        const [lastItem] = restItems.slice(-1);
        const PREVIOUSLY_FOCUSED_ELEMENT = document.activeElement;
        for (const candidate of candidates) {
          if (candidate === PREVIOUSLY_FOCUSED_ELEMENT) return;
          candidate == null ? void 0 : candidate.scrollIntoView({ block: "nearest" });
          if (candidate === firstItem && viewport) viewport.scrollTop = 0;
          if (candidate === lastItem && viewport) viewport.scrollTop = viewport.scrollHeight;
          candidate == null ? void 0 : candidate.focus();
          if (document.activeElement !== PREVIOUSLY_FOCUSED_ELEMENT) return;
        }
      },
      [getItems, viewport]
    );
    const focusSelectedItem = reactExports.useCallback(
      () => focusFirst2([selectedItem, content]),
      [focusFirst2, selectedItem, content]
    );
    reactExports.useEffect(() => {
      if (isPositioned) {
        focusSelectedItem();
      }
    }, [isPositioned, focusSelectedItem]);
    const { onOpenChange, triggerPointerDownPosRef } = context;
    reactExports.useEffect(() => {
      if (content) {
        let pointerMoveDelta = { x: 0, y: 0 };
        const handlePointerMove = (event) => {
          var _a, _b;
          pointerMoveDelta = {
            x: Math.abs(Math.round(event.pageX) - (((_a = triggerPointerDownPosRef.current) == null ? void 0 : _a.x) ?? 0)),
            y: Math.abs(Math.round(event.pageY) - (((_b = triggerPointerDownPosRef.current) == null ? void 0 : _b.y) ?? 0))
          };
        };
        const handlePointerUp = (event) => {
          if (pointerMoveDelta.x <= 10 && pointerMoveDelta.y <= 10) {
            event.preventDefault();
          } else {
            if (!content.contains(event.target)) {
              onOpenChange(false);
            }
          }
          document.removeEventListener("pointermove", handlePointerMove);
          triggerPointerDownPosRef.current = null;
        };
        if (triggerPointerDownPosRef.current !== null) {
          document.addEventListener("pointermove", handlePointerMove);
          document.addEventListener("pointerup", handlePointerUp, { capture: true, once: true });
        }
        return () => {
          document.removeEventListener("pointermove", handlePointerMove);
          document.removeEventListener("pointerup", handlePointerUp, { capture: true });
        };
      }
    }, [content, onOpenChange, triggerPointerDownPosRef]);
    reactExports.useEffect(() => {
      const close = () => onOpenChange(false);
      window.addEventListener("blur", close);
      window.addEventListener("resize", close);
      return () => {
        window.removeEventListener("blur", close);
        window.removeEventListener("resize", close);
      };
    }, [onOpenChange]);
    const [searchRef, handleTypeaheadSearch] = useTypeaheadSearch((search) => {
      const enabledItems = getItems().filter((item) => !item.disabled);
      const currentItem = enabledItems.find((item) => item.ref.current === document.activeElement);
      const nextItem = findNextItem(enabledItems, search, currentItem);
      if (nextItem) {
        setTimeout(() => nextItem.ref.current.focus());
      }
    });
    const itemRefCallback = reactExports.useCallback(
      (node, value, disabled) => {
        const isFirstValidItem = !firstValidItemFoundRef.current && !disabled;
        const isSelectedItem = context.value !== void 0 && context.value === value;
        if (isSelectedItem || isFirstValidItem) {
          setSelectedItem(node);
          if (isFirstValidItem) firstValidItemFoundRef.current = true;
        }
      },
      [context.value]
    );
    const handleItemLeave = reactExports.useCallback(() => content == null ? void 0 : content.focus(), [content]);
    const itemTextRefCallback = reactExports.useCallback(
      (node, value, disabled) => {
        const isFirstValidItem = !firstValidItemFoundRef.current && !disabled;
        const isSelectedItem = context.value !== void 0 && context.value === value;
        if (isSelectedItem || isFirstValidItem) {
          setSelectedItemText(node);
        }
      },
      [context.value]
    );
    const SelectPosition = position === "popper" ? SelectPopperPosition : SelectItemAlignedPosition;
    const popperContentProps = SelectPosition === SelectPopperPosition ? {
      side,
      sideOffset,
      align,
      alignOffset,
      arrowPadding,
      collisionBoundary,
      collisionPadding,
      sticky,
      hideWhenDetached,
      avoidCollisions
    } : {};
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      SelectContentProvider,
      {
        scope: __scopeSelect,
        content,
        viewport,
        onViewportChange: setViewport,
        itemRefCallback,
        selectedItem,
        onItemLeave: handleItemLeave,
        itemTextRefCallback,
        focusSelectedItem,
        selectedItemText,
        position,
        isPositioned,
        searchRef,
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(ReactRemoveScroll, { as: Slot, allowPinchZoom: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          FocusScope,
          {
            asChild: true,
            trapped: context.open,
            onMountAutoFocus: (event) => {
              event.preventDefault();
            },
            onUnmountAutoFocus: composeEventHandlers(onCloseAutoFocus, (event) => {
              var _a;
              (_a = context.trigger) == null ? void 0 : _a.focus({ preventScroll: true });
              event.preventDefault();
            }),
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              DismissableLayer,
              {
                asChild: true,
                disableOutsidePointerEvents: true,
                onEscapeKeyDown,
                onPointerDownOutside,
                onFocusOutside: (event) => event.preventDefault(),
                onDismiss: () => context.onOpenChange(false),
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  SelectPosition,
                  {
                    role: "listbox",
                    id: context.contentId,
                    "data-state": context.open ? "open" : "closed",
                    dir: context.dir,
                    onContextMenu: (event) => event.preventDefault(),
                    ...contentProps,
                    ...popperContentProps,
                    onPlaced: () => setIsPositioned(true),
                    ref: composedRefs,
                    style: {
                      // flex layout so we can place the scroll buttons properly
                      display: "flex",
                      flexDirection: "column",
                      // reset the outline by default as the content MAY get focused
                      outline: "none",
                      ...contentProps.style
                    },
                    onKeyDown: composeEventHandlers(contentProps.onKeyDown, (event) => {
                      const isModifierKey = event.ctrlKey || event.altKey || event.metaKey;
                      if (event.key === "Tab") event.preventDefault();
                      if (!isModifierKey && event.key.length === 1) handleTypeaheadSearch(event.key);
                      if (["ArrowUp", "ArrowDown", "Home", "End"].includes(event.key)) {
                        const items = getItems().filter((item) => !item.disabled);
                        let candidateNodes = items.map((item) => item.ref.current);
                        if (["ArrowUp", "End"].includes(event.key)) {
                          candidateNodes = candidateNodes.slice().reverse();
                        }
                        if (["ArrowUp", "ArrowDown"].includes(event.key)) {
                          const currentElement = event.target;
                          const currentIndex = candidateNodes.indexOf(currentElement);
                          candidateNodes = candidateNodes.slice(currentIndex + 1);
                        }
                        setTimeout(() => focusFirst2(candidateNodes));
                        event.preventDefault();
                      }
                    })
                  }
                )
              }
            )
          }
        ) })
      }
    );
  }
);
SelectContentImpl.displayName = CONTENT_IMPL_NAME;
var ITEM_ALIGNED_POSITION_NAME = "SelectItemAlignedPosition";
var SelectItemAlignedPosition = reactExports.forwardRef((props, forwardedRef) => {
  const { __scopeSelect, onPlaced, ...popperProps } = props;
  const context = useSelectContext(CONTENT_NAME, __scopeSelect);
  const contentContext = useSelectContentContext(CONTENT_NAME, __scopeSelect);
  const [contentWrapper, setContentWrapper] = reactExports.useState(null);
  const [content, setContent] = reactExports.useState(null);
  const composedRefs = useComposedRefs(forwardedRef, (node) => setContent(node));
  const getItems = useCollection(__scopeSelect);
  const shouldExpandOnScrollRef = reactExports.useRef(false);
  const shouldRepositionRef = reactExports.useRef(true);
  const { viewport, selectedItem, selectedItemText, focusSelectedItem } = contentContext;
  const position = reactExports.useCallback(() => {
    if (context.trigger && context.valueNode && contentWrapper && content && viewport && selectedItem && selectedItemText) {
      const triggerRect = context.trigger.getBoundingClientRect();
      const contentRect = content.getBoundingClientRect();
      const valueNodeRect = context.valueNode.getBoundingClientRect();
      const itemTextRect = selectedItemText.getBoundingClientRect();
      if (context.dir !== "rtl") {
        const itemTextOffset = itemTextRect.left - contentRect.left;
        const left = valueNodeRect.left - itemTextOffset;
        const leftDelta = triggerRect.left - left;
        const minContentWidth = triggerRect.width + leftDelta;
        const contentWidth = Math.max(minContentWidth, contentRect.width);
        const rightEdge = window.innerWidth - CONTENT_MARGIN;
        const clampedLeft = clamp(left, [
          CONTENT_MARGIN,
          // Prevents the content from going off the starting edge of the
          // viewport. It may still go off the ending edge, but this can be
          // controlled by the user since they may want to manage overflow in a
          // specific way.
          // https://github.com/radix-ui/primitives/issues/2049
          Math.max(CONTENT_MARGIN, rightEdge - contentWidth)
        ]);
        contentWrapper.style.minWidth = minContentWidth + "px";
        contentWrapper.style.left = clampedLeft + "px";
      } else {
        const itemTextOffset = contentRect.right - itemTextRect.right;
        const right = window.innerWidth - valueNodeRect.right - itemTextOffset;
        const rightDelta = window.innerWidth - triggerRect.right - right;
        const minContentWidth = triggerRect.width + rightDelta;
        const contentWidth = Math.max(minContentWidth, contentRect.width);
        const leftEdge = window.innerWidth - CONTENT_MARGIN;
        const clampedRight = clamp(right, [
          CONTENT_MARGIN,
          Math.max(CONTENT_MARGIN, leftEdge - contentWidth)
        ]);
        contentWrapper.style.minWidth = minContentWidth + "px";
        contentWrapper.style.right = clampedRight + "px";
      }
      const items = getItems();
      const availableHeight = window.innerHeight - CONTENT_MARGIN * 2;
      const itemsHeight = viewport.scrollHeight;
      const contentStyles = window.getComputedStyle(content);
      const contentBorderTopWidth = parseInt(contentStyles.borderTopWidth, 10);
      const contentPaddingTop = parseInt(contentStyles.paddingTop, 10);
      const contentBorderBottomWidth = parseInt(contentStyles.borderBottomWidth, 10);
      const contentPaddingBottom = parseInt(contentStyles.paddingBottom, 10);
      const fullContentHeight = contentBorderTopWidth + contentPaddingTop + itemsHeight + contentPaddingBottom + contentBorderBottomWidth;
      const minContentHeight = Math.min(selectedItem.offsetHeight * 5, fullContentHeight);
      const viewportStyles = window.getComputedStyle(viewport);
      const viewportPaddingTop = parseInt(viewportStyles.paddingTop, 10);
      const viewportPaddingBottom = parseInt(viewportStyles.paddingBottom, 10);
      const topEdgeToTriggerMiddle = triggerRect.top + triggerRect.height / 2 - CONTENT_MARGIN;
      const triggerMiddleToBottomEdge = availableHeight - topEdgeToTriggerMiddle;
      const selectedItemHalfHeight = selectedItem.offsetHeight / 2;
      const itemOffsetMiddle = selectedItem.offsetTop + selectedItemHalfHeight;
      const contentTopToItemMiddle = contentBorderTopWidth + contentPaddingTop + itemOffsetMiddle;
      const itemMiddleToContentBottom = fullContentHeight - contentTopToItemMiddle;
      const willAlignWithoutTopOverflow = contentTopToItemMiddle <= topEdgeToTriggerMiddle;
      if (willAlignWithoutTopOverflow) {
        const isLastItem = items.length > 0 && selectedItem === items[items.length - 1].ref.current;
        contentWrapper.style.bottom = "0px";
        const viewportOffsetBottom = content.clientHeight - viewport.offsetTop - viewport.offsetHeight;
        const clampedTriggerMiddleToBottomEdge = Math.max(
          triggerMiddleToBottomEdge,
          selectedItemHalfHeight + // viewport might have padding bottom, include it to avoid a scrollable viewport
          (isLastItem ? viewportPaddingBottom : 0) + viewportOffsetBottom + contentBorderBottomWidth
        );
        const height = contentTopToItemMiddle + clampedTriggerMiddleToBottomEdge;
        contentWrapper.style.height = height + "px";
      } else {
        const isFirstItem = items.length > 0 && selectedItem === items[0].ref.current;
        contentWrapper.style.top = "0px";
        const clampedTopEdgeToTriggerMiddle = Math.max(
          topEdgeToTriggerMiddle,
          contentBorderTopWidth + viewport.offsetTop + // viewport might have padding top, include it to avoid a scrollable viewport
          (isFirstItem ? viewportPaddingTop : 0) + selectedItemHalfHeight
        );
        const height = clampedTopEdgeToTriggerMiddle + itemMiddleToContentBottom;
        contentWrapper.style.height = height + "px";
        viewport.scrollTop = contentTopToItemMiddle - topEdgeToTriggerMiddle + viewport.offsetTop;
      }
      contentWrapper.style.margin = `${CONTENT_MARGIN}px 0`;
      contentWrapper.style.minHeight = minContentHeight + "px";
      contentWrapper.style.maxHeight = availableHeight + "px";
      onPlaced == null ? void 0 : onPlaced();
      requestAnimationFrame(() => shouldExpandOnScrollRef.current = true);
    }
  }, [
    getItems,
    context.trigger,
    context.valueNode,
    contentWrapper,
    content,
    viewport,
    selectedItem,
    selectedItemText,
    context.dir,
    onPlaced
  ]);
  useLayoutEffect2(() => position(), [position]);
  const [contentZIndex, setContentZIndex] = reactExports.useState();
  useLayoutEffect2(() => {
    if (content) setContentZIndex(window.getComputedStyle(content).zIndex);
  }, [content]);
  const handleScrollButtonChange = reactExports.useCallback(
    (node) => {
      if (node && shouldRepositionRef.current === true) {
        position();
        focusSelectedItem == null ? void 0 : focusSelectedItem();
        shouldRepositionRef.current = false;
      }
    },
    [position, focusSelectedItem]
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    SelectViewportProvider,
    {
      scope: __scopeSelect,
      contentWrapper,
      shouldExpandOnScrollRef,
      onScrollButtonChange: handleScrollButtonChange,
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          ref: setContentWrapper,
          style: {
            display: "flex",
            flexDirection: "column",
            position: "fixed",
            zIndex: contentZIndex
          },
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            Primitive.div,
            {
              ...popperProps,
              ref: composedRefs,
              style: {
                // When we get the height of the content, it includes borders. If we were to set
                // the height without having `boxSizing: 'border-box'` it would be too big.
                boxSizing: "border-box",
                // We need to ensure the content doesn't get taller than the wrapper
                maxHeight: "100%",
                ...popperProps.style
              }
            }
          )
        }
      )
    }
  );
});
SelectItemAlignedPosition.displayName = ITEM_ALIGNED_POSITION_NAME;
var POPPER_POSITION_NAME = "SelectPopperPosition";
var SelectPopperPosition = reactExports.forwardRef((props, forwardedRef) => {
  const {
    __scopeSelect,
    align = "start",
    collisionPadding = CONTENT_MARGIN,
    ...popperProps
  } = props;
  const popperScope = usePopperScope(__scopeSelect);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Content$1,
    {
      ...popperScope,
      ...popperProps,
      ref: forwardedRef,
      align,
      collisionPadding,
      style: {
        // Ensure border-box for floating-ui calculations
        boxSizing: "border-box",
        ...popperProps.style,
        // re-namespace exposed content custom properties
        ...{
          "--radix-select-content-transform-origin": "var(--radix-popper-transform-origin)",
          "--radix-select-content-available-width": "var(--radix-popper-available-width)",
          "--radix-select-content-available-height": "var(--radix-popper-available-height)",
          "--radix-select-trigger-width": "var(--radix-popper-anchor-width)",
          "--radix-select-trigger-height": "var(--radix-popper-anchor-height)"
        }
      }
    }
  );
});
SelectPopperPosition.displayName = POPPER_POSITION_NAME;
var [SelectViewportProvider, useSelectViewportContext] = createSelectContext(CONTENT_NAME, {});
var VIEWPORT_NAME = "SelectViewport";
var SelectViewport = reactExports.forwardRef(
  (props, forwardedRef) => {
    const { __scopeSelect, nonce, ...viewportProps } = props;
    const contentContext = useSelectContentContext(VIEWPORT_NAME, __scopeSelect);
    const viewportContext = useSelectViewportContext(VIEWPORT_NAME, __scopeSelect);
    const composedRefs = useComposedRefs(forwardedRef, contentContext.onViewportChange);
    const prevScrollTopRef = reactExports.useRef(0);
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "style",
        {
          dangerouslySetInnerHTML: {
            __html: `[data-radix-select-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-select-viewport]::-webkit-scrollbar{display:none}`
          },
          nonce
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(Collection.Slot, { scope: __scopeSelect, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        Primitive.div,
        {
          "data-radix-select-viewport": "",
          role: "presentation",
          ...viewportProps,
          ref: composedRefs,
          style: {
            // we use position: 'relative' here on the `viewport` so that when we call
            // `selectedItem.offsetTop` in calculations, the offset is relative to the viewport
            // (independent of the scrollUpButton).
            position: "relative",
            flex: 1,
            // Viewport should only be scrollable in the vertical direction.
            // This won't work in vertical writing modes, so we'll need to
            // revisit this if/when that is supported
            // https://developer.chrome.com/blog/vertical-form-controls
            overflow: "hidden auto",
            ...viewportProps.style
          },
          onScroll: composeEventHandlers(viewportProps.onScroll, (event) => {
            const viewport = event.currentTarget;
            const { contentWrapper, shouldExpandOnScrollRef } = viewportContext;
            if ((shouldExpandOnScrollRef == null ? void 0 : shouldExpandOnScrollRef.current) && contentWrapper) {
              const scrolledBy = Math.abs(prevScrollTopRef.current - viewport.scrollTop);
              if (scrolledBy > 0) {
                const availableHeight = window.innerHeight - CONTENT_MARGIN * 2;
                const cssMinHeight = parseFloat(contentWrapper.style.minHeight);
                const cssHeight = parseFloat(contentWrapper.style.height);
                const prevHeight = Math.max(cssMinHeight, cssHeight);
                if (prevHeight < availableHeight) {
                  const nextHeight = prevHeight + scrolledBy;
                  const clampedNextHeight = Math.min(availableHeight, nextHeight);
                  const heightDiff = nextHeight - clampedNextHeight;
                  contentWrapper.style.height = clampedNextHeight + "px";
                  if (contentWrapper.style.bottom === "0px") {
                    viewport.scrollTop = heightDiff > 0 ? heightDiff : 0;
                    contentWrapper.style.justifyContent = "flex-end";
                  }
                }
              }
            }
            prevScrollTopRef.current = viewport.scrollTop;
          })
        }
      ) })
    ] });
  }
);
SelectViewport.displayName = VIEWPORT_NAME;
var GROUP_NAME = "SelectGroup";
var [SelectGroupContextProvider, useSelectGroupContext] = createSelectContext(GROUP_NAME);
var SelectGroup = reactExports.forwardRef(
  (props, forwardedRef) => {
    const { __scopeSelect, ...groupProps } = props;
    const groupId = useId();
    return /* @__PURE__ */ jsxRuntimeExports.jsx(SelectGroupContextProvider, { scope: __scopeSelect, id: groupId, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Primitive.div, { role: "group", "aria-labelledby": groupId, ...groupProps, ref: forwardedRef }) });
  }
);
SelectGroup.displayName = GROUP_NAME;
var LABEL_NAME = "SelectLabel";
var SelectLabel$1 = reactExports.forwardRef(
  (props, forwardedRef) => {
    const { __scopeSelect, ...labelProps } = props;
    const groupContext = useSelectGroupContext(LABEL_NAME, __scopeSelect);
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Primitive.div, { id: groupContext.id, ...labelProps, ref: forwardedRef });
  }
);
SelectLabel$1.displayName = LABEL_NAME;
var ITEM_NAME = "SelectItem";
var [SelectItemContextProvider, useSelectItemContext] = createSelectContext(ITEM_NAME);
var SelectItem$1 = reactExports.forwardRef(
  (props, forwardedRef) => {
    const {
      __scopeSelect,
      value,
      disabled = false,
      textValue: textValueProp,
      ...itemProps
    } = props;
    const context = useSelectContext(ITEM_NAME, __scopeSelect);
    const contentContext = useSelectContentContext(ITEM_NAME, __scopeSelect);
    const isSelected = context.value === value;
    const [textValue, setTextValue] = reactExports.useState(textValueProp ?? "");
    const [isFocused, setIsFocused] = reactExports.useState(false);
    const composedRefs = useComposedRefs(
      forwardedRef,
      (node) => {
        var _a;
        return (_a = contentContext.itemRefCallback) == null ? void 0 : _a.call(contentContext, node, value, disabled);
      }
    );
    const textId = useId();
    const pointerTypeRef = reactExports.useRef("touch");
    const handleSelect = () => {
      if (!disabled) {
        context.onValueChange(value);
        context.onOpenChange(false);
      }
    };
    if (value === "") {
      throw new Error(
        "A <Select.Item /> must have a value prop that is not an empty string. This is because the Select value can be set to an empty string to clear the selection and show the placeholder."
      );
    }
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      SelectItemContextProvider,
      {
        scope: __scopeSelect,
        value,
        disabled,
        textId,
        isSelected,
        onItemTextChange: reactExports.useCallback((node) => {
          setTextValue((prevTextValue) => prevTextValue || ((node == null ? void 0 : node.textContent) ?? "").trim());
        }, []),
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          Collection.ItemSlot,
          {
            scope: __scopeSelect,
            value,
            disabled,
            textValue,
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              Primitive.div,
              {
                role: "option",
                "aria-labelledby": textId,
                "data-highlighted": isFocused ? "" : void 0,
                "aria-selected": isSelected && isFocused,
                "data-state": isSelected ? "checked" : "unchecked",
                "aria-disabled": disabled || void 0,
                "data-disabled": disabled ? "" : void 0,
                tabIndex: disabled ? void 0 : -1,
                ...itemProps,
                ref: composedRefs,
                onFocus: composeEventHandlers(itemProps.onFocus, () => setIsFocused(true)),
                onBlur: composeEventHandlers(itemProps.onBlur, () => setIsFocused(false)),
                onClick: composeEventHandlers(itemProps.onClick, () => {
                  if (pointerTypeRef.current !== "mouse") handleSelect();
                }),
                onPointerUp: composeEventHandlers(itemProps.onPointerUp, () => {
                  if (pointerTypeRef.current === "mouse") handleSelect();
                }),
                onPointerDown: composeEventHandlers(itemProps.onPointerDown, (event) => {
                  pointerTypeRef.current = event.pointerType;
                }),
                onPointerMove: composeEventHandlers(itemProps.onPointerMove, (event) => {
                  var _a;
                  pointerTypeRef.current = event.pointerType;
                  if (disabled) {
                    (_a = contentContext.onItemLeave) == null ? void 0 : _a.call(contentContext);
                  } else if (pointerTypeRef.current === "mouse") {
                    event.currentTarget.focus({ preventScroll: true });
                  }
                }),
                onPointerLeave: composeEventHandlers(itemProps.onPointerLeave, (event) => {
                  var _a;
                  if (event.currentTarget === document.activeElement) {
                    (_a = contentContext.onItemLeave) == null ? void 0 : _a.call(contentContext);
                  }
                }),
                onKeyDown: composeEventHandlers(itemProps.onKeyDown, (event) => {
                  var _a;
                  const isTypingAhead = ((_a = contentContext.searchRef) == null ? void 0 : _a.current) !== "";
                  if (isTypingAhead && event.key === " ") return;
                  if (SELECTION_KEYS.includes(event.key)) handleSelect();
                  if (event.key === " ") event.preventDefault();
                })
              }
            )
          }
        )
      }
    );
  }
);
SelectItem$1.displayName = ITEM_NAME;
var ITEM_TEXT_NAME = "SelectItemText";
var SelectItemText = reactExports.forwardRef(
  (props, forwardedRef) => {
    const { __scopeSelect, className, style, ...itemTextProps } = props;
    const context = useSelectContext(ITEM_TEXT_NAME, __scopeSelect);
    const contentContext = useSelectContentContext(ITEM_TEXT_NAME, __scopeSelect);
    const itemContext = useSelectItemContext(ITEM_TEXT_NAME, __scopeSelect);
    const nativeOptionsContext = useSelectNativeOptionsContext(ITEM_TEXT_NAME, __scopeSelect);
    const [itemTextNode, setItemTextNode] = reactExports.useState(null);
    const composedRefs = useComposedRefs(
      forwardedRef,
      (node) => setItemTextNode(node),
      itemContext.onItemTextChange,
      (node) => {
        var _a;
        return (_a = contentContext.itemTextRefCallback) == null ? void 0 : _a.call(contentContext, node, itemContext.value, itemContext.disabled);
      }
    );
    const textContent = itemTextNode == null ? void 0 : itemTextNode.textContent;
    const nativeOption = reactExports.useMemo(
      () => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: itemContext.value, disabled: itemContext.disabled, children: textContent }, itemContext.value),
      [itemContext.disabled, itemContext.value, textContent]
    );
    const { onNativeOptionAdd, onNativeOptionRemove } = nativeOptionsContext;
    useLayoutEffect2(() => {
      onNativeOptionAdd(nativeOption);
      return () => onNativeOptionRemove(nativeOption);
    }, [onNativeOptionAdd, onNativeOptionRemove, nativeOption]);
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Primitive.span, { id: itemContext.textId, ...itemTextProps, ref: composedRefs }),
      itemContext.isSelected && context.valueNode && !context.valueNodeHasChildren ? reactDomExports.createPortal(itemTextProps.children, context.valueNode) : null
    ] });
  }
);
SelectItemText.displayName = ITEM_TEXT_NAME;
var ITEM_INDICATOR_NAME = "SelectItemIndicator";
var SelectItemIndicator = reactExports.forwardRef(
  (props, forwardedRef) => {
    const { __scopeSelect, ...itemIndicatorProps } = props;
    const itemContext = useSelectItemContext(ITEM_INDICATOR_NAME, __scopeSelect);
    return itemContext.isSelected ? /* @__PURE__ */ jsxRuntimeExports.jsx(Primitive.span, { "aria-hidden": true, ...itemIndicatorProps, ref: forwardedRef }) : null;
  }
);
SelectItemIndicator.displayName = ITEM_INDICATOR_NAME;
var SCROLL_UP_BUTTON_NAME = "SelectScrollUpButton";
var SelectScrollUpButton$1 = reactExports.forwardRef((props, forwardedRef) => {
  const contentContext = useSelectContentContext(SCROLL_UP_BUTTON_NAME, props.__scopeSelect);
  const viewportContext = useSelectViewportContext(SCROLL_UP_BUTTON_NAME, props.__scopeSelect);
  const [canScrollUp, setCanScrollUp] = reactExports.useState(false);
  const composedRefs = useComposedRefs(forwardedRef, viewportContext.onScrollButtonChange);
  useLayoutEffect2(() => {
    if (contentContext.viewport && contentContext.isPositioned) {
      let handleScroll2 = function() {
        const canScrollUp2 = viewport.scrollTop > 0;
        setCanScrollUp(canScrollUp2);
      };
      const viewport = contentContext.viewport;
      handleScroll2();
      viewport.addEventListener("scroll", handleScroll2);
      return () => viewport.removeEventListener("scroll", handleScroll2);
    }
  }, [contentContext.viewport, contentContext.isPositioned]);
  return canScrollUp ? /* @__PURE__ */ jsxRuntimeExports.jsx(
    SelectScrollButtonImpl,
    {
      ...props,
      ref: composedRefs,
      onAutoScroll: () => {
        const { viewport, selectedItem } = contentContext;
        if (viewport && selectedItem) {
          viewport.scrollTop = viewport.scrollTop - selectedItem.offsetHeight;
        }
      }
    }
  ) : null;
});
SelectScrollUpButton$1.displayName = SCROLL_UP_BUTTON_NAME;
var SCROLL_DOWN_BUTTON_NAME = "SelectScrollDownButton";
var SelectScrollDownButton$1 = reactExports.forwardRef((props, forwardedRef) => {
  const contentContext = useSelectContentContext(SCROLL_DOWN_BUTTON_NAME, props.__scopeSelect);
  const viewportContext = useSelectViewportContext(SCROLL_DOWN_BUTTON_NAME, props.__scopeSelect);
  const [canScrollDown, setCanScrollDown] = reactExports.useState(false);
  const composedRefs = useComposedRefs(forwardedRef, viewportContext.onScrollButtonChange);
  useLayoutEffect2(() => {
    if (contentContext.viewport && contentContext.isPositioned) {
      let handleScroll2 = function() {
        const maxScroll = viewport.scrollHeight - viewport.clientHeight;
        const canScrollDown2 = Math.ceil(viewport.scrollTop) < maxScroll;
        setCanScrollDown(canScrollDown2);
      };
      const viewport = contentContext.viewport;
      handleScroll2();
      viewport.addEventListener("scroll", handleScroll2);
      return () => viewport.removeEventListener("scroll", handleScroll2);
    }
  }, [contentContext.viewport, contentContext.isPositioned]);
  return canScrollDown ? /* @__PURE__ */ jsxRuntimeExports.jsx(
    SelectScrollButtonImpl,
    {
      ...props,
      ref: composedRefs,
      onAutoScroll: () => {
        const { viewport, selectedItem } = contentContext;
        if (viewport && selectedItem) {
          viewport.scrollTop = viewport.scrollTop + selectedItem.offsetHeight;
        }
      }
    }
  ) : null;
});
SelectScrollDownButton$1.displayName = SCROLL_DOWN_BUTTON_NAME;
var SelectScrollButtonImpl = reactExports.forwardRef((props, forwardedRef) => {
  const { __scopeSelect, onAutoScroll, ...scrollIndicatorProps } = props;
  const contentContext = useSelectContentContext("SelectScrollButton", __scopeSelect);
  const autoScrollTimerRef = reactExports.useRef(null);
  const getItems = useCollection(__scopeSelect);
  const clearAutoScrollTimer = reactExports.useCallback(() => {
    if (autoScrollTimerRef.current !== null) {
      window.clearInterval(autoScrollTimerRef.current);
      autoScrollTimerRef.current = null;
    }
  }, []);
  reactExports.useEffect(() => {
    return () => clearAutoScrollTimer();
  }, [clearAutoScrollTimer]);
  useLayoutEffect2(() => {
    var _a;
    const activeItem = getItems().find((item) => item.ref.current === document.activeElement);
    (_a = activeItem == null ? void 0 : activeItem.ref.current) == null ? void 0 : _a.scrollIntoView({ block: "nearest" });
  }, [getItems]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Primitive.div,
    {
      "aria-hidden": true,
      ...scrollIndicatorProps,
      ref: forwardedRef,
      style: { flexShrink: 0, ...scrollIndicatorProps.style },
      onPointerDown: composeEventHandlers(scrollIndicatorProps.onPointerDown, () => {
        if (autoScrollTimerRef.current === null) {
          autoScrollTimerRef.current = window.setInterval(onAutoScroll, 50);
        }
      }),
      onPointerMove: composeEventHandlers(scrollIndicatorProps.onPointerMove, () => {
        var _a;
        (_a = contentContext.onItemLeave) == null ? void 0 : _a.call(contentContext);
        if (autoScrollTimerRef.current === null) {
          autoScrollTimerRef.current = window.setInterval(onAutoScroll, 50);
        }
      }),
      onPointerLeave: composeEventHandlers(scrollIndicatorProps.onPointerLeave, () => {
        clearAutoScrollTimer();
      })
    }
  );
});
var SEPARATOR_NAME = "SelectSeparator";
var SelectSeparator$1 = reactExports.forwardRef(
  (props, forwardedRef) => {
    const { __scopeSelect, ...separatorProps } = props;
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Primitive.div, { "aria-hidden": true, ...separatorProps, ref: forwardedRef });
  }
);
SelectSeparator$1.displayName = SEPARATOR_NAME;
var ARROW_NAME = "SelectArrow";
var SelectArrow = reactExports.forwardRef(
  (props, forwardedRef) => {
    const { __scopeSelect, ...arrowProps } = props;
    const popperScope = usePopperScope(__scopeSelect);
    const context = useSelectContext(ARROW_NAME, __scopeSelect);
    const contentContext = useSelectContentContext(ARROW_NAME, __scopeSelect);
    return context.open && contentContext.position === "popper" ? /* @__PURE__ */ jsxRuntimeExports.jsx(Arrow, { ...popperScope, ...arrowProps, ref: forwardedRef }) : null;
  }
);
SelectArrow.displayName = ARROW_NAME;
var BUBBLE_INPUT_NAME = "SelectBubbleInput";
var SelectBubbleInput = reactExports.forwardRef(
  ({ __scopeSelect, value, ...props }, forwardedRef) => {
    const ref = reactExports.useRef(null);
    const composedRefs = useComposedRefs(forwardedRef, ref);
    const prevValue = usePrevious(value);
    reactExports.useEffect(() => {
      const select = ref.current;
      if (!select) return;
      const selectProto = window.HTMLSelectElement.prototype;
      const descriptor = Object.getOwnPropertyDescriptor(
        selectProto,
        "value"
      );
      const setValue = descriptor.set;
      if (prevValue !== value && setValue) {
        const event = new Event("change", { bubbles: true });
        setValue.call(select, value);
        select.dispatchEvent(event);
      }
    }, [prevValue, value]);
    return /* @__PURE__ */ jsxRuntimeExports.jsx(
      Primitive.select,
      {
        ...props,
        style: { ...VISUALLY_HIDDEN_STYLES, ...props.style },
        ref: composedRefs,
        defaultValue: value
      }
    );
  }
);
SelectBubbleInput.displayName = BUBBLE_INPUT_NAME;
function shouldShowPlaceholder(value) {
  return value === "" || value === void 0;
}
function useTypeaheadSearch(onSearchChange) {
  const handleSearchChange = useCallbackRef$1(onSearchChange);
  const searchRef = reactExports.useRef("");
  const timerRef = reactExports.useRef(0);
  const handleTypeaheadSearch = reactExports.useCallback(
    (key) => {
      const search = searchRef.current + key;
      handleSearchChange(search);
      (function updateSearch(value) {
        searchRef.current = value;
        window.clearTimeout(timerRef.current);
        if (value !== "") timerRef.current = window.setTimeout(() => updateSearch(""), 1e3);
      })(search);
    },
    [handleSearchChange]
  );
  const resetTypeahead = reactExports.useCallback(() => {
    searchRef.current = "";
    window.clearTimeout(timerRef.current);
  }, []);
  reactExports.useEffect(() => {
    return () => window.clearTimeout(timerRef.current);
  }, []);
  return [searchRef, handleTypeaheadSearch, resetTypeahead];
}
function findNextItem(items, search, currentItem) {
  const isRepeated = search.length > 1 && Array.from(search).every((char) => char === search[0]);
  const normalizedSearch = isRepeated ? search[0] : search;
  const currentItemIndex = currentItem ? items.indexOf(currentItem) : -1;
  let wrappedItems = wrapArray(items, Math.max(currentItemIndex, 0));
  const excludeCurrentItem = normalizedSearch.length === 1;
  if (excludeCurrentItem) wrappedItems = wrappedItems.filter((v) => v !== currentItem);
  const nextItem = wrappedItems.find(
    (item) => item.textValue.toLowerCase().startsWith(normalizedSearch.toLowerCase())
  );
  return nextItem !== currentItem ? nextItem : void 0;
}
function wrapArray(array, startIndex) {
  return array.map((_, index) => array[(startIndex + index) % array.length]);
}
var Root2 = Select$1;
var Trigger = SelectTrigger$1;
var Value = SelectValue$1;
var Icon = SelectIcon;
var Portal = SelectPortal$1;
var Content2 = SelectContent$1;
var Viewport = SelectViewport;
var Label = SelectLabel$1;
var Item = SelectItem$1;
var ItemText = SelectItemText;
var ItemIndicator = SelectItemIndicator;
var ScrollUpButton = SelectScrollUpButton$1;
var ScrollDownButton = SelectScrollDownButton$1;
var Separator = SelectSeparator$1;
const Select = Root2;
const SelectValue = Value;
const SelectPortal = ({ children, ...props }) => {
  const shadowRoot = useShadowRoot();
  console.log("shadowRoot", shadowRoot);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Portal,
    {
      ...props,
      container: shadowRoot || void 0,
      children
    }
  );
};
const SelectTrigger = reactExports.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
  Trigger,
  {
    ref,
    className: cn(
      "jd-flex jd-h-9 jd-w-full jd-items-center jd-justify-between jd-whitespace-nowrap jd-rounded-md jd-border jd-border-input jd-bg-transparent jd-px-3 jd-py-2 jd-text-sm jd-shadow-sm jd-ring-offset-background data-[placeholder]:jd-text-muted-foreground focus:jd-outline-none focus:jd-ring-1 focus:jd-ring-ring disabled:jd-cursor-not-allowed disabled:jd-opacity-50 [&>span]:jd-line-clamp-1",
      className
    ),
    ...props,
    children: [
      children,
      /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "jd-h-4 jd-w-4 jd-opacity-50" }) })
    ]
  }
));
SelectTrigger.displayName = Trigger.displayName;
const SelectScrollUpButton = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  ScrollUpButton,
  {
    ref,
    className: cn(
      "jd-flex jd-cursor-default jd-items-center jd-justify-center jd-py-1",
      className
    ),
    ...props,
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronUp, { className: "jd-h-4 jd-w-4" })
  }
));
SelectScrollUpButton.displayName = ScrollUpButton.displayName;
const SelectScrollDownButton = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  ScrollDownButton,
  {
    ref,
    className: cn(
      "jd-flex jd-cursor-default jd-items-center jd-justify-center jd-py-1",
      className
    ),
    ...props,
    children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "jd-h-4 jd-w-4" })
  }
));
SelectScrollDownButton.displayName = ScrollDownButton.displayName;
const SelectContent = reactExports.forwardRef(({ className, children, position = "popper", ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(SelectPortal, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
  Content2,
  {
    ref,
    className: cn(
      "jd-relative jd-z-[10002] jd-max-h-[--radix-select-content-available-height] jd-min-w-[8rem] jd-overflow-y-auto jd-overflow-x-hidden jd-rounded-md jd-border jd-bg-popover jd-text-popover-foreground jd-shadow-md data-[state=open]:jd-animate-in data-[state=closed]:jd-animate-out data-[state=closed]:jd-fade-out-0 data-[state=open]:jd-fade-in-0 data-[state=closed]:jd-zoom-out-95 data-[state=open]:jd-zoom-in-95 data-[side=bottom]:jd-slide-in-from-top-2 data-[side=left]:jd-slide-in-from-right-2 data-[side=right]:jd-slide-in-from-left-2 data-[side=top]:jd-slide-in-from-bottom-2 jd-origin-[--radix-select-content-transform-origin]",
      position === "popper" && "data-[side=bottom]:jd-translate-y-1 data-[side=left]:jd-translate-x-1 data-[side=right]:jd-translate-x-1 data-[side=top]:jd-translate-y-1",
      className
    ),
    position,
    ...props,
    children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(SelectScrollUpButton, {}),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        Viewport,
        {
          className: cn(
            "jd-p-1",
            position === "popper" && "jd-h-[var(--radix-select-trigger-height)] jd-w-full jd-min-w-[var(--radix-select-trigger-width)]"
          ),
          children
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(SelectScrollDownButton, {})
    ]
  }
) }));
SelectContent.displayName = Content2.displayName;
const SelectLabel = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Label,
  {
    ref,
    className: cn("jd-px-2 jd-py-1.5 jd-text-sm jd-font-semibold", className),
    ...props
  }
));
SelectLabel.displayName = Label.displayName;
const SelectItem = reactExports.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
  Item,
  {
    ref,
    className: cn(
      "jd-relative jd-flex jd-w-full jd-cursor-default jd-select-none jd-items-center jd-rounded-sm jd-py-1.5 jd-pl-2 jd-pr-8 jd-text-sm jd-outline-none focus:jd-bg-accent focus:jd-text-accent-foreground data-[disabled]:jd-pointer-events-none data-[disabled]:jd-opacity-50",
      className
    ),
    ...props,
    children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "jd-absolute jd-right-2 jd-flex jd-h-3.5 jd-w-3.5 jd-items-center jd-justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ItemIndicator, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Check, { className: "jd-h-4 jd-w-4" }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(ItemText, { children })
    ]
  }
));
SelectItem.displayName = Item.displayName;
const SelectSeparator = reactExports.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ jsxRuntimeExports.jsx(
  Separator,
  {
    ref,
    className: cn("jd-mx-1 jd-my-1 jd-h-px jd-bg-muted", className),
    ...props
  }
));
SelectSeparator.displayName = Separator.displayName;
const Textarea = reactExports.forwardRef(({ className, ...props }, ref) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "textarea",
    {
      className: cn(
        "jd-flex jd-min-h-[80px] jd-w-full jd-rounded-md jd-border jd-border-input jd-bg-background jd-px-3 jd-py-2 jd-text-base jd-ring-offset-background placeholder:jd-text-muted-foreground jd-focus-visible:outline-none jd-focus-visible:ring-2 jd-focus-visible:ring-ring jd-focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 md:jd-text-sm",
        className
      ),
      ref,
      ...props
    }
  );
});
Textarea.displayName = "Textarea";
const _MessageService = class _MessageService extends AbstractBaseService {
  // ms
  constructor() {
    super();
    __publicField(this, "queue", []);
    __publicField(this, "processing", false);
    __publicField(this, "timer", null);
    __publicField(this, "processed", /* @__PURE__ */ new Set());
    __publicField(this, "batchSize", 5);
    __publicField(this, "flushInterval", 100);
    /**
     * Handle extracted message event
     */
    __publicField(this, "handleExtractedMessage", (event) => {
      const { message } = event.detail;
      if (message) {
        if (!message.conversationId || message.conversationId === "") {
          message.conversationId = chatService.getCurrentConversationId() || "";
        }
        this.queueMessage(message);
        if (message.role === "user") {
          emitEvent(AppEvent.CHAT_MESSAGE_SENT, {
            messageId: message.messageId,
            content: message.content,
            conversationId: message.conversationId
          });
        } else if (message.role === "assistant") {
          emitEvent(AppEvent.CHAT_MESSAGE_RECEIVED, {
            messageId: message.messageId,
            content: message.content,
            role: message.role,
            conversationId: message.conversationId
          });
        }
      }
    });
  }
  static getInstance() {
    if (!_MessageService.instance) {
      _MessageService.instance = new _MessageService();
    }
    return _MessageService.instance;
  }
  async onInitialize() {
    debug("Initializing MessageService");
    document.addEventListener("jaydai:message-extracted", this.handleExtractedMessage);
  }
  onCleanup() {
    if (this.timer !== null) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    document.removeEventListener("jaydai:message-extracted", this.handleExtractedMessage);
    debug("MessageService cleaned up");
  }
  /**
   * Queue a message for saving
   */
  queueMessage(message) {
    console.log("Queueing message:", message);
    if (this.processed.has(message.messageId)) {
      return;
    }
    if (message.conversationId && message.conversationId !== "") {
      this.processed.add(message.messageId);
    }
    this.queue.push(message);
    if (!this.processing) {
      this.processQueue();
    }
  }
  /**
   * Process the message queue
   */
  processQueue() {
    if (this.timer !== null) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    if (this.queue.length === 0) {
      this.processing = false;
      return;
    }
    this.processing = true;
    const messagesToProcess = [];
    const remainingMessages = [];
    this.queue.forEach((message) => {
      if (!message.conversationId || message.conversationId === "") {
        console.log("No conversation IDDDDDDDD found for message:", message);
        const currentConversationId = chatService.getCurrentConversationId();
        console.log("Current conversation ID:", currentConversationId);
        if (currentConversationId) {
          message.conversationId = currentConversationId;
        }
      }
      if (message.conversationId && message.conversationId !== "") {
        messagesToProcess.push(message);
        if (!this.processed.has(message.messageId)) {
          this.processed.add(message.messageId);
        }
      } else {
        remainingMessages.push(message);
      }
    });
    this.queue = remainingMessages;
    if (messagesToProcess.length > 0) {
      this.saveBatch(messagesToProcess).finally(() => {
        this.timer = window.setTimeout(() => this.processQueue(), this.flushInterval);
      });
    } else if (remainingMessages.length > 0) {
      this.timer = window.setTimeout(() => this.processQueue(), this.flushInterval);
    } else {
      this.processing = false;
    }
  }
  /**
   * Save a batch of messages
   */
  async saveBatch(messages) {
    if (messages.length === 0) return;
    try {
      const formattedMessages = messages.map((msg) => ({
        message_provider_id: msg.messageId,
        chat_provider_id: msg.conversationId,
        content: msg.content,
        role: msg.role,
        parent_message_provider_id: msg.parent_message_provider_id,
        model: msg.model || "unknown",
        created_at: msg.timestamp
      }));
      await messageApi.saveMessageBatch(formattedMessages);
      debug(`Saved batch of ${messages.length} messages`);
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error saving message batch", ErrorCode.API_ERROR, error)
      );
    }
  }
};
__publicField(_MessageService, "instance");
let MessageService = _MessageService;
MessageService.getInstance();
class NotificationApi {
  /**
   * Fetch all notifications
   */
  async fetchNotifications() {
    try {
      return await apiClient.request("/notifications/");
    } catch (error) {
      console.error("Error fetching notifications:", error);
      return [];
    }
  }
  /**
   * Fetch unread notifications
   */
  async fetchUnreadNotifications() {
    try {
      return await apiClient.request("/notifications/unread");
    } catch (error) {
      console.error("Error fetching unread notifications:", error);
      return [];
    }
  }
  /**
   * Mark a notification as read
   */
  async markNotificationRead(notificationId) {
    return apiClient.request(`/notifications/${notificationId}/read`, {
      method: "POST"
    });
  }
  /**
   * Mark all notifications as read
   */
  async markAllNotificationsRead() {
    return apiClient.request("/notifications/read-all", {
      method: "POST"
    });
  }
  /**
   * Get notification counts
   */
  async getNotificationCountsResponse() {
    return apiClient.request("/notifications/count");
  }
  /**
   * Delete a notification
   */
  async deleteNotification(notificationId) {
    return apiClient.request(`/notifications/${notificationId}`, {
      method: "DELETE"
    });
  }
}
const notificationApi = new NotificationApi();
const _NotificationService = class _NotificationService extends AbstractBaseService {
  constructor() {
    super();
    __publicField(this, "notifications", []);
    __publicField(this, "isLoading", false);
    __publicField(this, "lastLoadTime", 0);
    __publicField(this, "pollingInterval", null);
    __publicField(this, "updateCallbacks", []);
    __publicField(this, "unreadCount", 0);
  }
  /**
   * Get the singleton instance
   */
  static getInstance() {
    if (!_NotificationService.instance) {
      _NotificationService.instance = new _NotificationService();
    }
    return _NotificationService.instance;
  }
  /**
   * Initialize the notification service
   */
  async onInitialize() {
    debug("🔔 Initializing notification service...");
    await this.loadNotifications();
    this.startPolling();
    debug("✅ Notification service initialized");
  }
  /**
   * Clean up resources
   */
  onCleanup() {
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
      this.pollingInterval = null;
    }
    this.updateCallbacks = [];
    debug("✅ Notification service cleaned up");
  }
  /**
   * Load notifications from backend
   */
  async loadNotifications(forceRefresh = false) {
    const now = Date.now();
    if (!forceRefresh && this.lastLoadTime > 0 && now - this.lastLoadTime < 6e5) {
      return [...this.notifications];
    }
    if (this.isLoading) {
      return [...this.notifications];
    }
    this.isLoading = true;
    try {
      debug("🔔 Loading notifications...");
      const previousUnreadCount = this.getUnreadCount();
      const notifications = await notificationApi.fetchNotifications();
      if (notifications) {
        this.notifications = this.localizeNotifications(notifications);
        this.lastLoadTime = now;
        const newUnreadCount = this.getUnreadCount();
        debug(`✅ Loaded ${this.notifications.length} notifications (${newUnreadCount} unread)`);
        if (newUnreadCount > previousUnreadCount) {
          const newCount = newUnreadCount - previousUnreadCount;
          this.showNewNotificationsToast(newCount);
        }
        this.updateBadge();
        this.notifyUpdateListeners();
        emitEvent(AppEvent.NOTIFICATION_COUNT_UPDATED, { count: newUnreadCount });
      }
    } catch (error) {
      debug("❌ Error loading notifications:", error);
    } finally {
      this.isLoading = false;
    }
    return [...this.notifications];
  }
  /**
   * Apply localization to notifications
   */
  localizeNotifications(notifications) {
    return notifications.map((notification) => {
      const localizedTitle = getMessage(notification.title, void 0, notification.title);
      const localizedBody = getMessage(notification.body, void 0, notification.body);
      return {
        ...notification,
        title: localizedTitle,
        body: localizedBody
      };
    });
  }
  /**
   * Get all notifications
   */
  getNotifications() {
    return [...this.notifications];
  }
  /**
   * Get unread notifications
   */
  getUnreadNotifications() {
    return this.notifications.filter((n) => !n.read_at);
  }
  /**
   * Get a notification by ID
   */
  getNotification(id) {
    return this.notifications.find((n) => n.id === id);
  }
  /**
   * Mark a notification as read
   */
  async markAsRead(id) {
    try {
      const notification = this.notifications.find((n) => n.id === id);
      if (!notification) {
        return false;
      }
      notification.read_at = (/* @__PURE__ */ new Date()).toISOString();
      this.updateBadge();
      this.notifyUpdateListeners();
      emitEvent(AppEvent.NOTIFICATION_READ, { notificationId: id });
      await notificationApi.markNotificationRead(id.toString());
      return true;
    } catch (error) {
      debug("❌ Error marking notification as read:", error);
      return false;
    }
  }
  /**
   * Mark all notifications as read
   */
  async markAllAsRead() {
    try {
      const unreadCount = this.getUnreadCount();
      if (unreadCount === 0) {
        return true;
      }
      const now = (/* @__PURE__ */ new Date()).toISOString();
      this.notifications.forEach((n) => {
        if (!n.read_at) {
          n.read_at = now;
        }
      });
      this.updateBadge();
      this.notifyUpdateListeners();
      await notificationApi.markAllNotificationsRead();
      toast.success(getMessage("notifications_marked_read", { count: unreadCount }, `Marked ${unreadCount} notifications as read`));
      return true;
    } catch (error) {
      debug("❌ Error marking all notifications as read:", error);
      return false;
    }
  }
  /**
   * Delete a notification
   */
  async deleteNotification(id) {
    try {
      const notification = this.notifications.find((n) => n.id === id);
      if (!notification) {
        return false;
      }
      this.notifications = this.notifications.filter((n) => n.id !== id);
      this.updateBadge();
      this.notifyUpdateListeners();
      emitEvent(AppEvent.NOTIFICATION_DELETED, { notificationId: id });
      await notificationApi.deleteNotification(id.toString());
      toast.success(getMessage("notification_deleted", void 0, "Notification deleted"));
      return true;
    } catch (error) {
      debug("❌ Error deleting notification:", error);
      return false;
    }
  }
  /**
   * Create and show a new notification (client-side only)
   */
  showLocalNotification(notification) {
    var _a;
    const title = getMessage(notification.title, void 0, notification.title);
    const body = getMessage(notification.body, void 0, notification.body);
    const actionLabel = ((_a = notification.action) == null ? void 0 : _a.label) ? getMessage(notification.action.label, void 0, notification.action.label) : void 0;
    const action = notification.action ? {
      ...notification.action,
      label: actionLabel || notification.action.label
    } : void 0;
    switch (notification.type) {
      case "info":
        toast.info(title, {
          description: body,
          action
        });
        break;
      case "warning":
        toast.warning(title, {
          description: body,
          action
        });
        break;
      case "success":
        toast.success(title, {
          description: body,
          action
        });
        break;
      case "error":
        toast.error(title, {
          description: body,
          action
        });
        break;
    }
  }
  /**
   * Start polling for new notifications
   */
  startPolling() {
    if (this.pollingInterval) {
      clearInterval(this.pollingInterval);
      this.pollingInterval = null;
    }
    this.pollingInterval = window.setInterval(() => {
      this.loadNotifications();
    }, 6e5);
    debug("Started polling for notifications");
  }
  /**
   * Register for notification updates
   * @returns Cleanup function
   */
  onNotificationsUpdate(callback) {
    this.updateCallbacks.push(callback);
    callback([...this.notifications]);
    return () => {
      this.updateCallbacks = this.updateCallbacks.filter((cb) => cb !== callback);
    };
  }
  /**
   * Get count of unread notifications
   */
  getUnreadCount() {
    return this.notifications.filter((n) => !n.read_at).length;
  }
  /**
   * Update notification badge on main button
   */
  updateBadge() {
    const unreadCount = this.getUnreadCount();
    this.unreadCount = unreadCount;
    console.log("unreadCoun============t", unreadCount);
    document.dispatchEvent(new CustomEvent("jaydai:notification-count-changed", {
      detail: { unreadCount }
    }));
  }
  showNewNotificationsToast(count2) {
    toast.info(getMessage("new_notifications_title", { count: count2 }, `${count2} New Notification${count2 > 1 ? "s" : ""}`), {
      description: getMessage("new_notifications_description", void 0, "Click to view your notifications"),
      action: {
        label: getMessage("view_action", void 0, "View"),
        onClick: () => {
          console.log("Notification view action clicked");
          document.dispatchEvent(new CustomEvent("jaydai:open-notifications"));
          emitEvent(AppEvent.NOTIFICATION_RECEIVED, {
            notificationId: "",
            title: "",
            body: ""
          });
        }
      }
    });
  }
  /**
   * Handle a notification action based on metadata
   */
  async handleNotificationAction(id) {
    try {
      const notification = this.notifications.find((n) => n.id === id);
      if (!notification) {
        return;
      }
      await this.markAsRead(id);
      const metadata = this.parseMetadataSafe(notification.metadata);
      if (metadata && metadata.action_type) {
        switch (metadata.action_type) {
          case "openUrl":
          case "openLinkedIn":
            if (metadata.action_url) {
              window.open(metadata.action_url, "_blank");
            } else {
              toast.error(getMessage("no_url_error", void 0, "No URL provided for action"));
            }
            break;
          case "openChatGpt":
            window.open("https://chat.openai.com/", "_blank");
            break;
          case "openSettings":
            document.dispatchEvent(new CustomEvent("jaydai:toggle-panel", {
              detail: { panel: "menu" }
            }));
            document.dispatchEvent(new CustomEvent("jaydai:open-settings"));
            break;
          case "showTemplates":
            document.dispatchEvent(new CustomEvent("jaydai:toggle-panel", {
              detail: { panel: "templates" }
            }));
            break;
          case "start_conversation":
            window.open("https://chatgpt.com/", "_blank");
            break;
          default:
            debug(`⚠️ Unknown action type: ${metadata.action_type}`);
            toast.info(notification.title, {
              description: notification.body
            });
            break;
        }
        return;
      }
      switch (notification.type) {
        case "insight_prompt_length":
        case "insight_response_time":
        case "insight_conversation_quality":
          toast.info(notification.title, {
            description: notification.body,
            action: {
              label: getMessage("view_action", void 0, "View"),
              onClick: () => window.open("https://chatgpt.com/", "_blank")
            }
          });
          break;
        default:
          toast.info(notification.title, {
            description: notification.body
          });
          break;
      }
    } catch (error) {
      debug("❌ Error handling notification action:", error);
      toast.error(getMessage("action_error", void 0, "Failed to process notification action"));
    }
  }
  /**
   * Parse metadata safely without throwing
   */
  parseMetadataSafe(metadata) {
    try {
      if (!metadata) return null;
      if (typeof metadata === "object") {
        return this.validateMetadata(metadata);
      }
      const parsedMetadata = JSON.parse(metadata);
      return this.validateMetadata(parsedMetadata);
    } catch (error) {
      debug("❌ Error parsing notification metadata:", error);
      return null;
    }
  }
  /**
   * Validate notification action metadata
   */
  validateMetadata(data) {
    if (!data || typeof data !== "object") {
      return null;
    }
    if (typeof data.action_type !== "string" || typeof data.action_title_key !== "string") {
      return null;
    }
    if ((data.action_type === "openUrl" || data.action_type === "openLinkedIn" || data.action_type === "openChatGpt") && (!data.action_url || typeof data.action_url !== "string")) {
      debug(`⚠️ ${data.action_type} action missing valid URL`);
      return null;
    }
    return {
      action_type: data.action_type,
      action_title_key: data.action_title_key,
      action_url: data.action_url
    };
  }
  /**
   * Get action button details for a notification
   */
  getActionButton(notification) {
    console.log("notification METADATA===========", notification.metadata);
    if (!notification.metadata) {
      return null;
    }
    const metadata = this.parseMetadataSafe(notification.metadata);
    if (!metadata) {
      return null;
    }
    return {
      title: getMessage(metadata.action_title_key, void 0, metadata.action_title_key),
      visible: true
    };
  }
  /**
   * Notify all update listeners
   */
  notifyUpdateListeners() {
    const notificationsCopy = [...this.notifications];
    this.updateCallbacks.forEach((callback) => {
      try {
        callback(notificationsCopy);
      } catch (error) {
        debug("❌ Error in notification update callback:", error);
      }
    });
  }
};
__publicField(_NotificationService, "instance");
let NotificationService = _NotificationService;
const notificationService = NotificationService.getInstance();
const _StatsService = class _StatsService extends AbstractBaseService {
  constructor() {
    super();
    __publicField(this, "stats", {
      totalChats: 0,
      recentChats: 0,
      totalMessages: 0,
      avgMessagesPerChat: 0,
      messagesPerDay: {},
      chatsPerDay: {},
      // Add this
      tokenUsage: {
        recent: 0,
        recentInput: 0,
        recentOutput: 0,
        total: 0,
        totalInput: 0,
        totalOutput: 0
      },
      energyUsage: {
        recentWh: 0,
        totalWh: 0,
        perMessageWh: 0
      },
      thinkingTime: {
        total: 0,
        average: 0
      }
    });
    __publicField(this, "updateInterval", null);
    __publicField(this, "updateCallbacks", []);
    __publicField(this, "lastLoadTime", 0);
    __publicField(this, "retryCount", 0);
    __publicField(this, "isLoading", false);
    /**
     * Handle message extracted event
     */
    __publicField(this, "handleMessageExtracted", (event) => {
      const { message } = event.detail;
      if (!message) return;
      try {
        if (message.role === "user") {
          this.trackUserMessageSent(message.content);
        } else if (message.role === "assistant") {
          this.trackAssistantMessageReceived(message.content, message.thinkingTime);
        }
        this.debounceRefresh();
      } catch (error) {
        debug("Error handling message extracted event:", error);
      }
    });
    /**
     * Handle conversation loaded event
     */
    __publicField(this, "handleConversationLoaded", (_event) => {
      this.debounceRefresh(500);
    });
    /**
     * Handle conversation list event
     */
    __publicField(this, "handleConversationList", (event) => {
      const { conversations } = event.detail;
      if (conversations && Array.isArray(conversations)) {
        const currentTotalChats = this.stats.totalChats;
        const newTotalChats = conversations.length;
        if (newTotalChats !== currentTotalChats) {
          this.stats.totalChats = newTotalChats;
          this.notifyUpdateListeners();
          this.debounceRefresh();
        }
      }
    });
    /**
     * Handle conversation changed event
     */
    __publicField(this, "handleConversationChanged", (_event) => {
      this.debounceRefresh(500);
    });
    /**
     * Handle chat message sent event
     */
    __publicField(this, "handleChatMessageSent", (event) => {
      try {
        const { content } = event.detail;
        if (content) {
          this.trackUserMessageSent(content);
        }
      } catch (error) {
        debug("Error handling chat message sent event:", error);
      }
    });
    /**
     * Handle chat message received event
     */
    __publicField(this, "handleChatMessageReceived", (event) => {
      try {
        const { content, thinkingTime } = event.detail;
        if (content) {
          this.trackAssistantMessageReceived(content, thinkingTime);
        }
      } catch (error) {
        debug("Error handling chat message received event:", error);
      }
    });
    /**
     * Handle chat conversation changed event
     */
    __publicField(this, "handleChatConversationChanged", (_event) => {
      this.debounceRefresh(500);
    });
    /**
    * Handle network interception events for stats
    */
    __publicField(this, "handleNetworkEvent", (event) => {
      var _a, _b;
      const { type, data } = event.detail;
      if (!data) return;
      try {
        switch (type) {
          case "chatCompletion":
            if (((_b = (_a = data.requestBody) == null ? void 0 : _a.messages) == null ? void 0 : _b.length) > 0) {
              const userMessage = this.extractUserMessage(data.requestBody);
              if (userMessage && userMessage.content) {
                this.trackUserMessageSent(userMessage.content);
                this.debounceRefresh();
              }
            }
            break;
          case "assistantResponse":
            if (data.isComplete && data.content) {
              this.trackAssistantMessageReceived(data.content, data.thinkingTime);
              this.debounceRefresh();
            }
            break;
          case "conversationList":
            this.debounceRefresh();
            break;
          case "specificConversation":
            this.debounceRefresh(500);
            break;
        }
      } catch (error) {
        debug("Error handling stats event:", error);
      }
    });
    // Add debounce mechanism to prevent too many API calls
    __publicField(this, "refreshTimeout", null);
  }
  static getInstance() {
    if (!_StatsService.instance) {
      _StatsService.instance = new _StatsService();
    }
    return _StatsService.instance;
  }
  /**
   * Initialize stats tracking
   */
  async onInitialize() {
    debug("Initializing stats service...");
    this.setupEventListeners();
    await this.loadStats();
    this.updateInterval = window.setInterval(() => {
      const now = Date.now();
      if (now - this.lastLoadTime >= 1e4) {
        this.loadStats();
      }
    }, 2e4);
    debug("Stats service initialized");
  }
  /**
   * Clean up resources
   */
  onCleanup() {
    if (this.updateInterval) {
      clearInterval(this.updateInterval);
      this.updateInterval = null;
    }
    this.updateCallbacks = [];
    debug("Stats service cleaned up");
  }
  /**
  * Set up event listeners for tracking stats
  */
  setupEventListeners() {
    document.addEventListener("jaydai:network-intercept", this.handleNetworkEvent);
    document.addEventListener("jaydai:message-extracted", this.handleMessageExtracted);
    document.addEventListener("jaydai:conversation-loaded", this.handleConversationLoaded);
    document.addEventListener("jaydai:conversation-list", this.handleConversationList);
    document.addEventListener("jaydai:conversation-changed", this.handleConversationChanged);
    document.addEventListener(AppEvent.CHAT_MESSAGE_SENT, this.handleChatMessageSent);
    document.addEventListener(AppEvent.CHAT_MESSAGE_RECEIVED, this.handleChatMessageReceived);
    document.addEventListener(AppEvent.CHAT_CONVERSATION_CHANGED, this.handleChatConversationChanged);
  }
  /**
  * Update stats optimistically when a user message is sent
  */
  trackUserMessageSent(messageContent) {
    this.stats.totalMessages++;
    const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    this.stats.messagesPerDay[today] = (this.stats.messagesPerDay[today] || 0) + 1;
    const estimatedTokens = this.estimateTokens(messageContent);
    this.stats.tokenUsage.totalInput += estimatedTokens;
    this.stats.tokenUsage.recent += estimatedTokens;
    this.stats.tokenUsage.recentInput += estimatedTokens;
    const energyUsage = estimatedTokens * 3e-4 / 36e5;
    this.stats.energyUsage.total += energyUsage;
    this.stats.energyUsage.recent += energyUsage;
    this.notifyUpdateListeners();
  }
  /**
   * Update stats optimistically when an assistant message is received
   */
  trackAssistantMessageReceived(messageContent, thinkingTime) {
    this.stats.totalMessages++;
    const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
    this.stats.messagesPerDay[today] = (this.stats.messagesPerDay[today] || 0) + 1;
    const estimatedTokens = this.estimateTokens(messageContent);
    this.stats.tokenUsage.totalOutput += estimatedTokens;
    this.stats.tokenUsage.recent += estimatedTokens;
    this.stats.tokenUsage.recentOutput += estimatedTokens;
    const energyUsage = estimatedTokens * 6e-4 / 36e5;
    this.stats.energyUsage.total += energyUsage;
    this.stats.energyUsage.recent += energyUsage;
    if (thinkingTime) {
      this.stats.thinkingTime.total += thinkingTime;
      this.stats.thinkingTime.average = this.stats.totalMessages > 0 ? this.stats.thinkingTime.total / this.stats.totalMessages : 0;
    }
    this.notifyUpdateListeners();
  }
  /**
   * Estimate the number of tokens in text
   */
  estimateTokens(text) {
    if (!text) return 0;
    return Math.max(1, Math.ceil(text.length / 4));
  }
  /**
   * Extract user message from chat completion request body
   */
  extractUserMessage(requestBody) {
    var _a;
    try {
      if (!requestBody || !requestBody.messages) return null;
      const message = requestBody.messages.find(
        (m) => {
          var _a2;
          return ((_a2 = m.author) == null ? void 0 : _a2.role) === "user" || m.role === "user";
        }
      );
      if (!message) return null;
      let content = "";
      if ((_a = message.content) == null ? void 0 : _a.parts) {
        content = message.content.parts.join("\n");
      } else if (typeof message.content === "string") {
        content = message.content;
      } else if (message.content) {
        content = JSON.stringify(message.content);
      }
      return {
        id: message.id || `user-${Date.now()}`,
        content
      };
    } catch (error) {
      debug("Error extracting user message:", error);
      return null;
    }
  }
  debounceRefresh(delay2 = 1e3) {
    if (this.refreshTimeout !== null) {
      window.clearTimeout(this.refreshTimeout);
    }
    this.refreshTimeout = window.setTimeout(() => {
      this.refreshTimeout = null;
      this.loadStats();
    }, delay2);
  }
  /**
   * Get current stats
   */
  getStats() {
    return { ...this.stats };
  }
  /**
   * Get chart data for messages per day
   */
  getMessagesPerDayChart() {
    const sortedDays = Object.keys(this.stats.messagesPerDay).sort((a, b) => new Date(a).getTime() - new Date(b).getTime());
    return {
      labels: sortedDays,
      values: sortedDays.map((day) => this.stats.messagesPerDay[day])
    };
  }
  /**
   * Get energy usage chart data
   */
  getEnergyUsageChart() {
    return {
      labels: ["Recent", "Total"],
      values: [this.stats.energyUsage.recent, this.stats.energyUsage.total]
    };
  }
  /**
   * Get token usage chart data
   */
  getTokenUsageChart() {
    return {
      labels: ["Input", "Output"],
      values: [this.stats.tokenUsage.totalInput, this.stats.tokenUsage.totalOutput]
    };
  }
  /**
   * Get model usage chart data
   */
  getModelUsageChart() {
    if (!this.stats.modelUsage) {
      return { labels: [], values: [] };
    }
    const models = Object.keys(this.stats.modelUsage);
    return {
      labels: models,
      values: models.map((model) => {
        var _a;
        return ((_a = this.stats.modelUsage) == null ? void 0 : _a[model].count) || 0;
      })
    };
  }
  /**
   * Manually refresh stats from backend
   */
  async refreshStats() {
    return this.loadStats(true);
  }
  /**
   * Register for stats updates
   * @returns Cleanup function to unregister
   */
  onUpdate(callback) {
    this.updateCallbacks.push(callback);
    callback({ ...this.stats });
    return () => {
      this.updateCallbacks = this.updateCallbacks.filter((cb) => cb !== callback);
    };
  }
  /**
   * Load stats from backend with improved error handling
   */
  async loadStats(forceRefresh = false) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
    if (!forceRefresh && Date.now() - this.lastLoadTime < 6e4) {
      return;
    }
    if (this.isLoading) {
      return;
    }
    this.isLoading = true;
    try {
      debug("Loading stats from backend...");
      const data = await userApi.getUserStats();
      if (data) {
        this.stats = {
          ...this.stats,
          totalChats: data.total_chats || 0,
          recentChats: data.recent_chats || 0,
          totalMessages: data.total_messages || 0,
          avgMessagesPerChat: data.avg_messages_per_chat || 0,
          efficiency: data.efficiency,
          tokenUsage: {
            recent: ((_a = data.token_usage) == null ? void 0 : _a.recent) || 0,
            recentInput: ((_b = data.token_usage) == null ? void 0 : _b.recent_input) || 0,
            recentOutput: ((_c = data.token_usage) == null ? void 0 : _c.recent_output) || 0,
            total: ((_d = data.token_usage) == null ? void 0 : _d.total) || 0,
            totalInput: ((_e = data.token_usage) == null ? void 0 : _e.total_input) || 0,
            totalOutput: ((_f = data.token_usage) == null ? void 0 : _f.total_output) || 0
          },
          energyUsage: {
            recentWh: ((_g = data.energy_usage) == null ? void 0 : _g.recent_wh) || 0,
            totalWh: ((_h = data.energy_usage) == null ? void 0 : _h.total_wh) || 0,
            perMessageWh: ((_i = data.energy_usage) == null ? void 0 : _i.per_message_wh) || 0,
            equivalent: ((_j = data.energy_usage) == null ? void 0 : _j.equivalent) || ""
          },
          thinkingTime: {
            total: ((_k = data.thinking_time) == null ? void 0 : _k.total) || 0,
            average: ((_l = data.thinking_time) == null ? void 0 : _l.average) || 0
          },
          modelUsage: data.model_usage || {}
        };
        if (data.messages_per_day) {
          this.stats.messagesPerDay = { ...data.messages_per_day };
        }
        debug("Stats updated from backend");
        this.lastLoadTime = Date.now();
        this.retryCount = 0;
        this.notifyUpdateListeners();
        emitEvent(AppEvent.STATS_UPDATED, { stats: this.getStats() });
      }
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error loading stats", ErrorCode.API_ERROR, error)
      );
      if (this.retryCount < 3) {
        this.retryCount++;
        const delay2 = Math.pow(2, this.retryCount) * 1e3;
        debug(`Will retry loading stats in ${delay2 / 1e3}s (attempt ${this.retryCount}/3)`);
        setTimeout(() => {
          this.isLoading = false;
          this.loadStats();
        }, delay2);
      } else {
        if (this.lastLoadTime === 0) {
          debug("Using fallback stats data after multiple failed attempts");
          if (this.stats.totalMessages === 0) {
            const today = (/* @__PURE__ */ new Date()).toISOString().split("T")[0];
            this.stats.messagesPerDay[today] = this.stats.messagesPerDay[today] || 0;
            this.notifyUpdateListeners();
          }
        }
        this.retryCount = 0;
      }
    } finally {
      if (this.retryCount === 0) {
        this.isLoading = false;
      }
    }
  }
  /**
   * Notify all update listeners
   */
  notifyUpdateListeners() {
    const statsCopy = { ...this.stats };
    this.updateCallbacks.forEach((callback) => {
      try {
        callback(statsCopy);
      } catch (error) {
        errorReporter.captureError(
          new AppError("Error in stats update callback", ErrorCode.EXTENSION_ERROR, error)
        );
      }
    });
  }
  /**
   * Get weekly conversation statistics
   */
  async getWeeklyConversations() {
    try {
      return await userApi.getWeeklyConversationStats();
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error getting weekly conversation stats", ErrorCode.API_ERROR, error)
      );
      return null;
    }
  }
  /**
   * Get message distribution statistics
   */
  async getMessageDistribution() {
    try {
      return await userApi.getMessageDistribution();
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error getting message distribution", ErrorCode.API_ERROR, error)
      );
      return null;
    }
  }
};
__publicField(_StatsService, "instance");
let StatsService = _StatsService;
const _UserProfileService = class _UserProfileService extends AbstractBaseService {
  constructor() {
    super();
    __publicField(this, "userInfo", null);
    __publicField(this, "fetchedUserInfo", false);
    __publicField(this, "storageKey", "archimind_user_info");
    /**
     * Handle user info event directly
     */
    __publicField(this, "handleUserInfoEvent", (event) => {
      try {
        const data = event.detail;
        if (!data || !data.responseBody) return;
        this.handleUserInfoCapture(data.responseBody);
      } catch (error) {
        errorReporter.captureError(
          new AppError("Error handling user info event", ErrorCode.EXTENSION_ERROR, error)
        );
      }
    });
  }
  static getInstance() {
    if (!_UserProfileService.instance) {
      _UserProfileService.instance = new _UserProfileService();
    }
    return _UserProfileService.instance;
  }
  /**
   * Initialize the user profile service
   */
  async onInitialize() {
    debug("Initializing UserProfileService");
    this.getUserInfoFromStorage().then((data) => {
      if (data) {
        this.processUserInfo(data);
        this.fetchedUserInfo = true;
      }
    });
    document.addEventListener("jaydai:user-info", this.handleUserInfoEvent);
  }
  /**
   * Clean up resources
   */
  onCleanup() {
    document.removeEventListener("jaydai:user-info", this.handleUserInfoEvent);
    debug("UserProfileService cleaned up");
  }
  /**
   * Process user information
   */
  handleUserInfoCapture(userData) {
    try {
      debug("User info captured from network");
      if (userData && userData.email && userData.email !== "") {
        this.processUserInfo(userData);
        this.fetchedUserInfo = true;
        this.saveUserInfoToStorage(userData);
        emitEvent(AppEvent.USER_INFO_UPDATED, {
          email: userData.email,
          name: userData.name || userData.email.split("@")[0]
        });
      }
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error handling user info capture", ErrorCode.API_ERROR, error)
      );
    }
  }
  /**
   * Process user information from API
   */
  processUserInfo(data) {
    try {
      if (!data || !data.id || !data.email) {
        return;
      }
      let orgName = null;
      if (data.orgs && data.orgs.data && data.orgs.data.length > 0) {
        orgName = data.orgs.data[0].title || null;
      }
      this.userInfo = {
        id: data.id,
        email: data.email,
        name: data.name || data.email.split("@")[0],
        picture: data.picture || null,
        phone_number: data.phone_number || null,
        org_name: orgName
      };
      this.saveUserMetadataToBackend();
      debug("User info processed successfully");
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error processing user info", ErrorCode.VALIDATION_ERROR, error)
      );
    }
  }
  async hasCompletedOnboarding() {
    const status = await userApi.getUserOnboardingStatus();
    return status.has_completed_onboarding || false;
  }
  /**
   * Save user info to extension storage
   */
  saveUserInfoToStorage(userData) {
    try {
      chrome.storage.local.set({ [this.storageKey]: userData });
      debug("User info saved to storage");
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error saving user info to storage", ErrorCode.STORAGE_ERROR, error)
      );
    }
  }
  /**
   * Get user info from storage
   */
  async getUserInfoFromStorage() {
    try {
      return new Promise((resolve) => {
        chrome.storage.local.get([this.storageKey], (result) => {
          if (result && result[this.storageKey]) {
            debug("Retrieved user info from storage");
            resolve(result[this.storageKey]);
          } else {
            debug("No user info found in storage");
            resolve(null);
          }
        });
      });
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error getting user info from storage", ErrorCode.STORAGE_ERROR, error)
      );
      return null;
    }
  }
  /**
   * Get the current user info
   */
  getUserInfo() {
    return this.userInfo;
  }
  /**
   * Get user ID
   */
  getUserId() {
    var _a;
    return ((_a = this.userInfo) == null ? void 0 : _a.id) || null;
  }
  /**
   * Save user metadata to backend
   */
  saveUserMetadataToBackend() {
    if (!this.userInfo) return;
    try {
      userApi.saveUserMetadata({
        email: this.userInfo.email,
        name: this.userInfo.name,
        phone_number: this.userInfo.phone_number || void 0,
        org_name: this.userInfo.org_name || void 0,
        picture: this.userInfo.picture || void 0
      }).then(() => {
        debug("User metadata saved to backend");
      }).catch((error) => {
        errorReporter.captureError(
          new AppError("Error saving user metadata", ErrorCode.API_ERROR, error)
        );
      });
    } catch (error) {
      errorReporter.captureError(
        new AppError("Error preparing user metadata save", ErrorCode.UNKNOWN_ERROR, error)
      );
    }
  }
  /**
   * Force a refresh of the user info
   */
  refreshUserInfo() {
    this.fetchedUserInfo = false;
    chrome.storage.local.remove([this.storageKey]);
    debug("User info refreshed");
  }
};
__publicField(_UserProfileService, "instance");
let UserProfileService = _UserProfileService;
UserProfileService.getInstance();
const DIALOG_TYPES = {
  // Existing dialog types
  SETTINGS: "settings",
  CREATE_TEMPLATE: "createTemplate",
  EDIT_TEMPLATE: "editTemplate",
  CREATE_FOLDER: "createFolder",
  PLACEHOLDER_EDITOR: "placeholderEditor",
  AUTH: "auth",
  CONFIRMATION: "confirmation",
  ENHANCED_STATS: "enhancedStats",
  // New dialog type for block creation
  CREATE_BLOCK: "createBlock",
  INSERT_BLOCK: "insertBlock"
};
const ScrollArea = reactExports.forwardRef(({ className, children, viewportClassName, thumbClassName, ...props }, ref) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      ref,
      className: cn("jd-relative jd-overflow-hidden", className),
      ...props,
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          className: cn(
            "jd-h-full jd-w-full jd-overflow-auto jd-scrollbar-thin jd-scrollbar-thumb-rounded",
            "jd-scrollbar jd-scrollbar-track-transparent",
            viewportClassName
          ),
          style: {
            // Add some custom scrollbar styling that works in Shadow DOM
            scrollbarWidth: "thin",
            scrollbarColor: "var(--border) transparent"
          },
          onMouseDown: (e) => e.stopPropagation(),
          children
        }
      )
    }
  );
});
ScrollArea.displayName = "ScrollArea";
const ScrollAreaHorizontal = reactExports.forwardRef(({ className, children, ...props }, ref) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      ref,
      className: cn("jd-relative jd-overflow-hidden", className),
      ...props,
      children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          className: "jd-h-full jd-w-full jd-overflow-x-auto jd-overflow-y-hidden jd-scrollbar-thin jd-scrollbar-thumb-rounded",
          style: {
            scrollbarWidth: "thin",
            scrollbarColor: "var(--border) transparent"
          },
          onMouseDown: (e) => e.stopPropagation(),
          children
        }
      )
    }
  );
});
ScrollAreaHorizontal.displayName = "ScrollAreaHorizontal";
const LoadingSpinner = ({
  size = "md",
  className,
  message,
  fullScreen = false
}) => {
  const sizeMap = {
    sm: "jd-h-4 jd-w-4 jd-border-2",
    md: "jd-h-8 jd-w-8 jd-border-3",
    lg: "jd-h-12 jd-w-12 jd-border-4"
  };
  const spinnerClass = cn(
    "jd-animate-spin jd-rounded-full jd-border-transparent jd-border-t-primary jd-inline-block",
    sizeMap[size],
    className
  );
  const containerClass = cn(
    "jd-flex jd-flex-col jd-items-center jd-justify-center jd-gap-3",
    fullScreen ? "jd-fixed jd-inset-0 jd-z-50 jd-bg-background/80 jd-backdrop-blur-sm" : "jd-py-6"
  );
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: containerClass, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: spinnerClass }),
    message && /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "jd-text-sm jd-text-muted-foreground jd-animate-pulse", children: message })
  ] });
};
const BLOCK_TYPES = [
  "role",
  "context",
  "goal",
  "custom",
  "output_format",
  "example",
  "constraint",
  "tone_style",
  "audience"
];
const BLOCK_TYPE_LABELS = {
  role: "Role",
  context: "Context",
  goal: "Goal",
  custom: "Custom",
  output_format: "Output Format",
  example: "Example",
  constraint: "Constraint",
  tone_style: "Tone & Style",
  audience: "Audience"
};
const BLOCK_TYPE_ICONS = {
  role: User,
  context: MessageSquare,
  goal: Target,
  custom: Sparkles,
  output_format: Type,
  example: PanelsTopLeft,
  constraint: Ban,
  tone_style: Palette,
  audience: Users
};
const BLOCK_CARD_COLORS_LIGHT = {
  role: "jd-bg-gradient-to-br jd-from-purple-50 jd-to-purple-100 jd-border-purple-200 jd-text-purple-900",
  context: "jd-bg-gradient-to-br jd-from-green-50 jd-to-green-100 jd-border-green-200 jd-text-green-900",
  goal: "jd-bg-gradient-to-br jd-from-pink-50 jd-to-pink-100 jd-border-pink-200 jd-text-pink-900",
  custom: "jd-bg-gradient-to-br jd-from-amber-50 jd-to-amber-100 jd-border-amber-200 jd-text-amber-900",
  output_format: "jd-bg-gradient-to-br jd-from-cyan-50 jd-to-cyan-100 jd-border-cyan-200 jd-text-cyan-900",
  example: "jd-bg-gradient-to-br jd-from-orange-50 jd-to-orange-100 jd-border-orange-200 jd-text-orange-900",
  constraint: "jd-bg-gradient-to-br jd-from-red-50 jd-to-red-100 jd-border-red-200 jd-text-red-900",
  tone_style: "jd-bg-gradient-to-br jd-from-indigo-50 jd-to-indigo-100 jd-border-indigo-200 jd-text-indigo-900",
  audience: "jd-bg-gradient-to-br jd-from-teal-50 jd-to-teal-100 jd-border-teal-200 jd-text-teal-900"
};
const BLOCK_CARD_COLORS_DARK = {
  role: "jd-bg-gradient-to-br jd-from-purple-800/40 jd-to-purple-900/40 jd-border-purple-700 jd-text-purple-200",
  context: "jd-bg-gradient-to-br jd-from-green-800/40 jd-to-green-900/40 jd-border-green-700 jd-text-green-200",
  goal: "jd-bg-gradient-to-br jd-from-pink-800/40 jd-to-pink-900/40 jd-border-pink-700 jd-text-pink-200",
  custom: "jd-bg-gradient-to-br jd-from-amber-800/40 jd-to-amber-900/40 jd-border-amber-700 jd-text-amber-200",
  output_format: "jd-bg-gradient-to-br jd-from-cyan-800/40 jd-to-cyan-900/40 jd-border-cyan-700 jd-text-cyan-200",
  example: "jd-bg-gradient-to-br jd-from-orange-800/40 jd-to-orange-900/40 jd-border-orange-700 jd-text-orange-200",
  constraint: "jd-bg-gradient-to-br jd-from-red-800/40 jd-to-red-900/40 jd-border-red-700 jd-text-red-200",
  tone_style: "jd-bg-gradient-to-br jd-from-indigo-800/40 jd-to-indigo-900/40 jd-border-indigo-700 jd-text-indigo-200",
  audience: "jd-bg-gradient-to-br jd-from-teal-800/40 jd-to-teal-900/40 jd-border-teal-700 jd-text-teal-200"
};
const BLOCK_ICON_COLORS_LIGHT = {
  role: "jd-bg-purple-100 jd-text-purple-700",
  context: "jd-bg-green-100 jd-text-green-700",
  goal: "jd-bg-pink-100 jd-text-pink-700",
  custom: "jd-bg-amber-100 jd-text-amber-700",
  output_format: "jd-bg-cyan-100 jd-text-cyan-700",
  example: "jd-bg-orange-100 jd-text-orange-700",
  constraint: "jd-bg-red-100 jd-text-red-700",
  tone_style: "jd-bg-indigo-100 jd-text-indigo-700",
  audience: "jd-bg-teal-100 jd-text-teal-700"
};
const BLOCK_ICON_COLORS_DARK = {
  role: "jd-bg-purple-800 jd-text-purple-300",
  context: "jd-bg-green-800 jd-text-green-300",
  goal: "jd-bg-pink-800 jd-text-pink-300",
  custom: "jd-bg-amber-800 jd-text-amber-300",
  output_format: "jd-bg-cyan-800 jd-text-cyan-300",
  example: "jd-bg-orange-800 jd-text-orange-300",
  constraint: "jd-bg-red-800 jd-text-red-300",
  tone_style: "jd-bg-indigo-800 jd-text-indigo-300",
  audience: "jd-bg-teal-800 jd-text-teal-300"
};
const BLOCK_TEXT_COLORS_LIGHT = {
  role: "jd-text-purple-700",
  context: "jd-text-green-700",
  goal: "jd-text-pink-700",
  custom: "jd-text-amber-700",
  output_format: "jd-text-cyan-700",
  example: "jd-text-orange-700",
  constraint: "jd-text-red-700",
  tone_style: "jd-text-indigo-700",
  audience: "jd-text-teal-700"
};
const BLOCK_TEXT_COLORS_DARK = {
  role: "jd-text-purple-300",
  context: "jd-text-green-300",
  goal: "jd-text-pink-300",
  custom: "jd-text-amber-300",
  output_format: "jd-text-cyan-300",
  example: "jd-text-orange-300",
  constraint: "jd-text-red-300",
  tone_style: "jd-text-indigo-300",
  audience: "jd-text-teal-300"
};
const getBlockTypeLabel = (type) => BLOCK_TYPE_LABELS[type] || type;
const getBlockTypeIcon = (type) => BLOCK_TYPE_ICONS[type] || FileText;
const getBlockTypeColors = (type, dark) => dark ? BLOCK_CARD_COLORS_DARK[type] : BLOCK_CARD_COLORS_LIGHT[type];
const getBlockIconColors = (type, dark) => dark ? BLOCK_ICON_COLORS_DARK[type] : BLOCK_ICON_COLORS_LIGHT[type];
const getBlockTextColors = (type, dark) => dark ? BLOCK_TEXT_COLORS_DARK[type] : BLOCK_TEXT_COLORS_LIGHT[type];
const getLocalizedContent = (content) => {
  if (typeof content === "string") return content;
  if (content && typeof content === "object") {
    const locale = getCurrentLanguage();
    return content[locale] || content.en || Object.values(content)[0] || "";
  }
  return "";
};
const PROMPT_PREFIXES_FR = {
  role: "Role:\n ",
  context: "Contexte:\n ",
  goal: "Objectif:\n ",
  custom: "",
  output_format: "Format de sortie:\n ",
  example: "Exemples:\n ",
  constraint: "Contraintes:\n ",
  tone_style: "Ton et style:\n ",
  audience: "Audience cible:\n "
};
const escapeHtml = (str) => str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#039;").replace(/\n/g, "<br>");
const buildPromptPart = (type, content) => {
  if (!type || type === "custom") {
    return content;
  }
  const prefix = PROMPT_PREFIXES_FR[type];
  return prefix ? `${prefix}${content}` : content;
};
const buildPromptPartHtml = (type, content, isDarkMode) => {
  if (type === "custom") {
    return escapeHtml(content);
  }
  const prefix = PROMPT_PREFIXES_FR[type];
  if (!prefix) {
    return escapeHtml(content);
  }
  return `<span class="${getBlockTextColors(type, isDarkMode)} jd-font-black">${escapeHtml(prefix)}</span>${escapeHtml(content)}`;
};
const isMultipleValueBlock = (type) => {
  return ["constraint", "example"].includes(type);
};
const BlockItem = ({
  block,
  isDark,
  onSelect,
  isActive
}) => {
  const Icon2 = getBlockTypeIcon(block.type);
  const iconBg = getBlockIconColors(block.type, isDark);
  const title = getLocalizedContent(block.title);
  const content = getLocalizedContent(block.content);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      onClick: () => onSelect(block),
      className: cn(
        "jd-p-3 jd-cursor-pointer jd-transition-all jd-duration-150",
        "jd-hover:jd-bg-muted/80 jd-rounded-md jd-group",
        isActive && "jd-bg-muted"
      ),
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-flex jd-items-start jd-gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: cn(
          "jd-p-1.5 jd-rounded-md jd-flex-shrink-0 jd-transition-transform",
          "jd-group-hover:jd-scale-110",
          iconBg
        ), children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon2, { className: "jd-h-3 jd-w-3" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-flex-1 jd-min-w-0", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-flex jd-items-center jd-gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "jd-text-sm jd-font-medium jd-truncate", children: title }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "jd-text-[10px] jd-px-1.5 jd-py-0.5 jd-bg-muted jd-rounded jd-text-muted-foreground", children: BLOCK_TYPE_LABELS[block.type || "custom"] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "jd-text-xs jd-text-muted-foreground jd-line-clamp-1 jd-mt-0.5", children: content })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "jd-h-3 jd-w-3 jd-text-muted-foreground jd-opacity-0 jd-group-hover:jd-opacity-100 jd-transition-opacity jd-flex-shrink-0 jd-mt-1" })
      ] })
    }
  );
};
class BlocksApi {
  /**
   * Get all blocks accessible to the user
   */
  async getBlocks(type) {
    try {
      const params = type ? `?type=${type}` : "";
      return await apiClient.request(`/prompts/blocks${params}`);
    } catch (error) {
      console.error("Error fetching blocks:", error);
      return {
        success: false,
        data: [],
        message: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
  /**
   * Get blocks by specific type
   */
  async getBlocksByType(blockType) {
    try {
      return await apiClient.request(`/prompts/blocks/by-type/${blockType}`);
    } catch (error) {
      console.error(`Error fetching ${blockType} blocks:`, error);
      return {
        success: false,
        data: [],
        message: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
  /**
   * Create a new block
   */
  async createBlock(blockData) {
    try {
      return await apiClient.request("/prompts/blocks", {
        method: "POST",
        body: JSON.stringify(blockData)
      });
    } catch (error) {
      console.error("Error creating block:", error);
      return {
        success: false,
        message: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
  /**
   * Update an existing block
   */
  async updateBlock(blockId, blockData) {
    try {
      return await apiClient.request(`/prompts/blocks/${blockId}`, {
        method: "PUT",
        body: JSON.stringify(blockData)
      });
    } catch (error) {
      console.error("Error updating block:", error);
      return {
        success: false,
        message: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
  /**
   * Delete a block
   */
  async deleteBlock(blockId) {
    try {
      return await apiClient.request(`/prompts/blocks/${blockId}`, {
        method: "DELETE"
      });
    } catch (error) {
      console.error("Error deleting block:", error);
      return {
        success: false,
        message: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
  /**
   * Fetch a single block by ID
   */
  async getBlock(blockId) {
    try {
      return await apiClient.request(`/prompts/blocks/${blockId}`);
    } catch (error) {
      console.error("Error fetching block:", error);
      return {
        success: false,
        data: null,
        message: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
  /**
   * Get all available block types
   */
  async getBlockTypes() {
    try {
      return await apiClient.request("/prompts/blocks/types");
    } catch (error) {
      console.error("Error fetching block types:", error);
      return {
        success: false,
        data: [],
        message: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
  /**
   * Seed sample blocks (development only)
   */
  async seedSampleBlocks() {
    try {
      return await apiClient.request("/prompts/blocks/seed-sample-blocks", {
        method: "POST"
      });
    } catch (error) {
      console.error("Error seeding sample blocks:", error);
      return {
        success: false,
        message: error instanceof Error ? error.message : "Unknown error"
      };
    }
  }
}
const blocksApi = new BlocksApi();
function useBlocks() {
  const [blocks, setBlocks] = reactExports.useState([]);
  const [loading, setLoading] = reactExports.useState(true);
  reactExports.useEffect(() => {
    blocksApi.getBlocks().then((res) => {
      if (res.success) {
        setBlocks(res.data);
      }
      setLoading(false);
    });
  }, []);
  return { blocks, loading };
}
function sanitizeCursorPosition(targetElement, savedCursorPos) {
  if (savedCursorPos === void 0) return void 0;
  if (savedCursorPos < 0 || savedCursorPos > 1e6) return void 0;
  let length = 0;
  if (targetElement instanceof HTMLTextAreaElement || targetElement instanceof HTMLInputElement) {
    length = targetElement.value.length;
  } else if (targetElement.isContentEditable) {
    length = (targetElement.textContent || "").length;
  }
  return Math.max(0, Math.min(savedCursorPos, length));
}
function insertIntoTextarea(textarea, text, cursorPos) {
  const start = cursorPos !== void 0 ? cursorPos : textarea.selectionStart || 0;
  const end = cursorPos !== void 0 ? cursorPos : textarea.selectionEnd || 0;
  const safeStart = Math.max(0, Math.min(start, textarea.value.length));
  const safeEnd = Math.max(0, Math.min(end, textarea.value.length));
  textarea.value = textarea.value.substring(0, safeStart) + text + textarea.value.substring(safeEnd);
  const newCursor = safeStart + text.length;
  textarea.setSelectionRange(newCursor, newCursor);
  textarea.dispatchEvent(new Event("input", { bubbles: true }));
  textarea.focus();
}
function insertIntoInput(input, text, cursorPos) {
  const start = cursorPos !== void 0 ? cursorPos : input.selectionStart || 0;
  const end = cursorPos !== void 0 ? cursorPos : input.selectionEnd || 0;
  const safeStart = Math.max(0, Math.min(start, input.value.length));
  const safeEnd = Math.max(0, Math.min(end, input.value.length));
  input.value = input.value.substring(0, safeStart) + text + input.value.substring(safeEnd);
  const newCursor = safeStart + text.length;
  input.setSelectionRange(newCursor, newCursor);
  input.dispatchEvent(new Event("input", { bubbles: true }));
  input.focus();
}
function insertIntoContentEditable(element, text, cursorPos) {
  element.focus();
  if (cursorPos !== void 0) restoreCursorPositionSafely(element, cursorPos);
  const selection = window.getSelection();
  if (selection && selection.rangeCount > 0) {
    const range = selection.getRangeAt(0);
    range.deleteContents();
    if (text.includes("\n")) {
      const fragment = document.createDocumentFragment();
      const lines = text.split("\n");
      lines.forEach((line, i) => {
        if (line) fragment.appendChild(document.createTextNode(line));
        if (i < lines.length - 1) fragment.appendChild(document.createElement("br"));
      });
      const lastNode = fragment.lastChild;
      range.insertNode(fragment);
      if (lastNode && lastNode.parentNode) {
        range.setStartAfter(lastNode);
        range.setEndAfter(lastNode);
      } else {
        range.collapse(false);
      }
    } else {
      const node = document.createTextNode(text);
      range.insertNode(node);
      range.setStartAfter(node);
      range.setEndAfter(node);
    }
    selection.removeAllRanges();
    selection.addRange(range);
    element.dispatchEvent(new Event("input", { bubbles: true }));
    element.focus();
    return;
  }
  if (text.includes("\n")) {
    const html = text.split("\n").join("<br>");
    element.innerHTML += html;
  } else {
    element.textContent = (element.textContent || "") + text;
  }
  element.dispatchEvent(new Event("input", { bubbles: true }));
  element.focus();
}
function restoreCursorPositionSafely(element, pos) {
  var _a, _b, _c;
  try {
    const text = element.textContent || "";
    const safePos = Math.max(0, Math.min(pos, text.length));
    const selection = window.getSelection();
    if (!selection) return false;
    const range = document.createRange();
    const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT);
    let current = walker.nextNode();
    let accumulated = 0;
    while (current && accumulated + (((_a = current.textContent) == null ? void 0 : _a.length) || 0) < safePos) {
      accumulated += ((_b = current.textContent) == null ? void 0 : _b.length) || 0;
      current = walker.nextNode();
    }
    if (current) {
      const offset = safePos - accumulated;
      range.setStart(current, Math.min(offset, ((_c = current.textContent) == null ? void 0 : _c.length) || 0));
      range.collapse(true);
    } else {
      range.selectNodeContents(element);
      range.collapse(false);
    }
    selection.removeAllRanges();
    selection.addRange(range);
    return true;
  } catch {
    return false;
  }
}
function tryPlatformSpecificInsertion(targetElement, text, pos) {
  const host = window.location.hostname;
  if (host.includes("claude.ai") && targetElement.isContentEditable) {
    targetElement.focus();
    if (typeof pos === "number") restoreCursorPositionSafely(targetElement, pos);
    try {
      if (document.execCommand && !text.includes("\n")) {
        if (document.execCommand("insertText", false, text)) return true;
      }
    } catch {
    }
    insertIntoContentEditable(targetElement, text, pos);
    return true;
  }
  if ((host.includes("chatgpt.com") || host.includes("chat.openai.com")) && targetElement instanceof HTMLTextAreaElement) {
    insertIntoTextarea(targetElement, text, pos);
    targetElement.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }
  return false;
}
function tryFallbackInsertion(text) {
  const selectors = ["textarea:focus", 'input[type="text"]:focus', '[contenteditable="true"]:focus', "textarea", 'input[type="text"]', '[contenteditable="true"]'];
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el && isElementVisible(el)) {
      if (el instanceof HTMLTextAreaElement || el instanceof HTMLInputElement) {
        el.value += text;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.focus();
        return;
      }
      if (el.isContentEditable) {
        el.textContent = (el.textContent || "") + text;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.focus();
        return;
      }
    }
  }
}
function isElementVisible(el) {
  const rect = el.getBoundingClientRect();
  const style = window.getComputedStyle(el);
  return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none" && el.offsetParent !== null;
}
function insertTextAtCursor(targetElement, text, savedCursorPos) {
  if (!targetElement || !text) return;
  if (window._jaydaiInserting) return;
  window._jaydaiInserting = true;
  try {
    const sanitized = sanitizeCursorPosition(targetElement, savedCursorPos);
    const success = tryPlatformSpecificInsertion(targetElement, text, sanitized);
    if (success) return;
    if (targetElement instanceof HTMLTextAreaElement) {
      insertIntoTextarea(targetElement, text, sanitized);
      return;
    }
    if (targetElement.isContentEditable) {
      insertIntoContentEditable(targetElement, text, sanitized);
      return;
    }
    if (targetElement instanceof HTMLInputElement) {
      insertIntoInput(targetElement, text, sanitized);
      return;
    }
    tryFallbackInsertion(text);
  } finally {
    setTimeout(() => {
      window._jaydaiInserting = false;
    }, 50);
  }
}
function insertIntoPromptArea(text) {
  const selectors = [
    'textarea[data-id="root"]',
    'div[contenteditable="true"]',
    'textarea[placeholder*="Message"]',
    'textarea[placeholder*="Ask Copilot"]',
    "textarea",
    "div[contenteditable]"
  ];
  let target = null;
  for (const sel of selectors) {
    const elements = document.querySelectorAll(sel);
    for (const el of elements) {
      if (el instanceof HTMLElement && isElementVisible(el)) {
        target = el;
        break;
      }
    }
    if (target) break;
  }
  if (!target) return;
  if (target instanceof HTMLTextAreaElement) {
    target.value = text;
    target.dispatchEvent(new Event("input", { bubbles: true }));
    target.focus();
  } else if (target.isContentEditable) {
    target.textContent = text;
    target.dispatchEvent(new Event("input", { bubbles: true }));
    target.focus();
  } else if (target instanceof HTMLInputElement) {
    target.value = text;
    target.dispatchEvent(new Event("input", { bubbles: true }));
    target.focus();
  }
}
function useBlockInsertion(targetElement, cursorPosition, onClose) {
  const insertingRef = reactExports.useRef(false);
  const insertBlock = (block) => {
    if (insertingRef.current) return;
    insertingRef.current = true;
    const content = getLocalizedContent(block.content);
    let text = buildPromptPart(block.type || "custom", content);
    let currentContent = "";
    if (targetElement instanceof HTMLTextAreaElement) {
      currentContent = targetElement.value;
    } else if (targetElement.isContentEditable) {
      currentContent = targetElement.textContent || "";
    }
    if (typeof cursorPosition === "number" && currentContent.length > 0) {
      const beforeCursorRaw = currentContent.substring(0, cursorPosition);
      const afterCursorRaw = currentContent.substring(cursorPosition);
      const beforeCursor = beforeCursorRaw.trim();
      const afterCursor = afterCursorRaw.trim();
      if (beforeCursor.length > 0 && !beforeCursorRaw.endsWith("\n")) {
        text = "\n\n" + text;
      }
      if (afterCursor.length > 0 && !text.endsWith("\n")) {
        text = text + "\n\n";
      } else if (afterCursor.length === 0 && !text.endsWith("\n")) {
        text = text + "\n";
      }
    } else if (currentContent.length > 0) {
      text = text + "\n";
    }
    if (onClose) onClose();
    setTimeout(() => {
      var _a, _b, _c;
      try {
        targetElement.focus();
        if (targetElement instanceof HTMLTextAreaElement && typeof cursorPosition === "number") {
          const safePosition = Math.max(
            0,
            Math.min(cursorPosition, targetElement.value.length)
          );
          targetElement.setSelectionRange(safePosition, safePosition);
        }
        if (targetElement.isContentEditable && typeof cursorPosition === "number") {
          const textContent = targetElement.textContent || "";
          const safePosition = Math.max(
            0,
            Math.min(cursorPosition, textContent.length)
          );
          try {
            const selection = window.getSelection();
            if (selection) {
              const range = document.createRange();
              const walker = document.createTreeWalker(
                targetElement,
                NodeFilter.SHOW_TEXT,
                null
              );
              let currentPos = 0;
              let targetNode = walker.nextNode();
              while (targetNode && currentPos + (((_a = targetNode.textContent) == null ? void 0 : _a.length) || 0) < safePosition) {
                currentPos += ((_b = targetNode.textContent) == null ? void 0 : _b.length) || 0;
                targetNode = walker.nextNode();
              }
              if (targetNode) {
                const offsetInNode = safePosition - currentPos;
                const nodeLength = ((_c = targetNode.textContent) == null ? void 0 : _c.length) || 0;
                const safeOffset = Math.max(0, Math.min(offsetInNode, nodeLength));
                range.setStart(targetNode, safeOffset);
                range.setEnd(targetNode, safeOffset);
                selection.removeAllRanges();
                selection.addRange(range);
              }
            }
          } catch (error) {
            console.warn("Failed to restore cursor position in contenteditable:", error);
          }
        }
        insertTextAtCursor(targetElement, text, cursorPosition);
        toast.success(`Inserted ${getLocalizedContent(block.title)} block`);
        setTimeout(() => {
          if (window.slashCommandService && typeof window.slashCommandService.refreshListener === "function") {
            window.slashCommandService.refreshListener();
          }
        }, 300);
      } catch (error) {
        console.error("Error inserting text:", error);
        toast.error("Failed to insert block");
      } finally {
        setTimeout(() => {
          insertingRef.current = false;
        }, 50);
      }
    }, 100);
  };
  return { insertBlock };
}
function calculateDropdownPosition(position, maxWidth = 400, maxHeight = 480, padding = 10) {
  let x = position.x;
  let y = position.y + 25;
  if (x + maxWidth > window.innerWidth - padding) {
    x = window.innerWidth - maxWidth - padding;
  }
  if (y + maxHeight > window.innerHeight - padding) {
    y = position.y - maxHeight - 10;
  }
  x = Math.max(padding, x);
  y = Math.max(padding, y);
  return { x, y };
}
const QUICK_FILTERS = [
  { type: "all", label: "All", icon: "📋" },
  { type: "role", label: "Role", icon: "👤" },
  { type: "context", label: "Context", icon: "📝" },
  { type: "goal", label: "Goal", icon: "🎯" },
  { type: "example", label: "Examples", icon: "💡" },
  { type: "constraint", label: "Constraints", icon: "🚫" }
];
const QuickBlockSelector = ({
  position,
  onClose,
  targetElement,
  onOpenFullDialog,
  cursorPosition
}) => {
  const shadowRoot = useShadowRoot();
  const { blocks, loading } = useBlocks();
  const [search, setSearch] = reactExports.useState("");
  const [selectedFilter, setSelectedFilter] = reactExports.useState("all");
  const [activeIndex, setActiveIndex] = reactExports.useState(0);
  const isDark = useThemeDetector();
  const containerRef = reactExports.useRef(null);
  const searchInputRef = reactExports.useRef(null);
  reactExports.useEffect(() => {
    var _a;
    (_a = searchInputRef.current) == null ? void 0 : _a.focus();
  }, []);
  reactExports.useEffect(() => {
    const handleClickOutside = (e) => {
      if (containerRef.current) {
        const path = e.composedPath ? e.composedPath() : [];
        if (!path.includes(containerRef.current)) {
          onClose();
        }
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [onClose]);
  const filteredBlocks = blocks.filter((b) => {
    const title = getLocalizedContent(b.title);
    const content = getLocalizedContent(b.content);
    const term = search.toLowerCase();
    const matchesSearch = title.toLowerCase().includes(term) || content.toLowerCase().includes(term);
    const matchesType = selectedFilter === "all" || b.type === selectedFilter;
    return matchesSearch && matchesType;
  });
  const handleKeyDown = reactExports.useCallback((e) => {
    if (e.key === "Escape") {
      onClose();
    } else if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveIndex((prev) => Math.min(prev + 1, filteredBlocks.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIndex((prev) => Math.max(prev - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (filteredBlocks[activeIndex]) {
        handleSelectBlock(filteredBlocks[activeIndex]);
      }
    } else if (e.key === "Tab") {
      e.preventDefault();
      const filters = QUICK_FILTERS.map((f) => f.type);
      const currentIndex = filters.indexOf(selectedFilter);
      const nextIndex = (currentIndex + 1) % filters.length;
      setSelectedFilter(filters[nextIndex]);
    }
  }, [filteredBlocks, activeIndex, selectedFilter]);
  reactExports.useEffect(() => {
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [handleKeyDown]);
  reactExports.useEffect(() => {
    setActiveIndex(0);
  }, [search, selectedFilter]);
  const { insertBlock } = useBlockInsertion(targetElement, cursorPosition, onClose);
  const handleSelectBlock = (block) => insertBlock(block);
  const openFullDialog = () => {
    onClose();
    onOpenFullDialog();
  };
  const { x, y } = calculateDropdownPosition(position);
  const darkLogo = chrome.runtime.getURL("images/full-logo-white.png");
  const lightLogo = chrome.runtime.getURL("images/full-logo-dark.png");
  return reactDomExports.createPortal(
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "div",
      {
        ref: containerRef,
        className: cn(
          "jd-fixed jd-z-[2147483647] jd-w-[400px] jd-h-[480px]",
          "jd-bg-background jd-border jd-rounded-lg jd-shadow-xl",
          "jd-flex jd-flex-col jd-animate-in jd-fade-in jd-slide-in-from-bottom-2",
          isDark ? "jd-border-gray-700" : "jd-border-gray-200"
        ),
        style: {
          left: `${x}px`,
          top: `${y}px`,
          // Ensure proper background and isolation
          backgroundColor: isDark ? "#1a1a1a" : "#ffffff",
          color: isDark ? "#ffffff" : "#000000",
          fontSize: "14px",
          lineHeight: "1.5",
          fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
          // Reset any inherited styles
          margin: 0,
          padding: 0,
          boxSizing: "border-box",
          // Ensure it's above everything
          zIndex: 2147483647,
          position: "fixed"
        },
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-flex jd-items-center jd-justify-between jd-p-3 jd-border-b jd-flex-shrink-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-flex jd-items-center jd-gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              "img",
              {
                src: isDark ? darkLogo : lightLogo,
                alt: isDark ? "Jaydai Logo Dark" : "Jaydai Logo Light",
                className: "jd-h-6 jd-pl-2"
              }
            ) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-flex jd-items-center jd-gap-1", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                Button,
                {
                  size: "sm",
                  variant: "ghost",
                  onClick: openFullDialog,
                  className: "jd-h-7 jd-px-2 jd-text-xs",
                  title: "Open block builder",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx(Maximize2, { className: "jd-h-3 jd-w-3 jd-mr-1" }),
                    "Builder"
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                Button,
                {
                  size: "sm",
                  variant: "ghost",
                  onClick: onClose,
                  className: "jd-h-7 jd-w-7 jd-p-0",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "jd-h-3 jd-w-3" })
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-p-3 jd-pb-2 jd-flex-shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-relative", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "jd-absolute jd-left-2.5 jd-top-1/2 -jd-translate-y-1/2 jd-h-3.5 jd-w-3.5 jd-text-muted-foreground" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              Input,
              {
                ref: searchInputRef,
                value: search,
                onChange: (e) => setSearch(e.target.value),
                placeholder: "Search blocks...",
                className: "jd-pl-8 jd-h-8 jd-text-sm"
              }
            )
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-px-3 jd-pb-2 jd-flex-shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-flex jd-items-center jd-gap-1 jd-flex-wrap", children: QUICK_FILTERS.map((filter2) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "button",
            {
              onClick: () => setSelectedFilter(filter2.type),
              className: cn(
                "jd-px-2 jd-py-1 jd-text-xs jd-rounded-md jd-transition-colors",
                "jd-flex jd-items-center jd-gap-1",
                selectedFilter === filter2.type ? "jd-bg-primary jd-text-primary-foreground" : "jd-bg-muted jd-hover:jd-bg-muted/80"
              ),
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: filter2.icon }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: filter2.label })
              ]
            },
            filter2.type
          )) }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-flex-1 jd-px-3 jd-pb-3 jd-min-h-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ScrollArea, { className: "jd-h-full", children: loading ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-py-8", children: /* @__PURE__ */ jsxRuntimeExports.jsx(LoadingSpinner, { size: "sm", message: "Loading blocks..." }) }) : filteredBlocks.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-py-8 jd-text-center jd-text-sm jd-text-muted-foreground", children: search ? `No blocks found for "${search}"` : "No blocks available" }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-space-y-1 jd-pr-2", children: filteredBlocks.map((block, index) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            BlockItem,
            {
              block,
              isDark,
              onSelect: handleSelectBlock,
              isActive: index === activeIndex
            },
            block.id
          )) }) }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-px-3 jd-py-2 jd-border-t jd-flex jd-items-center jd-justify-between jd-text-[10px] jd-text-muted-foreground jd-flex-shrink-0", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "↑↓ Navigate • Enter Select • Tab Filter" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              filteredBlocks.length,
              " blocks"
            ] })
          ] })
        ]
      }
    ),
    shadowRoot || document.body
  );
};
function removeTriggerFromContentEditable(element, triggerLength) {
  const selection = window.getSelection();
  if (selection && selection.rangeCount > 0) {
    const range = selection.getRangeAt(0);
    try {
      const triggerRange = document.createRange();
      const currentNode = range.startContainer;
      const currentOffset = range.startOffset;
      if (currentNode.nodeType === Node.TEXT_NODE) {
        const startOffset = Math.max(0, currentOffset - triggerLength);
        triggerRange.setStart(currentNode, startOffset);
        triggerRange.setEnd(currentNode, currentOffset);
        triggerRange.deleteContents();
        const newRange = document.createRange();
        newRange.setStart(currentNode, startOffset);
        newRange.setEnd(currentNode, startOffset);
        selection.removeAllRanges();
        selection.addRange(newRange);
      } else {
        const textContent = element.textContent || "";
        const newText = textContent.replace(/\/\/j\s?$/i, "");
        element.textContent = newText;
      }
      element.dispatchEvent(new Event("input", { bubbles: true }));
    } catch {
      const textContent = element.textContent || "";
      const newText = textContent.replace(/\/\/j\s?$/i, "");
      element.textContent = newText;
      element.dispatchEvent(new Event("input", { bubbles: true }));
    }
  } else {
    const textContent = element.textContent || "";
    const newText = textContent.replace(/\/\/j\s?$/i, "");
    element.textContent = newText;
    element.dispatchEvent(new Event("input", { bubbles: true }));
  }
}
function createTextareaMirror(textarea) {
  const mirrorDiv = document.createElement("div");
  const computedStyle = window.getComputedStyle(textarea);
  const stylesToCopy = [
    "fontFamily",
    "fontSize",
    "fontWeight",
    "lineHeight",
    "letterSpacing",
    "textTransform",
    "wordSpacing",
    "textIndent",
    "textAlign",
    "paddingTop",
    "paddingRight",
    "paddingBottom",
    "paddingLeft",
    "borderTopWidth",
    "borderRightWidth",
    "borderBottomWidth",
    "borderLeftWidth",
    "borderTopStyle",
    "borderRightStyle",
    "borderBottomStyle",
    "borderLeftStyle",
    "whiteSpace",
    "wordWrap",
    "overflowWrap"
  ];
  stylesToCopy.forEach((prop) => {
    mirrorDiv.style[prop] = computedStyle.getPropertyValue(prop);
  });
  mirrorDiv.style.position = "absolute";
  mirrorDiv.style.top = "0";
  mirrorDiv.style.left = "0";
  mirrorDiv.style.visibility = "hidden";
  mirrorDiv.style.height = "auto";
  mirrorDiv.style.width = textarea.offsetWidth + "px";
  mirrorDiv.style.minHeight = textarea.offsetHeight + "px";
  mirrorDiv.style.overflow = "hidden";
  return mirrorDiv;
}
function getCursorCoordinates(element) {
  if (element instanceof HTMLTextAreaElement) {
    const selectionStart = element.selectionStart || 0;
    const mirrorDiv = createTextareaMirror(element);
    const textBeforeCursor = element.value.substring(0, selectionStart);
    mirrorDiv.textContent = textBeforeCursor;
    const cursorSpan = document.createElement("span");
    cursorSpan.textContent = "|";
    mirrorDiv.appendChild(cursorSpan);
    document.body.appendChild(mirrorDiv);
    const spanRect = cursorSpan.getBoundingClientRect();
    const x = spanRect.left;
    const y = spanRect.top - element.scrollTop;
    document.body.removeChild(mirrorDiv);
    return { x, y };
  }
  if (element.isContentEditable) {
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      const tempSpan = document.createElement("span");
      tempSpan.style.position = "absolute";
      tempSpan.textContent = "|";
      try {
        range.insertNode(tempSpan);
        const rect2 = tempSpan.getBoundingClientRect();
        const x = rect2.left;
        const y = rect2.top;
        tempSpan.remove();
        return { x, y };
      } catch {
        tempSpan.remove();
        const rect2 = element.getBoundingClientRect();
        return { x: rect2.left, y: rect2.top };
      }
    }
  }
  if (element instanceof HTMLInputElement) {
    const selectionStart = element.selectionStart || 0;
    const tempElement = document.createElement("span");
    const computedStyle = window.getComputedStyle(element);
    tempElement.style.font = computedStyle.font;
    tempElement.style.fontSize = computedStyle.fontSize;
    tempElement.style.fontFamily = computedStyle.fontFamily;
    tempElement.style.fontWeight = computedStyle.fontWeight;
    tempElement.style.letterSpacing = computedStyle.letterSpacing;
    tempElement.style.position = "absolute";
    tempElement.style.visibility = "hidden";
    tempElement.style.whiteSpace = "pre";
    const textBeforeCursor = element.value.substring(0, selectionStart);
    tempElement.textContent = textBeforeCursor;
    document.body.appendChild(tempElement);
    const rect2 = element.getBoundingClientRect();
    const textWidth = tempElement.offsetWidth;
    const paddingLeft = parseFloat(computedStyle.paddingLeft) || 0;
    const x = rect2.left + paddingLeft + textWidth;
    const y = rect2.top;
    document.body.removeChild(tempElement);
    return { x, y };
  }
  const rect = element.getBoundingClientRect();
  return { x: rect.left, y: rect.top };
}
function getCursorTextPosition(element) {
  var _a;
  if (element instanceof HTMLTextAreaElement || element instanceof HTMLInputElement) {
    return element.selectionStart || 0;
  }
  if (element.isContentEditable) {
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      const walker = document.createTreeWalker(element, NodeFilter.SHOW_TEXT, null);
      let position = 0;
      let currentNode = walker.nextNode();
      while (currentNode && currentNode !== range.startContainer) {
        position += ((_a = currentNode.textContent) == null ? void 0 : _a.length) || 0;
        currentNode = walker.nextNode();
      }
      if (currentNode === range.startContainer) {
        position += range.startOffset;
      }
      return position;
    }
  }
  return 0;
}
const _SlashCommandService = class _SlashCommandService extends AbstractBaseService {
  // Prevent double insertion
  constructor() {
    super();
    __publicField(this, "inputEl", null);
    __publicField(this, "documentListenerAttached", false);
    __publicField(this, "observer", null);
    __publicField(this, "quickSelectorRoot", null);
    __publicField(this, "quickSelectorContainer", null);
    __publicField(this, "isQuickSelectorOpen", false);
    __publicField(this, "isInserting", false);
    /**
     * Get current cursor position in text content (not screen coordinates)
     */
    __publicField(this, "handleInput", (e) => {
      if (this.isQuickSelectorOpen || this.isInserting) {
        return;
      }
      const target = e.target;
      const config2 = getConfigByHostname(window.location.hostname);
      if (!config2) return;
      const promptEl = target.closest(config2.domSelectors.PROMPT_TEXTAREA);
      if (!promptEl) return;
      this.inputEl = promptEl;
      let value = "";
      let originalCursorPos = 0;
      if (target instanceof HTMLTextAreaElement) {
        value = target.value;
        originalCursorPos = target.selectionStart || 0;
      } else if (target instanceof HTMLElement && target.isContentEditable) {
        value = target.innerText || target.textContent || "";
        originalCursorPos = getCursorTextPosition(target);
      }
      const triggerRegex = /\/\/j\s?$/i;
      if (triggerRegex.test(value)) {
        console.log("Slash command detected:", { value: value.substring(Math.max(0, value.length - 20)), originalCursorPos });
        this.isInserting = true;
        const triggerMatch = value.match(triggerRegex);
        const triggerLength = triggerMatch ? triggerMatch[0].length : 0;
        const newCursorPos = Math.max(0, originalCursorPos - triggerLength);
        console.log("Cursor calculation:", {
          originalCursorPos,
          triggerLength,
          newCursorPos,
          valueLength: value.length
        });
        const newValue = value.replace(triggerRegex, "");
        if (target instanceof HTMLTextAreaElement) {
          target.value = newValue;
          const safeCursorPos = Math.min(newCursorPos, newValue.length);
          target.setSelectionRange(safeCursorPos, safeCursorPos);
          target.dispatchEvent(new Event("input", { bubbles: true }));
          target.dispatchEvent(new Event("change", { bubbles: true }));
        } else if (target instanceof HTMLElement && target.isContentEditable) {
          removeTriggerFromContentEditable(target, triggerLength);
        }
        setTimeout(() => {
          try {
            target.focus();
            const position = getCursorCoordinates(target);
            const safeCursorPos = target instanceof HTMLTextAreaElement ? Math.min(newCursorPos, target.value.length) : Math.min(newCursorPos, (target.textContent || "").length);
            console.log("Showing quick selector at position:", { position, safeCursorPos });
            this.showQuickSelector(position, target, safeCursorPos);
          } catch (error) {
            console.error("Error showing quick selector:", error);
          } finally {
            setTimeout(() => {
              this.isInserting = false;
            }, 100);
          }
        }, 50);
      }
    });
  }
  static getInstance() {
    if (!_SlashCommandService.instance) {
      _SlashCommandService.instance = new _SlashCommandService();
    }
    return _SlashCommandService.instance;
  }
  /**
   * Publicly accessible method to refresh the listener
   * Useful after DOM changes or insertions
   */
  refreshListener() {
    console.log("Manually refreshing slash command listener...");
    this.attachListener();
  }
  /**
   * Enhanced initialization with retry mechanism
   */
  async onInitialize() {
    this.attachListener();
    this.observeDom();
    window.slashCommandService = this;
    setInterval(() => {
      this.attachListener();
    }, 2e3);
  }
  onCleanup() {
    this.detachListener();
    if (this.observer) {
      this.observer.disconnect();
      this.observer = null;
    }
    this.closeQuickSelector();
    if (window.slashCommandService === this) {
      delete window.slashCommandService;
    }
  }
  observeDom() {
    this.observer = new MutationObserver(() => {
      setTimeout(() => this.attachListener(), 100);
    });
    this.observer.observe(document.body, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true
    });
  }
  attachListener() {
    const config2 = getConfigByHostname(window.location.hostname);
    if (!config2) return;
    if (!this.documentListenerAttached) {
      document.addEventListener("input", this.handleInput, true);
      this.documentListenerAttached = true;
    }
    const el = document.querySelector(config2.domSelectors.PROMPT_TEXTAREA);
    if (el) this.inputEl = el;
  }
  detachListener() {
    if (this.documentListenerAttached) {
      document.removeEventListener("input", this.handleInput, true);
      this.documentListenerAttached = false;
    }
    this.inputEl = null;
  }
  /**
   * Enhanced cursor position calculation that works accurately for different element types
   */
  showQuickSelector(position, targetElement, cursorPosition) {
    this.closeQuickSelector();
    this.quickSelectorContainer = document.createElement("div");
    this.quickSelectorContainer.id = "jaydai-quick-selector";
    document.body.appendChild(this.quickSelectorContainer);
    this.quickSelectorRoot = createRoot(this.quickSelectorContainer);
    this.quickSelectorRoot.render(
      React.createElement(QuickBlockSelector, {
        position,
        onClose: () => this.closeQuickSelector(),
        targetElement,
        cursorPosition,
        onOpenFullDialog: () => {
          if (window.dialogManager && typeof window.dialogManager.openDialog === "function") {
            window.dialogManager.openDialog(DIALOG_TYPES.INSERT_BLOCK);
          }
        }
      })
    );
    this.isQuickSelectorOpen = true;
  }
  closeQuickSelector() {
    if (this.quickSelectorRoot) {
      this.quickSelectorRoot.unmount();
      this.quickSelectorRoot = null;
    }
    if (this.quickSelectorContainer) {
      this.quickSelectorContainer.remove();
      this.quickSelectorContainer = null;
    }
    this.isQuickSelectorOpen = false;
    setTimeout(() => {
      this.isInserting = false;
    }, 100);
  }
};
__publicField(_SlashCommandService, "instance");
let SlashCommandService = _SlashCommandService;
SlashCommandService.getInstance();
function registerServices() {
  serviceManager.registerService("chat.network", ChatService.getInstance());
  serviceManager.registerService("message.network", MessageService.getInstance());
  serviceManager.registerService("auth.token", TokenService.getInstance());
  serviceManager.registerService("auth.state", AuthService.getInstance(), [
    "auth.token"
  ]);
  serviceManager.registerService("notifications", NotificationService.getInstance());
  serviceManager.registerService("stats", StatsService.getInstance());
  serviceManager.registerService("ui.slash", SlashCommandService.getInstance());
  serviceManager.registerService("auth", AuthService.getInstance());
  serviceManager.registerService("user", UserProfileService.getInstance());
  console.log("All services registered with ServiceManager");
}
export {
  getBlockTypeLabel as $,
  AuthForm as A,
  apiClient as B,
  Check as C,
  getAdapterByHostname as D,
  EVENTS as E,
  FocusScope as F,
  incrementUserProperty as G,
  DIALOG_TYPES as H,
  Item$1 as I,
  ChevronDown as J,
  Search as K,
  RefreshCw as L,
  notificationService as M,
  LoadingSpinner as N,
  errorReporter as O,
  AppError as P,
  ErrorCode as Q,
  ReactRemoveScroll as R,
  Sparkles as S,
  Textarea as T,
  Users as U,
  isMultipleValueBlock as V,
  getLocalizedContent as W,
  X,
  Maximize2 as Y,
  Zap as Z,
  ScrollArea as _,
  useShadowRoot as a,
  getBlockTypeColors as a0,
  getBlockIconColors as a1,
  ChevronUp as a2,
  Ban as a3,
  Palette as a4,
  PanelsTopLeft as a5,
  Type as a6,
  Target as a7,
  MessageSquare as a8,
  User as a9,
  BLOCK_TYPES as aa,
  blocksApi as ab,
  Tabs as ac,
  TabsList as ad,
  TabsTrigger as ae,
  TabsContent as af,
  BLOCK_TYPE_LABELS as ag,
  getBlockTypeIcon as ah,
  buildPromptPart as ai,
  buildPromptPartHtml as aj,
  insertIntoPromptArea as ak,
  componentInjector as al,
  Select as b,
  SelectTrigger as c,
  SelectValue as d,
  SelectContent as e,
  SelectItem as f,
  ArrowLeft as g,
  hideOthers as h,
  ArrowRight as i,
  usePrevious as j,
  createRovingFocusGroupScope as k,
  useDirection as l,
  Root as m,
  Star as n,
  CircleCheckBig as o,
  userApi as p,
  serviceManager as q,
  registerServices as r,
  setUserProperties as s,
  trackEvent as t,
  useFocusGuards as u,
  setAmplitudeUserId as v,
  initAmplitude as w,
  getBlockTextColors as x,
  useThemeDetector as y,
  FileText as z
};
//# sourceMappingURL=index.D7-A2koz.js.map
