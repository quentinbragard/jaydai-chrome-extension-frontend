import { j as jsxRuntimeExports, J, c as createLucideIcon, r as reactExports, L as Label, g as getMessage, I as Input, B as Button, a as LogIn, U as UserPlus, b as authService, t as toast, C as ChevronRight, E as ExternalLink, d as client, R as React } from "./assets/index.DcWboGrL.js";
import { C as CardContent, M as Mail, L as Lock, a as CardFooter, b as CardHeader, T as TooltipProvider, c as Tooltip, d as TooltipTrigger, e as TooltipContent, f as Linkedin, g as Card } from "./assets/tooltip.BbLxkD_S.js";
import { T as Toaster } from "./assets/sonner.ByJ12Hh4.js";
function ThemeProvider({
  children,
  ...props
}) {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(J, { ...props, children });
}
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$2 = [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3", key: "1u773s" }],
  ["path", { d: "M12 17h.01", key: "p32p05" }]
];
const CircleHelp = createLucideIcon("CircleHelp", __iconNode$2);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode$1 = [
  ["path", { d: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4", key: "1uf3rs" }],
  ["polyline", { points: "16 17 21 12 16 7", key: "1gabdz" }],
  ["line", { x1: "21", x2: "9", y1: "12", y2: "12", key: "1uyos4" }]
];
const LogOut = createLucideIcon("LogOut", __iconNode$1);
/**
 * @license lucide-react v0.482.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const __iconNode = [
  [
    "path",
    {
      d: "M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z",
      key: "1qme2f"
    }
  ],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }]
];
const Settings = createLucideIcon("Settings", __iconNode);
const LoginForm = ({
  authState,
  onWelcomePageClick
}) => {
  const [email, setEmail] = reactExports.useState("");
  const [password, setPassword] = reactExports.useState("");
  const [isLoggingIn, setIsLoggingIn] = reactExports.useState(false);
  const [loginError, setLoginError] = reactExports.useState(null);
  const handleEmailLogin = async () => {
    if (!email.trim() || !password) {
      setLoginError(getMessage("invalidCredentials", void 0, "Please enter both email and password"));
      return;
    }
    setIsLoggingIn(true);
    setLoginError(null);
    try {
      const success = await authService.signInWithEmail(email, password);
      if (success) {
        toast.success(getMessage("signInSuccessful", void 0, "Sign-in successful"));
      } else {
        setLoginError(authState.error || getMessage("invalidCredentials", void 0, "Invalid email or password"));
      }
    } catch (error) {
      setLoginError(getMessage("loginFailed", void 0, "Login failed. Please try again."));
      console.error("Login error:", error);
    } finally {
      setIsLoggingIn(false);
    }
  };
  const handleGoogleLogin = async () => {
    setIsLoggingIn(true);
    setLoginError(null);
    try {
      const success = await authService.signInWithGoogle();
      if (success) {
        toast.success(getMessage("signInSuccessful", void 0, "Sign-in successful"));
      } else {
        setLoginError(authState.error || getMessage("loginFailed", void 0, "Google login failed"));
      }
    } catch (error) {
      setLoginError(getMessage("loginFailed", void 0, "Login failed. Please try again."));
      console.error("Google login error:", error);
    } finally {
      setIsLoggingIn(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(CardContent, { className: "jd-p-4 jd-space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-space-y-3", children: [
      loginError && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-bg-red-500/10 jd-text-red-500 jd-border-red-300/20 jd-p-3 jd-rounded-lg jd-text-sm jd-font-medium jd-shadow-sm jd-backdrop-blur-sm jd-flex jd-items-start jd-space-x-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-flex-shrink-0 jd-mt-0.5", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("circle", { cx: "12", cy: "12", r: "10" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "12", y1: "8", x2: "12", y2: "12" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("line", { x1: "12", y1: "16", x2: "12.01", y2: "16" })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-flex-1", children: loginError })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-space-y-2 jd-text-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "email-signin", className: "jd-font-medium jd-text-sm", children: getMessage("email", void 0, "Email") }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-relative jd-group", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Input,
            {
              id: "email-signin",
              type: "email",
              placeholder: "you@example.com",
              value: email,
              onChange: (e) => setEmail(e.target.value),
              className: "jd-pl-11 jd-pr-4 jd-py-2 jd-bg-card/80 jd-backdrop-blur-sm jd-border-input jd-focus:jd-ring-2 jd-focus:jd-ring-blue-500/20 jd-focus:jd-border-blue-500 jd-transition-all jd-rounded-lg",
              disabled: isLoggingIn
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-absolute jd-left-3 jd-top-1/2 -jd-translate-y-1/2 jd-text-muted-foreground group-focus-within:jd-text-blue-500 jd-transition-colors", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Mail, { className: "jd-h-5 jd-w-5" }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-space-y-2 jd-text-foreground", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-flex jd-justify-between jd-items-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Label, { htmlFor: "password-signin", className: "jd-font-medium jd-text-sm", children: getMessage("password", void 0, "Password") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "link", className: "jd-p-0 jd-h-auto jd-text-xs jd-text-blue-500 hover:jd-text-blue-400 jd-transition-colors", children: getMessage("forgotPassword", void 0, "Forgot?") })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-relative jd-group", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            Input,
            {
              id: "password-signin",
              type: "password",
              placeholder: "••••••••",
              value: password,
              onChange: (e) => setPassword(e.target.value),
              className: "jd-pl-11 jd-pr-4 jd-py-2 jd-bg-card/80 jd-backdrop-blur-sm jd-border-input jd-focus:jd-ring-2 jd-focus:jd-ring-blue-500/20 jd-focus:jd-border-blue-500 jd-transition-all jd-rounded-lg",
              disabled: isLoggingIn,
              onKeyDown: (e) => {
                if (e.key === "Enter") {
                  handleEmailLogin();
                }
              }
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-absolute jd-left-3 jd-top-1/2 -jd-translate-y-1/2 jd-text-muted-foreground group-focus-within:jd-text-blue-500 jd-transition-colors", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Lock, { className: "jd-h-5 jd-w-5" }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        Button,
        {
          onClick: handleEmailLogin,
          className: "jd-w-full jd-bg-gradient-to-r jd-from-blue-600 jd-to-indigo-600 hover:jd-from-blue-700 hover:jd-to-indigo-700 jd-transition-all jd-duration-300 jd-py-5 jd-mt-3 jd-rounded-lg jd-relative jd-overflow-hidden jd-group jd-border-none",
          disabled: isLoggingIn,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-absolute jd-inset-0 jd-w-full jd-h-full jd-bg-gradient-to-r jd-from-blue-600/0 jd-via-blue-400/10 jd-to-blue-600/0 jd-transform jd-skew-x-12 jd-translate-x-full group-hover:jd-translate-x-full jd-transition-transform jd-duration-1000 jd-ease-out" }),
            isLoggingIn ? /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "jd-flex jd-items-center jd-justify-center", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-spinner-sm jd-mr-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-double-bounce1" }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-double-bounce2" })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: getMessage("signingIn", void 0, "Signing in...") })
            ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "jd-flex jd-items-center jd-justify-center", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(LogIn, { className: "jd-h-4 jd-w-4 jd-mr-2" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: getMessage("signIn", void 0, "Sign In") })
            ] })
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-relative jd-my-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-absolute jd-inset-0 jd-flex jd-items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-w-full jd-border-t jd-border-muted" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-relative jd-flex jd-justify-center jd-text-xs jd-font-medium", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "jd-px-4 jd-py-1 jd-bg-background jd-text-muted-foreground jd-rounded-full jd-border jd-border-muted", children: getMessage("or", void 0, "Or continue with") }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-grid jd-gap-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        Button,
        {
          variant: "outline",
          onClick: handleGoogleLogin,
          className: "jd-w-full jd-border-muted hover:jd-bg-muted/10 jd-transition-all jd-duration-300 jd-py-5 jd-rounded-lg jd-group jd-relative jd-overflow-hidden",
          disabled: isLoggingIn,
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-absolute jd-inset-0 jd-bg-gradient-to-r jd-from-red-500/5 jd-via-blue-500/5 jd-to-green-500/5 jd-opacity-0 group-hover:jd-opacity-100 jd-transition-opacity jd-duration-500" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "jd-flex jd-items-center jd-justify-center jd-relative jd-z-10", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-flex jd-items-center jd-justify-center jd-w-6 jd-h-6 jd-bg-white jd-rounded-full jd-shadow-sm jd-mr-3 group-hover:jd-shadow group-hover:jd-scale-110 jd-transition-all jd-duration-300 jd-overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                "img",
                {
                  src: "https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg",
                  alt: "Google",
                  className: "jd-h-4 jd-w-4 jd-object-contain",
                  style: { display: "block" }
                }
              ) }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "jd-font-medium", children: getMessage("signInWith", ["Google"], "Sign in with Google") })
            ] })
          ]
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-relative", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-absolute jd-inset-x-0 jd-top-1/2 jd-h-px jd-bg-gradient-to-r jd-from-transparent jd-via-muted jd-to-transparent jd-translate-y-1/2" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(
        Button,
        {
          variant: "ghost",
          onClick: onWelcomePageClick,
          className: "jd-w-full jd-text-blue-600 hover:jd-text-blue-500 hover:jd-bg-blue-50/30 jd-dark:hover:jd-bg-blue-950/20 jd-transition-all jd-duration-300 jd-py-5 jd-rounded-lg jd-relative jd-overflow-hidden jd-group",
          children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-absolute jd-inset-0 jd-bg-gradient-to-r jd-from-blue-500/0 jd-via-blue-500/5 jd-to-blue-500/0 jd-opacity-0 group-hover:jd-opacity-100 jd-transition-opacity jd-duration-500" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "jd-flex jd-items-center jd-justify-center jd-space-x-2 jd-relative jd-z-10", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(UserPlus, { className: "jd-h-4 jd-w-4 group-hover:jd-scale-110 jd-transition-transform jd-duration-300" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "jd-font-medium", children: getMessage("createAccount", void 0, "Create Account") })
            ] })
          ]
        }
      )
    ] })
  ] });
};
const ToolCard = ({
  tool,
  onClick
}) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-relative jd-group jd-perspective jd-mb-3", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: `jd-absolute jd-inset-0 jd-bg-gradient-to-r jd-${tool.color} jd-rounded-lg jd-m-0.5 
                   jd-opacity-0 group-hover:jd-opacity-100 jd-transition-all jd-duration-300
                   jd-blur-[2px] group-hover:jd-blur-[1px] jd-scale-[0.97] group-hover:jd-scale-100`
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Button,
      {
        variant: "default",
        className: `jd-w-full jd-justify-start jd-py-6 jd-px-4 jd-relative 
                   jd-bg-card/95 jd-border jd-border-gray-800/30 
                   jd-shadow-sm hover:jd-shadow-lg jd-rounded-lg
                   jd-transition-all jd-duration-300 jd-ease-out
                   group-hover:jd-translate-y-[-2px] group-hover:jd-border-gray-700/50
                   ${tool.disabled ? "jd-opacity-80 hover:jd-opacity-80 jd-cursor-not-allowed" : ""}`,
        onClick,
        disabled: tool.disabled,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-flex jd-items-center jd-w-full jd-gap-3", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `jd-flex-shrink-0 jd-p-2 jd-rounded-md
                         jd-transition-all jd-duration-300
                         jd-bg-gradient-to-br jd-from-background/90 jd-to-background
                         group-hover:jd-shadow-md jd-shadow-sm
                         jd-border jd-border-gray-800/40 group-hover:jd-border-gray-700/70
                         ${!tool.disabled ? "group-hover:jd-scale-110" : ""}`, children: tool.icon }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-flex-grow jd-text-left jd-overflow-hidden", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-font-semibold jd-text-foreground group-hover:jd-text-white jd-transition-colors jd-duration-300", children: tool.name }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-text-xs jd-text-muted-foreground jd-truncate jd-max-w-[160px] group-hover:jd-text-gray-300 jd-transition-colors jd-duration-300", children: tool.description })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-flex-shrink-0 jd-ml-1 jd-text-muted-foreground jd-opacity-70 group-hover:jd-opacity-100 jd-transition-opacity jd-duration-300", children: !tool.disabled ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-p-1 jd-rounded-full jd-bg-gray-800/50 group-hover:jd-bg-blue-600/20 jd-transition-colors jd-duration-300", children: /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "jd-h-4 jd-w-4 group-hover:jd-text-blue-400 jd-transition-colors jd-duration-300" }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "jd-text-[10px] jd-font-medium jd-opacity-60", children: getMessage("comingSoon", void 0, "Coming Soon") }) })
          ] }),
          !tool.disabled && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-absolute jd-top-0 jd-left-0 jd-w-full jd-h-full jd-overflow-hidden jd-rounded-lg jd-pointer-events-none jd-opacity-40 group-hover:jd-opacity-70 jd-transition-opacity jd-duration-300", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-absolute jd-top-1 jd-right-1 jd-w-10 jd-h-10 jd-bg-blue-500/20 jd-rounded-full jd-blur-sm" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-absolute jd-bottom-1 jd-left-1 jd-w-12 jd-h-12 jd-bg-indigo-500/20 jd-rounded-full jd-blur-sm" })
          ] })
        ]
      }
    )
  ] });
};
const AI_TOOLS = [
  {
    name: "ChatGPT",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: "https://vetoswvwgsebhxetqppa.supabase.co/storage/v1/object/public/images//chatgpt_logo.png", alt: "ChatGPT", className: "jd-h-8 jd-w-8" }),
    url: "https://chat.openai.com/",
    description: "OpenAI's conversational AI",
    disabled: false,
    color: "jd-from-green-500/20 jd-to-emerald-500/20"
  },
  {
    name: "Claude",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: "https://vetoswvwgsebhxetqppa.supabase.co/storage/v1/object/public/images//claude_logo.png", alt: "Claude", className: "jd-h-8 jd-w-8" }),
    url: "https://claude.ai/",
    description: "Anthropic's AI assistant",
    disabled: true,
    color: "jd-from-purple-500/20 jd-to-indigo-500/20"
  },
  {
    name: "Gemini",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: "https://vetoswvwgsebhxetqppa.supabase.co/storage/v1/object/public/images//gemini_logo.png", alt: "Gemini", className: "jd-h-8 jd-w-8" }),
    url: "https://gemini.google.com/",
    description: "Google's generative AI",
    disabled: true,
    color: "jd-from-blue-500/20 jd-to-sky-500/20"
  },
  {
    name: "Mistral",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: "https://vetoswvwgsebhxetqppa.supabase.co/storage/v1/object/public/images//mistral_logo.png", alt: "Mistral", className: "jd-h-8 jd-w-8" }),
    url: "https://chat.mistral.ai/",
    description: "Mistral AI's conversational model",
    disabled: true,
    color: "jd-from-amber-500/20 jd-to-yellow-500/20"
  },
  {
    name: "Perplexity",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: "https://vetoswvwgsebhxetqppa.supabase.co/storage/v1/object/public/images//perplexity_logo.png", alt: "Perplexity", className: "jd-h-8 jd-w-8" }),
    url: "https://www.perplexity.ai/",
    description: "AI-powered search and chat",
    disabled: true,
    color: "jd-from-pink-500/20 jd-to-rose-500/20"
  }
];
const ToolGrid = ({
  onLogout,
  onOpenChatGPT
}) => {
  const openTool = (url) => {
    chrome.tabs.create({ url });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(CardContent, { className: "jd-p-4 jd-space-y-3 jd-mt-2", children: AI_TOOLS.map((tool) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      ToolCard,
      {
        tool,
        onClick: () => !tool.disabled && openTool(tool.url)
      },
      tool.name
    )) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(CardFooter, { className: "jd-border-t jd-border-muted jd-pt-3 jd-pb-3 jd-flex jd-justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-w-full jd-px-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
      Button,
      {
        variant: "ghost",
        className: "jd-w-full jd-text-red-500 hover:jd-text-red-600 hover:jd-bg-red-50 jd-dark:hover:jd-bg-red-950/30 jd-gap-2 jd-transition-all jd-duration-300 jd-py-5 jd-rounded-lg jd-group jd-border-none",
        onClick: onLogout,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(LogOut, { className: "jd-h-4 jd-w-4 group-hover:jd-rotate-12 jd-transition-transform jd-duration-300" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "jd-font-medium", children: getMessage("signOut", void 0, "Sign Out") })
        ]
      }
    ) }) })
  ] });
};
const LoadingState = () => {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-w-80 jd-bg-gradient-to-b jd-from-background jd-to-background/90 jd-text-foreground jd-flex jd-flex-col jd-items-center jd-justify-center jd-h-64 jd-p-4 jd-space-y-4", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-relative", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-spinner", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-double-bounce1" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-double-bounce2" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-absolute jd-inset-0 jd-bg-gradient-to-r jd-from-blue-500/20 jd-to-indigo-500/20 jd-blur-xl jd-rounded-full" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-flex jd-flex-col jd-items-center jd-space-y-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "jd-text-sm jd-animate-pulse", children: getMessage("loadingTools", void 0, "Loading your AI tools") }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-w-16 jd-h-1 jd-bg-muted jd-rounded-full jd-overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-h-full jd-bg-gradient-to-r jd-from-blue-500 jd-to-indigo-500 jd-w-1/2 jd-animate-[gradient-shift_1s_ease_infinite]" }) })
    ] })
  ] });
};
const AppHeader = ({
  isAuthenticated,
  user
}) => {
  const logo = chrome.runtime.getURL("images/full-logo-white.png");
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(CardHeader, { className: "jd-pb-2 jd-relative jd-overflow-hidden", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-absolute jd-inset-0 jd-bg-gradient-to-r jd-from-indigo-600 jd-to-blue-500 jd-opacity-90 jd-bg-animate jd-rounded-lg" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-absolute jd-inset-0 jd-bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTAwIiBoZWlnaHQ9IjUwMCIgdmlld0JveD0iMCAwIDUwMCA1MDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PHBhdGggZD0iTTIwMC44NzYgMTYwLjAwOGM2LjgxOCA2LjgxOCAxNi4xMTQgMTEuMDM5IDI2LjQxNCAxMS4wMzlzMTkuNTk2LTQuMjIxIDI2LjQxNC0xMS4wMzlsLjAwMS0uMDAxYzYuODE5LTYuODE4IDExLjA0MS0xNi4xMTQgMTEuMDQxLTI2LjQxNCAwLTEwLjMtNC4yMjItMTkuNTk3LTExLjA0MS0yNi40MTYtNi44MTgtNi44MTgtMTYuMTE0LTExLjA0LTI2LjQxNC0xMS4wNC0xMC4zIDAtMTkuNTk2IDQuMjIyLTI2LjQxNCAxMS4wNGwtLjAwMi4wMDFjLTYuODE4IDYuODE5LTExLjAzOSAxNi4xMTQtMTEuMDM5IDI2LjQxNCAwIDEwLjMgNC4yMjEgMTkuNTk2IDExLjAzOSAyNi40MTRsLjAwMS4wMDFaIiBmaWxsPSIjZmZmZmZmMTAiLz48cGF0aCBkPSJNMjU2IDMwNmM4LjI4NCAwIDE1LTYuNzE2IDE1LTE1IDAtOC4yODQtNi43MTYtMTUtMTUtMTVzLTE1IDYuNzE2LTE1IDE1YzAgOC4yODQgNi43MTYgMTUgMTUgMTVaIiBmaWxsPSIjZmZmZmZmMTAiLz48cGF0aCBkPSJNMTg4IDM3MC41YzAgMTEuODc0IDkuNjI2IDIxLjUgMjEuNSAyMS41UzIzMSAzODIuMzc0IDIzMSAzNzAuNSAyMjEuMzc0IDM0OSAyMDkuNSAzNDkgMTg4IDM1OC42MjYgMTg4IDM3MC41WiIgZmlsbD0iI2ZmZmZmZjEwIi8+PHBhdGggZD0iTTMxNCAyODVjMCA0LjQ0Mi0zLjU1OCA4LTggOHMtOC0zLjU1OC04LTggMy41NTgtOCA4LTggOCAzLjU1OCA4IDhaIiBmaWxsPSIjZmZmZmZmMTAiLz48L3N2Zz4=')] bg-cover opacity-50" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-absolute jd-top-0 jd-right-0 jd-w-24 jd-h-24 jd-bg-white jd-opacity-5 jd-rounded-full jd-transform jd-translate-x-8 jd-translate-y-8" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-absolute jd-bottom-0 jd-left-0 jd-w-16 jd-h-16 jd-bg-white jd-opacity-5 jd-rounded-full jd-transform jd-translate-x-8 jd-translate-y-8" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-relative jd-z-10", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-flex jd-items-center jd-justify-between", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-flex jd-items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-w-16 jd-h-16 jd-rounded-md  jd-flex jd-items-center jd-justify-center jd-mr-3", children: /* @__PURE__ */ jsxRuntimeExports.jsx("img", { src: logo, alt: "Logo", className: "jd-object-contain" }) }) }),
        isAuthenticated && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-flex jd-items-center jd-space-x-1 jd-bg-white/10 jd-backdrop-blur-sm jd-rounded-full jd-px-2 jd-py-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "jd-w-2 jd-h-2 jd-bg-green-400 jd-rounded-full jd-animate-pulse" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "jd-text-xs jd-text-white/90 jd-font-medium", children: getMessage("online", void 0, "Online") })
        ] })
      ] }),
      isAuthenticated && user && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-text-sm jd-text-blue-100 jd-mt-2 jd-flex jd-items-center", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-glass jd-px-3 jd-py-1 jd-rounded-full jd-text-xs jd-flex jd-items-center jd-space-x-1 jd-backdrop-blur-sm jd-bg-white/10 jd-shadow-inner", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "jd-text-white/90", children: getMessage("signedInAs", void 0, "Signed in as") }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "jd-font-semibold jd-text-white jd-truncate jd-max-w-[180px]", children: user.email || user.name })
      ] }) })
    ] })
  ] });
};
const AppFooter = ({
  version = chrome.runtime.getManifest().version,
  onSettingsClick
}) => {
  const handleLinkedInClick = () => {
    chrome.tabs.create({ url: "https://www.linkedin.com/company/jaydai" });
  };
  const handleWebsiteClick = () => {
    chrome.tabs.create({ url: "https://jayd.ai" });
  };
  const handleHelpClick = () => {
    chrome.tabs.create({ url: "https://www.jayd.ai/" });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(CardFooter, { className: "jd-p-3 jd-border-t jd-border-muted jd-flex jd-flex-col jd-items-center", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-w-full jd-flex jd-justify-between jd-items-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-flex jd-items-center jd-gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(TooltipProvider, { children: [
        onSettingsClick && /* @__PURE__ */ jsxRuntimeExports.jsxs(Tooltip, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TooltipTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            Button,
            {
              variant: "ghost",
              size: "icon",
              className: "jd-h-8 jd-w-8 jd-rounded-full jd-bg-transparent hover:jd-bg-muted",
              onClick: onSettingsClick,
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(Settings, { className: "jd-h-4 jd-w-4 jd-text-muted-foreground" })
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TooltipContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: getMessage("settings", void 0, "Settings") }) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(Tooltip, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(TooltipTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            Button,
            {
              variant: "ghost",
              size: "icon",
              className: "jd-h-8 jd-w-8 jd-rounded-full jd-bg-transparent hover:jd-bg-muted",
              onClick: handleHelpClick,
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(CircleHelp, { className: "jd-h-4 jd-w-4 jd-text-muted-foreground" })
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(TooltipContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: getMessage("help", void 0, "Help") }) })
        ] })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "jd-flex jd-items-center jd-gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "jd-text-xs jd-text-muted-foreground jd-mr-1", children: [
          "Archimind v",
          version
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(TooltipProvider, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Tooltip, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TooltipTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              Button,
              {
                variant: "ghost",
                size: "icon",
                className: "jd-h-8 jd-w-8 jd-rounded-full jd-bg-transparent hover:jd-bg-muted",
                onClick: handleLinkedInClick,
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(Linkedin, { className: "jd-h-4 jd-w-4 jd-text-muted-foreground" })
              }
            ) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TooltipContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: getMessage("linkedin", void 0, "LinkedIn") }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(Tooltip, { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TooltipTrigger, { asChild: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              Button,
              {
                variant: "ghost",
                size: "icon",
                className: "jd-h-8 jd-w-8 jd-rounded-full jd-bg-transparent hover:jd-bg-muted",
                onClick: handleWebsiteClick,
                children: /* @__PURE__ */ jsxRuntimeExports.jsx(ExternalLink, { className: "jd-h-4 jd-w-4 jd-text-muted-foreground" })
              }
            ) }),
            /* @__PURE__ */ jsxRuntimeExports.jsx(TooltipContent, { children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: getMessage("website", void 0, "Website") }) })
          ] })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-text-[10px] jd-text-center jd-text-muted-foreground/60 jd-mt-1 jd-px-4", children: getMessage("aiCompanion", void 0, "Your AI companion for effective tool usage") })
  ] });
};
const ExtensionPopup = () => {
  const [authState, setAuthState] = reactExports.useState({
    user: null,
    isAuthenticated: false,
    isLoading: true,
    error: null
  });
  reactExports.useEffect(() => {
    const unsubscribe = authService.subscribe((state) => {
      setAuthState(state);
    });
    if (!authService.isInitialized()) {
      authService.initialize();
    }
    return () => {
      unsubscribe();
    };
  }, []);
  const handleLogout = async () => {
    try {
      await authService.signOut();
      toast.success(getMessage("signedOut", void 0, "Signed out successfully"));
    } catch (error) {
      console.error("Logout error:", error);
      toast.error(getMessage("logoutFailed", void 0, "Failed to sign out"));
    }
  };
  const openChatGPT = () => {
    chrome.tabs.create({ url: "https://chat.openai.com" });
  };
  const openWelcomePage = () => {
    chrome.tabs.create({ url: "welcome.html" });
  };
  if (authState.isLoading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(LoadingState, {});
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(ThemeProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-w-80 jd-bg-gradient-to-b jd-from-background jd-to-background/80 jd-backdrop-blur jd-overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { className: "jd-w-full jd-border-none jd-shadow-none jd-relative", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "jd-absolute jd-top-0 jd-left-0 jd-w-full jd-h-1 jd-bg-gradient-to-r jd-from-blue-600 jd-via-indigo-500 jd-to-purple-600" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      AppHeader,
      {
        isAuthenticated: authState.isAuthenticated,
        user: authState.user
      }
    ),
    authState.isAuthenticated && authState.user ? /* @__PURE__ */ jsxRuntimeExports.jsx(ToolGrid, { onLogout: handleLogout, onOpenChatGPT: openChatGPT }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
      LoginForm,
      {
        authState,
        onWelcomePageClick: openWelcomePage
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      AppFooter,
      {
        version: chrome.runtime.getManifest().version
      }
    )
  ] }) }) });
};
const applyStoredThemePreference = () => {
  const root = window.document.documentElement;
  const storedTheme = localStorage.getItem("theme") || "system";
  if (storedTheme === "dark") {
    root.classList.add("dark");
  } else if (storedTheme === "light") {
    root.classList.add("light");
  } else {
    if (window.matchMedia("(prefers-color-scheme: dark)").matches) {
      root.classList.add("dark");
    } else {
      root.classList.add("light");
    }
  }
};
applyStoredThemePreference();
const rootElement = document.getElementById("root");
if (!rootElement) throw new Error("Root element not found");
client.createRoot(rootElement).render(
  /* @__PURE__ */ jsxRuntimeExports.jsxs(React.StrictMode, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(ExtensionPopup, {}),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Toaster, { richColors: true, position: "bottom-right" })
  ] })
);
//# sourceMappingURL=popup.js.map
