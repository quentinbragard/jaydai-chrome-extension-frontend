const ENDPOINTS = {
  "chatgpt": {
    USER_INFO: "/backend-api/me",
    CONVERSATIONS_LIST: "/backend-api/conversations",
    CHAT_COMPLETION: "/backend-api/conversation",
    SPECIFIC_CONVERSATION: /\/backend-api\/conversation\/([a-f0-9-]+)$/
  },
  "claude": {
    USER_INFO: "/api/user",
    CONVERSATIONS_LIST: /\/api\/organizations\/[a-f0-9-]+\/chat_conversations/,
    CHAT_COMPLETION: /\/api\/organizations\/[a-f0-9-]+\/chat_conversations\/[a-f0-9-]+\/completion/,
    SPECIFIC_CONVERSATION: /\/api\/organizations\/[a-f0-9-]+\/chat_conversations\/([a-f0-9-]+)/
  },
  "mistral": {
    USER_INFO: "/api/trpc/user.session",
    CONVERSATIONS_LIST: "/api/trpc/chat.list",
    CHAT_COMPLETION: "/api/chat",
    SPECIFIC_CONVERSATION: /\/api\/chat/
  },
  "copilot": {
    USER_INFO: "/c/api/user",
    CONVERSATIONS_LIST: "/c/api/conversations",
    CHAT_COMPLETION: "/c/api/conversations",
    SPECIFIC_CONVERSATION: /\/c\/api\/conversations\/([a-zA-Z0-9-]+)\/history/
  }
};
const EVENTS = {
  USER_INFO: "jaydai:user-info",
  CONVERSATIONS_LIST: "jaydai:conversation-list",
  SPECIFIC_CONVERSATION: "jaydai:specific-conversation",
  CHAT_COMPLETION: "jaydai:chat-completion",
  ASSISTANT_RESPONSE: "jaydai:assistant-response",
  MESSAGE_EXTRACTED: "jaydai:message-extracted",
  CONVERSATION_LOADED: "jaydai:conversation-loaded",
  CONVERSATION_CHANGED: "jaydai:conversation-changed",
  QUEUE_MESSAGE: "jaydai:queue-message",
  NOTIFICATION_COUNT_CHANGED: "jaydai:notification-count-changed",
  OPEN_NOTIFICATIONS: "jaydai:open-notifications",
  TOGGLE_PANEL: "jaydai:toggle-panel",
  SHOW_AUTH_MODAL: "jaydai:show-auth-modal",
  AUTH_ERROR: "jaydai:auth-error",
  OPEN_SETTINGS: "jaydai:open-settings",
  OPEN_TEMPLATES: "jaydai:open-templates",
  INJECTION_COMPLETE: "jaydai:injection-complete"
};
function detectPlatform() {
  const hostname = window.location.hostname;
  if (hostname.includes("chatgpt.com")) {
    return "chatgpt";
  }
  if (hostname.includes("claude.ai")) {
    return "claude";
  }
  if (hostname.includes("mistral.ai")) {
    return "mistral";
  }
  if (hostname.includes("copilot.microsoft.com")) {
    return "copilot";
  }
  return "unknown";
}
function matchEndpoint(url, pattern) {
  if (pattern instanceof RegExp) {
    return pattern.test(url);
  }
  return url.includes(pattern);
}
function getEndpointEvent(url) {
  if (!url) return null;
  const platform = detectPlatform();
  if (platform === "unknown") return null;
  const pathname = url.startsWith("http") ? new URL(url).pathname + (new URL(url).search || "") : url;
  console.log(`Checking endpoint for ${platform}: ${pathname}`);
  if (matchEndpoint(pathname, ENDPOINTS[platform].SPECIFIC_CONVERSATION)) {
    console.log(`Matched ${platform} SPECIFIC_CONVERSATION`);
    return EVENTS.SPECIFIC_CONVERSATION;
  }
  if (matchEndpoint(pathname, ENDPOINTS[platform].USER_INFO)) {
    console.log(`Matched ${platform} USER_INFO`);
    return EVENTS.USER_INFO;
  }
  if (matchEndpoint(pathname, ENDPOINTS[platform].CONVERSATIONS_LIST)) {
    console.log(`Matched ${platform} CONVERSATIONS_LIST`);
    return EVENTS.CONVERSATIONS_LIST;
  }
  if (matchEndpoint(pathname, ENDPOINTS[platform].CHAT_COMPLETION)) {
    console.log(`Matched ${platform} CHAT_COMPLETION`);
    return EVENTS.CHAT_COMPLETION;
  }
  console.log(`No match found for ${platform}: ${pathname}`);
  return null;
}
function extractRequestBody(init) {
  if (!init || !init.body) return null;
  try {
    const bodyText = typeof init.body === "string" ? init.body : new TextDecoder().decode(init.body);
    if (bodyText.trim().startsWith("{")) {
      return JSON.parse(bodyText);
    }
  } catch (e) {
    console.error("Error parsing request body:", e);
  }
  return null;
}
function dispatchEvent(eventName, platform, data) {
  console.log(`Dispatching event: ${eventName}`, data);
  document.dispatchEvent(new CustomEvent(eventName, {
    detail: { ...data, platform, timestamp: Date.now() }
  }));
}
function processStreamData(data, assistantData, thinkingSteps) {
  var _a, _b, _c, _d, _e, _f, _g;
  detectPlatform();
  if (!assistantData) {
    assistantData = {
      messageId: null,
      conversationId: null,
      model: null,
      content: "",
      isComplete: false,
      currentThinkingStep: null,
      createTime: null,
      // For timestamp
      parentMessageId: null
      // For parent message tracking
    };
  }
  if (!thinkingSteps) {
    thinkingSteps = [];
  }
  if (data.type === "message_stream_complete") {
    assistantData.isComplete = true;
    assistantData.conversationId = data.conversation_id || assistantData.conversationId;
    return { assistantData, thinkingSteps };
  }
  if ((_a = data.v) == null ? void 0 : _a.message) {
    assistantData.messageId = data.v.message.id;
    assistantData.conversationId = data.v.conversation_id;
    assistantData.model = ((_b = data.v.message.metadata) == null ? void 0 : _b.model_slug) || null;
    if (data.v.message.create_time) {
      assistantData.createTime = data.v.message.create_time;
    }
    if ((_c = data.v.message.metadata) == null ? void 0 : _c.parent_id) {
      assistantData.parentMessageId = data.v.message.metadata.parent_id;
    }
    const role = (_d = data.v.message.author) == null ? void 0 : _d.role;
    const newStep = {
      id: data.v.message.id,
      role,
      content: "",
      createTime: data.v.message.create_time,
      parentMessageId: (_e = data.v.message.metadata) == null ? void 0 : _e.parent_id,
      initialText: ((_f = data.v.message.metadata) == null ? void 0 : _f.initial_text) || "",
      finishedText: ((_g = data.v.message.metadata) == null ? void 0 : _g.finished_text) || ""
    };
    thinkingSteps.push(newStep);
    assistantData.currentThinkingStep = thinkingSteps.length - 1;
    if (role === "assistant") {
      assistantData.content = "";
    }
    console.log("ASSISTANT DATA", assistantData);
    console.log("THINKING STEPS", thinkingSteps);
    return { assistantData, thinkingSteps };
  }
  if (data.o === "append" && data.p === "/message/content/parts/0" && data.v) {
    if (assistantData.currentThinkingStep !== null && assistantData.currentThinkingStep < thinkingSteps.length) {
      thinkingSteps[assistantData.currentThinkingStep].content += data.v;
      if (thinkingSteps[assistantData.currentThinkingStep].role === "assistant") {
        assistantData.content += data.v;
      }
    }
    return { assistantData, thinkingSteps };
  }
  if (typeof data.v === "string" && !data.o) {
    if (assistantData.currentThinkingStep !== null && assistantData.currentThinkingStep < thinkingSteps.length) {
      thinkingSteps[assistantData.currentThinkingStep].content += data.v;
      if (thinkingSteps[assistantData.currentThinkingStep].role === "assistant") {
        assistantData.content += data.v;
      }
    }
    return { assistantData, thinkingSteps };
  }
  if (data.o === "patch" && Array.isArray(data.v)) {
    for (const patch of data.v) {
      if (patch.p === "/message/status" && patch.v === "finished_successfully") ;
      if (patch.p === "/message/metadata/finished_text" && assistantData.currentThinkingStep !== null) {
        thinkingSteps[assistantData.currentThinkingStep].finishedText = patch.v;
      }
      if (patch.p === "/message/content/parts/0" && patch.o === "append" && patch.v) {
        if (assistantData.currentThinkingStep !== null && assistantData.currentThinkingStep < thinkingSteps.length) {
          thinkingSteps[assistantData.currentThinkingStep].content += patch.v;
          if (thinkingSteps[assistantData.currentThinkingStep].role === "assistant") {
            assistantData.content += patch.v;
          }
        }
      }
    }
    console.log("ASSISTANT DATAAAAAAAA", assistantData);
    console.log("THINKING STEPS", thinkingSteps);
    if (assistantData.content === "" && thinkingSteps.length > 0) {
      assistantData.content = thinkingSteps[thinkingSteps.length - 1].content;
    }
    return { assistantData, thinkingSteps };
  }
  return { assistantData, thinkingSteps };
}
async function processStreamingResponse(response, requestBody) {
  console.log("PROCESSING STREAMING RESPONSE");
  const platform = detectPlatform();
  const clonedResponse = response.clone();
  const reader = clonedResponse.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  let assistantData = {
    messageId: null,
    conversationId: null,
    model: null,
    content: "",
    isComplete: false,
    createTime: null,
    parentMessageId: null
  };
  let thinkingSteps = [];
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let eventEndIndex;
      while ((eventEndIndex = buffer.indexOf("\n\n")) !== -1) {
        const eventString = buffer.substring(0, eventEndIndex + 2);
        buffer = buffer.substring(eventEndIndex + 2);
        const eventMatch = eventString.match(/^event: ([^\n]+)/);
        const dataMatch = eventString.match(/data: (.+)$/m);
        if (!dataMatch) continue;
        const eventType = eventMatch ? eventMatch[1] : "unknown";
        if (dataMatch[1] === "[DONE]") {
          console.log("Received [DONE] message, finalizing response");
          console.log("ASSISTANT DATA", assistantData);
          if (assistantData.messageId && assistantData.content.length > 0) {
            assistantData.isComplete = true;
            dispatchEvent(EVENTS.ASSISTANT_RESPONSE, platform, assistantData);
          }
          continue;
        }
        try {
          const data = JSON.parse(dataMatch[1]);
          console.log("event type", eventType);
          console.log("data", data);
          if (data.type === "message_stream_complete") {
            if (assistantData.messageId) {
              assistantData.isComplete = true;
              console.log("Stream processing complete");
              dispatchEvent(EVENTS.ASSISTANT_RESPONSE, platform, assistantData);
            }
            continue;
          }
          const result = processStreamData(data, assistantData, thinkingSteps);
          assistantData = result.assistantData;
          thinkingSteps = result.thinkingSteps;
          if (assistantData.messageId && assistantData.content.length > 0 && assistantData.content.length % 500 === 0) {
            dispatchEvent(EVENTS.ASSISTANT_RESPONSE, platform, {
              ...assistantData,
              isComplete: false
            });
          }
        } catch (error) {
          console.error("Error parsing data:", error, "Raw data:", dataMatch[1]);
        }
      }
    }
    if (assistantData.messageId && assistantData.content.length > 0 && !assistantData.isComplete) {
      console.log("Stream ended without completion signal, sending final data");
      assistantData.isComplete = true;
      dispatchEvent(EVENTS.ASSISTANT_RESPONSE, platform, assistantData);
    }
  } catch (error) {
    console.error("Error processing stream:", error);
    if (assistantData.messageId && assistantData.content.length > 0) {
      console.log("Salvaging partial response after error");
      assistantData.isComplete = true;
      dispatchEvent(EVENTS.ASSISTANT_RESPONSE, platform, assistantData);
    }
  }
}
let originalFetch = null;
function initFetchInterceptor() {
  originalFetch = window.fetch;
  window.fetch = async function(input, init) {
    var _a, _b, _c, _d;
    const url = typeof input === "string" ? input : input instanceof URL ? input.toString() : input.url;
    console.log("🔍 Intercepting request:", url);
    const eventName = getEndpointEvent(url);
    const platform = detectPlatform();
    if (!eventName) {
      return originalFetch.apply(this, arguments);
    }
    const requestBody = extractRequestBody(init);
    const response = await originalFetch.apply(this, arguments);
    if (!response.ok) return response;
    try {
      const isStreaming = ((_a = response.headers.get("content-type")) == null ? void 0 : _a.includes("text/event-stream")) || false;
      if (eventName === EVENTS.CHAT_COMPLETION) {
        dispatchEvent(EVENTS.CHAT_COMPLETION, platform, { requestBody });
        if (isStreaming && ((_d = (_c = (_b = requestBody == null ? void 0 : requestBody.messages) == null ? void 0 : _b[0]) == null ? void 0 : _c.author) == null ? void 0 : _d.role) === "user") {
          processStreamingResponse(response, requestBody);
        }
      } else if (!isStreaming) {
        const responseData = await response.clone().json().catch(() => null);
        if (responseData) {
          dispatchEvent(eventName, platform, {
            url,
            platform,
            requestBody,
            responseBody: responseData,
            method: (init == null ? void 0 : init.method) || "GET"
          });
        }
      }
    } catch (error) {
      console.error("Error in fetch interceptor:", error);
    }
    return response;
  };
}
(function() {
  try {
    initFetchInterceptor();
    console.log("✅ Jaydai network interceptor initialized successfully");
  } catch (error) {
    console.error("❌ Error initializing network interceptor:", error);
  }
})();
//# sourceMappingURL=networkInterceptor.js.map
